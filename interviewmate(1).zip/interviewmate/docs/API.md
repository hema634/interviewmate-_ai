# API reference

JSON over HTTP. Authenticated routes need `Authorization: Bearer <token>` (from register/login). Errors: `{"error":{"code","message"}}`. Every private record is scoped to the signed-in user server-side; other users' records return **404**.

| Method | Path | Auth | Purpose |
|---|---|---|---|
| GET | `/api/health` | no | Server status; which providers are configured |
| GET | `/api/privacy` | no | What is stored, which external providers (if any) receive data |
| GET | `/api/rubric` | no | Weights, formula, category definitions, limitations |
| POST | `/api/auth/register` | no | Create account → token |
| POST | `/api/auth/login` | no | Sign in → token |
| GET | `/api/me` | yes | Profile and consent flags (PUT updates name/consents; DELETE erases account and all data) |
| PUT | `/api/me` | yes | Profile and consent flags (PUT updates name/consents; DELETE erases account and all data) |
| DELETE | `/api/me` | yes | Profile and consent flags (PUT updates name/consents; DELETE erases account and all data) |
| GET | `/api/export` | yes | Download all your data as JSON |
| POST | `/api/documents` | yes | Upload PDF/DOCX/TXT (multipart: `kind`, `file`); GET lists |
| POST | `/api/documents/text` | yes | Submit pasted text instead of a file |
| GET | `/api/documents` | yes | Upload PDF/DOCX/TXT (multipart: `kind`, `file`); GET lists |
| DELETE | `/api/documents/<id>` | yes | Delete a document and its extracted profile |
| GET | `/api/profiles` | yes | List extracted candidate profiles |
| PUT | `/api/profiles/<id>` | yes | Save user corrections to a profile |
| GET | `/api/jobs` | yes | List extracted job profiles |
| PUT | `/api/jobs/<id>` | yes | Save corrections to a job profile |
| GET | `/api/compare` | yes | `?profile_id=&job_id=` matching/missing skills, relevant projects, topics |
| POST | `/api/sessions` | yes | POST creates an interview (mode, target_role, experience_level, difficulty, num_questions, duration_minutes, language, input_mode, profile_id, job_id, project_name); GET lists |
| GET | `/api/sessions` | yes | POST creates an interview (mode, target_role, experience_level, difficulty, num_questions, duration_minutes, language, input_mode, profile_id, job_id, project_name); GET lists |
| GET | `/api/sessions/<id>` | yes | Full session state (GET) / delete (DELETE) |
| DELETE | `/api/sessions/<id>` | yes | Full session state (GET) / delete (DELETE) |
| POST | `/api/sessions/<id>/answer` | yes | Submit `{question_id,text,source}` → evaluation, next step (follow-up / question / complete) |
| POST | `/api/sessions/<id>/control` | yes | `{action: pause|resume|repeat|skip|end}` |
| POST | `/api/sessions/<id>/retry` | yes | Retry a question → saved comparison |
| GET | `/api/sessions/<id>/retries` | yes | Saved retry comparisons |
| POST | `/api/sessions/<id>/coach` | yes | `{question_id, action}` coaching (why_weak, better_answer, next_followup, shorter_clearer, explain_concept, practice_example) |
| GET | `/api/sessions/<id>/report` | yes | Report as JSON |
| GET | `/api/sessions/<id>/report.html` | yes | Print-friendly report |
| GET | `/api/sessions/<id>/report.pdf` | yes | PDF report |
| POST | `/api/evaluations/<id>/flag` | yes | Flag an evaluation as incorrect `{message}` |
| GET | `/api/flags` | yes | Your flags |
| GET | `/api/progress` | yes | Trend, category averages, weak areas, recommendation |
| GET | `/api/dashboard` | yes | Dashboard summary |
| GET | `/api/plans/<id>` | yes | Seven-day plan for a completed session |
| POST | `/api/speech/transcribe` | yes | Multipart `audio` → editable transcript (needs audio consent + STT configured; 503 `stt_unavailable` otherwise) |
| POST | `/api/speech/synthesize` | yes | `{text}` → audio (503 `tts_unavailable` if not configured; client falls back to browser voice) |
| GET | `/api/coding/problems` | yes | Practice problems, languages; execution is not available |
| POST | `/api/coding/review` | yes | Static code review `{language, problem_id, code, explanation}` (no execution) |
| POST | `/api/demo` | yes | Seed a clearly labelled DEMO session |
