"""Run: python -m interviewmate.server  (from backend/)"""
import os
from .app import create_app
from .config import Settings
from .web import serve


def load_dotenv(path=".env"):
    if os.path.exists(path):
        for line in open(path):
            line = line.strip()
            if line and not line.startswith("#") and "=" in line:
                k, v = line.split("=", 1)
                os.environ.setdefault(k.strip(), v.strip())


def main():
    load_dotenv()
    settings = Settings.load()
    if settings.secret_key.startswith("dev-insecure"):
        print("WARNING: using the insecure default IM_SECRET_KEY. Set IM_SECRET_KEY before deploying.")
    app, ctx = create_app(settings)
    print(f"InterviewMate AI on http://{settings.host}:{settings.port}  (LLM provider: {ctx.provider.name}; STT: {ctx.stt.available}; TTS: {ctx.tts.available})")
    serve(app, settings.host, settings.port, settings.max_upload_bytes + 1024 * 1024)


if __name__ == "__main__":
    main()
