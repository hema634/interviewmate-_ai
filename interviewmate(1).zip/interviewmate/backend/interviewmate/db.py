"""SQLite persistence with a tiny versioned-migration runner.

PostgreSQL is the suggested production database; the schema below uses plain SQL
types so it ports directly. SQLite keeps the MVP runnable with zero dependencies.
"""
import sqlite3
import threading

MIGRATIONS = [
    # v1: core schema
    """
    CREATE TABLE users (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        email TEXT NOT NULL UNIQUE,
        password_hash TEXT NOT NULL,
        display_name TEXT NOT NULL DEFAULT '',
        consent_ai_processing INTEGER NOT NULL DEFAULT 0,
        consent_audio INTEGER NOT NULL DEFAULT 0,
        created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
    );
    CREATE TABLE uploaded_documents (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
        kind TEXT NOT NULL CHECK (kind IN ('resume','job_description')),
        filename TEXT NOT NULL,
        text TEXT NOT NULL,
        created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
    );
    CREATE TABLE candidate_profiles (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
        document_id INTEGER REFERENCES uploaded_documents(id) ON DELETE SET NULL,
        profile_json TEXT NOT NULL,
        user_corrected INTEGER NOT NULL DEFAULT 0,
        created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
    );
    CREATE TABLE job_descriptions (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
        document_id INTEGER REFERENCES uploaded_documents(id) ON DELETE SET NULL,
        job_json TEXT NOT NULL,
        user_corrected INTEGER NOT NULL DEFAULT 0,
        created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
    );
    CREATE TABLE interview_sessions (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
        profile_id INTEGER REFERENCES candidate_profiles(id) ON DELETE SET NULL,
        job_id INTEGER REFERENCES job_descriptions(id) ON DELETE SET NULL,
        mode TEXT NOT NULL,
        target_role TEXT NOT NULL,
        experience_level TEXT NOT NULL,
        difficulty TEXT NOT NULL,
        language TEXT NOT NULL DEFAULT 'en',
        input_mode TEXT NOT NULL DEFAULT 'typed',
        num_questions INTEGER NOT NULL,
        duration_minutes INTEGER NOT NULL,
        status TEXT NOT NULL DEFAULT 'active' CHECK (status IN ('active','paused','completed')),
        state_json TEXT NOT NULL DEFAULT '{}',
        is_demo INTEGER NOT NULL DEFAULT 0,
        elapsed_seconds INTEGER NOT NULL DEFAULT 0,
        overall_score REAL,
        created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
        completed_at TEXT
    );
    CREATE TABLE interview_questions (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        session_id INTEGER NOT NULL REFERENCES interview_sessions(id) ON DELETE CASCADE,
        seq INTEGER NOT NULL,
        text TEXT NOT NULL,
        topic TEXT NOT NULL,
        category TEXT NOT NULL,
        difficulty TEXT NOT NULL,
        is_followup INTEGER NOT NULL DEFAULT 0,
        parent_question_id INTEGER,
        rubric_json TEXT NOT NULL,
        status TEXT NOT NULL DEFAULT 'asked' CHECK (status IN ('asked','answered','skipped')),
        created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
    );
    CREATE TABLE interview_answers (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        question_id INTEGER NOT NULL REFERENCES interview_questions(id) ON DELETE CASCADE,
        attempt INTEGER NOT NULL DEFAULT 1,
        text TEXT NOT NULL,
        source TEXT NOT NULL DEFAULT 'typed',
        duration_seconds INTEGER,
        created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
    );
    CREATE TABLE evaluation_results (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        answer_id INTEGER NOT NULL UNIQUE REFERENCES interview_answers(id) ON DELETE CASCADE,
        total_score REAL,
        result_json TEXT NOT NULL,
        evaluator TEXT NOT NULL,
        created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
    );
    CREATE TABLE retry_attempts (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        question_id INTEGER NOT NULL REFERENCES interview_questions(id) ON DELETE CASCADE,
        original_answer_id INTEGER NOT NULL REFERENCES interview_answers(id) ON DELETE CASCADE,
        revised_answer_id INTEGER NOT NULL REFERENCES interview_answers(id) ON DELETE CASCADE,
        comparison_json TEXT NOT NULL,
        created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
    );
    CREATE TABLE improvement_plans (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        session_id INTEGER NOT NULL UNIQUE REFERENCES interview_sessions(id) ON DELETE CASCADE,
        plan_json TEXT NOT NULL,
        created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
    );
    CREATE TABLE user_feedback (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
        evaluation_id INTEGER NOT NULL REFERENCES evaluation_results(id) ON DELETE CASCADE,
        category TEXT,
        message TEXT NOT NULL,
        created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
    );
    CREATE INDEX idx_sessions_user ON interview_sessions(user_id);
    CREATE INDEX idx_questions_session ON interview_questions(session_id);
    CREATE INDEX idx_docs_user ON uploaded_documents(user_id);
    """,
    # v2: explicit consent for local document processing
    "ALTER TABLE users ADD COLUMN consent_documents INTEGER NOT NULL DEFAULT 0;",
]


class Database:
    def __init__(self, path: str):
        self.path = path
        self._local = threading.local()
        self.migrate()

    def conn(self) -> sqlite3.Connection:
        c = getattr(self._local, "conn", None)
        if c is None:
            c = sqlite3.connect(self.path, timeout=30)
            c.row_factory = sqlite3.Row
            c.execute("PRAGMA foreign_keys = ON")
            self._local.conn = c
        return c

    def migrate(self) -> None:
        c = self.conn()
        c.execute("CREATE TABLE IF NOT EXISTS schema_version (version INTEGER NOT NULL)")
        row = c.execute("SELECT MAX(version) AS v FROM schema_version").fetchone()
        current = row["v"] or 0
        for i, sql in enumerate(MIGRATIONS, start=1):
            if i > current:
                c.executescript(sql)
                c.execute("INSERT INTO schema_version(version) VALUES (?)", (i,))
                c.commit()

    def execute(self, sql: str, params: tuple = ()) -> sqlite3.Cursor:
        c = self.conn()
        cur = c.execute(sql, params)
        c.commit()
        return cur

    def one(self, sql: str, params: tuple = ()):
        return self.conn().execute(sql, params).fetchone()

    def all(self, sql: str, params: tuple = ()):
        return self.conn().execute(sql, params).fetchall()
