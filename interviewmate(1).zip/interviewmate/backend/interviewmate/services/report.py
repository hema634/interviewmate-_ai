"""ReportService: JSON report, print-friendly HTML, and PDF. Observed evidence, AI suggestions and
unassessed categories are labelled separately throughout."""
from __future__ import annotations

import html
import json

from ..scoring import CATEGORY_LABELS, CATEGORY_WEIGHTS
from . import pdfgen
from .plan import category_averages


def build_report(svc, user_id: int, session_id: int) -> dict:
    s = svc.get(user_id, session_id)
    plan_row = svc.db.one("SELECT plan_json FROM improvement_plans WHERE session_id=?", (session_id,))
    plan = json.loads(plan_row["plan_json"]) if plan_row else None
    items, strengths, gaps, comm_good, comm_gap = [], [], [], [], []
    qa = []
    for q in s["questions"]:
        if not q["answers"]:
            qa.append({"seq": q["seq"], "question": q["text"], "topic": q["topic"], "status": q["status"], "attempts": []})
            continue
        first = q["answers"][0]; ev = first["evaluation"]
        items.append({"question": q["text"], "topic": q["topic"], "category": q["category"], "evaluation": ev})
        for n in ev["flags"]["concepts_covered"]:
            strengths.append(f"{q['topic']}: {n}")
        for n in ev["flags"]["concepts_missing"]:
            gaps.append(f"{q['topic']}: {n}")
        c = ev["categories"]["communication"]
        (comm_good if c["status"] == "scored" and c["score"] >= 70 else comm_gap).append(
            {"question": q["text"], "status": c["status"], "score": c["score"], "note": c["explanation"]})
        qa.append({"seq": q["seq"], "question": q["text"], "topic": q["topic"], "status": q["status"],
                   "attempts": [{"attempt": a["attempt"], "answer": a["text"], "total": a["evaluation"]["total"],
                                 "partial": a["evaluation"]["partial"], "evaluator": a["evaluation"]["evaluator"],
                                 "categories": a["evaluation"]["categories"], "feedback": a["evaluation"]["feedback"]} for a in q["answers"]]})
    strengths = list(dict.fromkeys(strengths)); gaps = list(dict.fromkeys(gaps))  # de-duplicate, keep order
    avgs = category_averages(items)
    not_assessed = [{"question": it["question"], "category": CATEGORY_LABELS[k], "reason": c["explanation"]}
                    for it in items for k, c in it["evaluation"]["categories"].items() if c["status"] != "scored"]
    return {
        "overview": {"session_id": s["id"], "mode": s["mode"], "target_role": s["target_role"], "experience_level": s["experience_level"],
                     "difficulty": s["difficulty"], "questions_answered": len(items), "questions_total": len([q for q in s["questions"]]),
                     "duration_minutes": s["duration_minutes"], "elapsed_seconds": s["elapsed_seconds"], "completed_at": s["completed_at"],
                     "is_demo": s["is_demo"]},
        "overall_score": s["overall_score"],
        "weights": {CATEGORY_LABELS[k]: v for k, v in CATEGORY_WEIGHTS.items()},
        "category_scores": {CATEGORY_LABELS[k]: v for k, v in avgs.items()},
        "technical_strengths": strengths, "technical_gaps": gaps,
        "communication": {"strengths": comm_good, "gaps": comm_gap},
        "questions": qa, "retries": svc.retries(user_id, session_id),
        "study_topics": (plan or {}).get("study_topics", []), "improvement_plan": plan, "not_assessed": not_assessed,
        "labels": {"observed": "Transcript excerpts are quoted exactly from your answers (observed evidence).",
                   "ai": "Scores, explanations, study topics and the plan are AI-generated suggestions.",
                   "unassessed": "Categories marked insufficient evidence were not scored; scores were renormalised and flagged partial.",
                   "disclaimer": "Practice feedback only. Not a prediction of any hiring decision."},
    }


def _e(x):
    return html.escape(str(x if x is not None else "—"))


def report_html(rep: dict) -> str:
    o = rep["overview"]
    parts = [f"""<!doctype html><html lang="en"><head><meta charset="utf-8"><title>InterviewMate AI Report #{o['session_id']}</title>
<style>body{{font:14px/1.5 system-ui,sans-serif;max-width:860px;margin:24px auto;padding:0 16px;color:#111}}
h1{{font-size:24px}}h2{{border-bottom:2px solid #b8923a;padding-bottom:4px;margin-top:28px}}
.card{{border:1px solid #ccc;border-radius:8px;padding:12px;margin:10px 0;page-break-inside:avoid}}
.tag{{display:inline-block;font-size:11px;border:1px solid #888;border-radius:10px;padding:0 8px;margin-right:6px}}
blockquote{{margin:6px 0;padding:4px 10px;border-left:3px solid #b8923a;background:#faf6ec}} .muted{{color:#555}}
table{{border-collapse:collapse}}td,th{{border:1px solid #ccc;padding:4px 8px;text-align:left}}
@media print{{.noprint{{display:none}}}}</style></head><body>
<p class="noprint"><button onclick="window.print()">Print / Save as PDF</button></p>
<h1>InterviewMate AI — Interview Report</h1>"""]
    if o["is_demo"]:
        parts.append("<p><strong>DEMO session — sample data, clearly labelled.</strong></p>")
    parts.append(f"<h2>1-2. Overview</h2><p>Mode: <b>{_e(o['mode'])}</b> · Role: <b>{_e(o['target_role'])}</b> · Level: {_e(o['experience_level'])} · Difficulty: {_e(o['difficulty'])}<br>"
                 f"Answered {o['questions_answered']} question(s) · {o['elapsed_seconds']//60} min elapsed of {o['duration_minutes']} · Completed: {_e(o['completed_at'])}</p>")
    parts.append(f"<h2>3. Overall score</h2><p style='font-size:28px'><b>{_e(rep['overall_score'])}</b> / 100 <span class='tag'>AI-generated</span></p>")
    parts.append("<h2>4. Category-wise scores</h2><table><tr><th>Category</th><th>Weight</th><th>Average</th><th>Answers scored</th><th>Insufficient evidence</th></tr>")
    for label, v in rep["category_scores"].items():
        parts.append(f"<tr><td>{_e(label)}</td><td>{int(rep['weights'][label]*100)}%</td><td>{_e(v['average'])}</td><td>{v['n']}</td><td>{v['insufficient']}</td></tr>")
    parts.append("</table>")
    parts.append("<h2>5. Technical strengths</h2><ul>" + "".join(f"<li>{_e(x)}</li>" for x in rep["technical_strengths"]) + ("" if rep["technical_strengths"] else "<li>None observed yet.</li>") + "</ul>")
    parts.append("<h2>6. Technical knowledge gaps</h2><ul>" + "".join(f"<li>{_e(x)}</li>" for x in rep["technical_gaps"]) + ("" if rep["technical_gaps"] else "<li>No gaps against the rubrics.</li>") + "</ul>")
    parts.append("<h2>7. Communication</h2><p><b>Strengths:</b> " + (_e(len(rep['communication']['strengths'])) + " answer(s) scored 70+") + "</p><ul>" +
                 "".join(f"<li>{_e(g['question'])} — {_e(g['score'])} ({_e(g['status'])})</li>" for g in rep["communication"]["gaps"]) + "</ul>")
    parts.append("<h2>8-9. Question-by-question feedback with transcript evidence</h2>")
    for q in rep["questions"]:
        parts.append(f"<div class='card'><b>Q{q['seq']}. {_e(q['question'])}</b> <span class='tag'>{_e(q['topic'])}</span>")
        if not q["attempts"]:
            parts.append(f"<p class='muted'>Not answered ({_e(q['status'])}).</p></div>"); continue
        for a in q["attempts"]:
            parts.append(f"<p><b>Attempt {a['attempt']}</b> — total {_e(a['total'])}{' (partial: some categories not assessed)' if a['partial'] else ''} <span class='tag'>{_e(a['evaluator'])}</span></p>"
                         f"<p class='muted'>Your answer (observed): {_e(a['answer'])}</p>")
            for k, c in a["categories"].items():
                parts.append(f"<p><b>{_e(CATEGORY_LABELS[k])}:</b> {_e(c['score']) if c['status']=='scored' else 'Insufficient evidence'} — {_e(c['explanation'])}</p>")
                for ev in c["evidence"]:
                    parts.append(f"<blockquote>“{_e(ev['quote'])}”<br><span class='muted'>Why it matters: {_e(ev['why_it_matters'])}</span></blockquote>")
                parts.append(f"<p class='muted'>Suggestion (AI): {_e(c['suggestion'])}</p>")
        parts.append("</div>")
    parts.append("<h2>10. Recommended topics to study</h2><ul>" + "".join(f"<li>{_e(t['topic'])} — {_e(t['concept'])}</li>" for t in rep["study_topics"]) + "</ul>")
    parts.append("<h2>11. Retry comparisons</h2>")
    for r in rep["retries"]:
        c = r["comparison"]
        parts.append(f"<div class='card'><b>{_e(r['question'])}</b><p>Score change (second − first): <b>{_e(c['score_change'])}</b> ({_e(c['first_total'])} → {_e(c['second_total'])})</p><p class='muted'>{_e(c['disclaimer'])}</p></div>")
    if not rep["retries"]:
        parts.append("<p class='muted'>No retries yet.</p>")
    plan = rep["improvement_plan"]
    parts.append("<h2>12. Seven-day improvement plan <span class='tag'>AI-generated suggestions</span></h2>")
    if plan:
        for d in plan["days"]:
            parts.append(f"<div class='card'><b>Day {d['day']}: {_e(d['topic'])}</b> · ~{d['minutes']} min<ul>" + "".join(f"<li>{_e(t)}</li>" for t in d["tasks"]) +
                         f"</ul><p class='muted'>Done when: {_e(d['completion_criteria'])}</p></div>")
    parts.append("<h2>Not assessed reliably</h2><ul>" + "".join(f"<li>{_e(n['category'])} on “{_e(n['question'])}”: {_e(n['reason'])}</li>" for n in rep["not_assessed"]) + ("" if rep["not_assessed"] else "<li>All categories were assessed.</li>") + "</ul>")
    parts.append(f"<hr><p class='muted'>{_e(rep['labels']['observed'])}<br>{_e(rep['labels']['ai'])}<br>{_e(rep['labels']['unassessed'])}<br><b>{_e(rep['labels']['disclaimer'])}</b></p></body></html>")
    return "".join(parts)


def report_pdf(rep: dict) -> bytes:
    o = rep["overview"]
    b = [("h1", "InterviewMate AI - Interview Report")]
    if o["is_demo"]:
        b.append(("n", "DEMO session - sample data, clearly labelled."))
    b += [("p", f"Mode: {o['mode']} | Role: {o['target_role']} | Level: {o['experience_level']} | Difficulty: {o['difficulty']}"),
          ("p", f"Questions answered: {o['questions_answered']} | Elapsed: {o['elapsed_seconds']//60} of {o['duration_minutes']} min"),
          ("h2", f"Overall score: {rep['overall_score']} / 100 (AI-generated)"), ("h2", "Category scores")]
    for label, v in rep["category_scores"].items():
        b.append(("b", f"{label} ({int(rep['weights'][label]*100)}%): average {v['average']} over {v['n']} answer(s); insufficient evidence: {v['insufficient']}"))
    b.append(("h2", "Technical strengths"))
    b += [("b", x) for x in rep["technical_strengths"]] or [("p", "None observed yet.")]
    b.append(("h2", "Technical knowledge gaps"))
    b += [("b", x) for x in rep["technical_gaps"]] or [("p", "No gaps against the rubrics.")]
    b.append(("h2", "Question-by-question feedback"))
    for q in rep["questions"]:
        b.append(("p", f"Q{q['seq']}. {q['question']}"))
        if not q["attempts"]:
            b.append(("n", f"Not answered ({q['status']})")); continue
        for a in q["attempts"]:
            b.append(("n", f"Attempt {a['attempt']} - total {a['total']}{' (partial)' if a['partial'] else ''} - {a['evaluator']}"))
            b.append(("p", "Your answer (observed): " + a["answer"]))
            for k, c in a["categories"].items():
                b.append(("b", f"{CATEGORY_LABELS[k]}: {c['score'] if c['status']=='scored' else 'Insufficient evidence'} - {c['explanation']}"))
                for ev in c["evidence"]:
                    b.append(("q", ev["quote"]))
    b.append(("h2", "Recommended topics to study"))
    b += [("b", f"{t['topic']} - {t['concept']}") for t in rep["study_topics"]]
    b.append(("h2", "Retry comparisons"))
    for r in rep["retries"]:
        c = r["comparison"]
        b.append(("b", f"{r['question']}: {c['first_total']} -> {c['second_total']} (change {c['score_change']})"))
    if not rep["retries"]:
        b.append(("p", "No retries yet."))
    plan = rep["improvement_plan"]
    b.append(("h2", "Seven-day improvement plan (AI-generated suggestions)"))
    for d in (plan or {}).get("days", []):
        b.append(("p", f"Day {d['day']}: {d['topic']} (~{d['minutes']} min)"))
        b += [("b", t) for t in d["tasks"]]
        b.append(("n", "Done when: " + d["completion_criteria"]))
    b.append(("h2", "Not assessed reliably"))
    b += [("b", f"{n['category']} on '{n['question']}': {n['reason']}") for n in rep["not_assessed"]] or [("p", "All categories were assessed.")]
    b.append(("n", rep["labels"]["observed"] + " " + rep["labels"]["ai"] + " " + rep["labels"]["unassessed"]))
    b.append(("n", rep["labels"]["disclaimer"]))
    return pdfgen.make_pdf(b)
