"""SpeechTranscriptionService and TextToSpeechService (Whisper-/OpenAI-compatible HTTP APIs).

Audio is processed in memory and never written to disk or the database. If a provider is not
configured, methods raise HttpError(503) and the client falls back to typed answers / browser TTS.
"""
from __future__ import annotations

import json
import urllib.error
import urllib.request
import uuid

from ..web import HttpError

MAX_AUDIO_BYTES = 10 * 1024 * 1024


class SpeechTranscriptionService:
    def __init__(self, settings):
        self.s = settings

    @property
    def available(self) -> bool:
        return bool(self.s.stt_base_url and self.s.stt_api_key)

    def transcribe(self, filename: str, audio: bytes, content_type: str, language: str | None = None) -> dict:
        if not self.available:
            raise HttpError(503, "Speech recognition is not configured on this server. Please type your answer instead.", "stt_unavailable")
        if not audio or len(audio) < 800:
            raise HttpError(422, "No audio captured (recording was empty). Try again or type your answer.", "silence")
        if len(audio) > MAX_AUDIO_BYTES:
            raise HttpError(413, "Recording is too long (10 MB max).", "too_large")
        boundary = uuid.uuid4().hex
        parts = []
        def field(name, value):
            parts.append(f'--{boundary}\r\nContent-Disposition: form-data; name="{name}"\r\n\r\n{value}\r\n'.encode())
        field("model", self.s.stt_model)
        field("response_format", "json")
        if language and language != "auto":
            field("language", language)
        safe_name = "".join(ch for ch in (filename or "audio.webm") if ch.isalnum() or ch in "._-") or "audio.webm"
        parts.append((f'--{boundary}\r\nContent-Disposition: form-data; name="file"; filename="{safe_name}"\r\n'
                      f'Content-Type: {content_type or "application/octet-stream"}\r\n\r\n').encode() + audio + b"\r\n")
        parts.append(f"--{boundary}--\r\n".encode())
        req = urllib.request.Request(self.s.stt_base_url.rstrip("/") + "/audio/transcriptions", data=b"".join(parts), method="POST",
                                     headers={"Authorization": f"Bearer {self.s.stt_api_key}",
                                              "Content-Type": f"multipart/form-data; boundary={boundary}"})
        try:
            with urllib.request.urlopen(req, timeout=60) as r:
                payload = json.loads(r.read())
        except (urllib.error.URLError, TimeoutError, ValueError):
            raise HttpError(502, "Transcription failed. You can retry or type your answer.", "stt_failed")
        text = str(payload.get("text", "")).strip()
        if not text:
            raise HttpError(422, "No speech detected (silence or heavy background noise). Try again closer to the microphone, or type.", "silence")
        return {"text": text, "editable": True, "note": "Review and correct this transcript before submitting."}


class TextToSpeechService:
    def __init__(self, settings):
        self.s = settings

    @property
    def available(self) -> bool:
        return bool(self.s.tts_base_url and self.s.tts_api_key and self.s.tts_model)

    def speak(self, text: str, voice: str = "alloy") -> tuple[bytes, str]:
        if not self.available:
            raise HttpError(503, "Server text-to-speech is not configured. The browser's built-in voice will be used if available.", "tts_unavailable")
        text = (text or "").strip()[:1500]
        if not text:
            raise HttpError(400, "Nothing to read", "bad_request")
        body = json.dumps({"model": self.s.tts_model, "input": text, "voice": voice}).encode()
        req = urllib.request.Request(self.s.tts_base_url.rstrip("/") + "/audio/speech", data=body, method="POST",
                                     headers={"Authorization": f"Bearer {self.s.tts_api_key}", "Content-Type": "application/json"})
        try:
            with urllib.request.urlopen(req, timeout=60) as r:
                return r.read(), r.headers.get("Content-Type", "audio/mpeg")
        except (urllib.error.URLError, TimeoutError):
            raise HttpError(502, "Text-to-speech failed. The question is still shown as text.", "tts_failed")
