"""AdaptiveQuestionService: picks questions and decides follow-ups from the previous answer.

Pure functions over (state, profile, job, last evaluation) so the logic is unit-testable.
Never repeats a question unless a retry is explicitly requested; asks one main question at a time.
"""
from __future__ import annotations

import copy

from ..data.bank import PROJECT_TEMPLATES, QUESTIONS

LEVELS = ["easy", "medium", "hard"]
BASE_LEVEL = {"fresher": 0, "junior": 1, "mid": 1, "senior": 2}
MODES = ("hr", "software", "electrical", "project", "mixed")
ELECTRICAL_HINTS = ("electrical", "automation", "control", "power", "embedded", "plc", "scada", "instrument", "iot", "eee", "electronics")


def initial_state(config: dict, profile: dict | None, job: dict | None) -> dict:
    level = LEVELS.index(config["difficulty"]) if config["difficulty"] in LEVELS else BASE_LEVEL.get(config["experience_level"], 1)
    return {
        "asked_ids": [], "main_count": 0, "followups_used": {}, "current_question_id": None,
        "level": level, "adaptive": config["difficulty"] == "adaptive", "covered": [],
        "project": config.get("project_name") or pick_project(profile, job),
        "project_step": 0, "mixed_index": 0, "skipped": 0, "repeats": 0,
        "paused": False, "elapsed_base": 0.0, "last_resume_ts": None,
    }


def pick_project(profile: dict | None, job: dict | None) -> str | None:
    projects = (profile or {}).get("projects") or []
    if not projects:
        return None
    wanted = {s.lower() for s in ((job or {}).get("required_skills") or []) + ((job or {}).get("preferred_skills") or [])}
    best = max(projects, key=lambda p: len(set(p.get("skills", [])) & wanted))
    return best["name"]


def _skillset(profile, job):
    cand = {s.lower() for s in (profile or {}).get("technical_skills", [])}
    req = {s.lower() for s in (job or {}).get("required_skills", [])}
    pref = {s.lower() for s in (job or {}).get("preferred_skills", [])}
    return cand, req, pref


def personalization_score(q: dict, profile, job) -> int:
    cand, req, pref = _skillset(profile, job)
    names = {t.lower() for t in q.get("tags", [])} | {q["topic"].lower()}
    def hit(skills):
        return sum(1 for s in skills if any(s in n or n in s for n in names))
    return 2 * hit(req) + hit(pref) + hit(cand)


def pick_domain(config: dict, profile, job) -> str:
    cand, req, pref = _skillset(profile, job)
    role = (config.get("target_role") or "").lower()
    sw = {"python", "java", "c++", "c#", "javascript", "typescript", "react", "sql", "rest api", "django", "flask", "fastapi", "docker", "git", "data structures", "algorithms"}
    el = {"plc", "scada", "matlab", "simulink", "arduino", "esp32", "embedded c", "iot", "pid", "control systems", "power electronics", "power systems", "sensors", "relay", "hmi", "transformer"}
    e_score = len((cand | req | pref) & el) + (3 if any(h in role for h in ELECTRICAL_HINTS) else 0)
    s_score = len((cand | req | pref) & sw) + (3 if any(h in role for h in ("software", "developer", "backend", "frontend", "full stack", "web")) else 0)
    return "software" if s_score > e_score else "electrical"


def _project_question(state: dict) -> dict | None:
    step = state["project_step"]
    if step >= len(PROJECT_TEMPLATES):
        return None
    key, topic, diff, text, concepts = PROJECT_TEMPLATES[step]
    p = state["project"] or "your main project"
    ref = ("Project defense answers should be specific: named components with ratings, reasons for each choice, "
           "numbers with units, tests with measured results, and honest limitations.")
    return {"id": f"proj_{key}", "category": "project", "topic": topic, "difficulty": diff,
            "text": text.format(p=p), "answer_type": "project", "concepts": concepts, "reference": ref,
            "misconceptions": [], "followup_vague": "Which specific component, value, or result can you point to as evidence?", "tags": ["project"]}


def _bank_pick(category: str, state, profile, job) -> dict | None:
    pool = [q for q in QUESTIONS if q["category"] == category and q["id"] not in state["asked_ids"]]
    if not pool:
        return None
    target = state["level"]
    def key(q):
        return (abs(LEVELS.index(q["difficulty"]) - target), -personalization_score(q, profile, job), QUESTIONS.index(q))
    return copy.deepcopy(min(pool, key=key))


MIXED_PATTERN = ["hr", "tech", "project", "tech", "hr", "project", "tech", "hr"]


def next_main_question(config: dict, state: dict, profile, job) -> dict | None:
    mode = config["mode"]
    if mode == "project":
        return _project_question(state)
    if mode == "mixed":
        for _ in range(len(MIXED_PATTERN)):
            slot = MIXED_PATTERN[state["mixed_index"] % len(MIXED_PATTERN)]
            state["mixed_index"] += 1
            if slot == "hr":
                q = _bank_pick("hr", state, profile, job)
            elif slot == "project":
                q = _project_question(state)
            else:
                q = _bank_pick(pick_domain(config, profile, job), state, profile, job)
            if q:
                return q
        return None
    return _bank_pick(mode, state, profile, job)


def advance_after_question(state: dict, q: dict) -> None:
    if q["id"].startswith("proj_") and not q["id"].endswith("_fu"):
        state["project_step"] += 1


def decide_followup(question: dict, evaluation: dict, state: dict, followups_allowed: bool) -> dict | None:
    """Return a follow-up question dict (rubric included) or None."""
    if question.get("is_followup") or not followups_allowed:
        return None
    flags = evaluation["flags"]
    if flags["dont_know"]:
        return None  # respect honesty; move on rather than pressing
    cov = flags["coverage"]
    miss_names = flags["concepts_missing"]
    missed = [c for c in question["concepts"] if c["name"] in miss_names]
    fu = None
    if flags["misconceptions"]:
        ev = next((e["quote"] for e in evaluation["categories"]["technical_correctness"]["evidence"]), "")
        target = missed[0]["name"] if missed else question["topic"]
        text = (f'Let me probe that. You said: "{ev}". Walk me through the reasoning step by step, '
                f"and tell me how it relates to {target}.")
        fu = {"kind": "diagnostic", "text": text}
    elif cov < 0.5 and question.get("followup_vague"):
        fu = {"kind": "clarify", "text": question["followup_vague"]}
    if not fu:
        return None
    return {"id": question["id"] + "_fu", "category": question["category"], "topic": question["topic"],
            "difficulty": question["difficulty"], "text": fu["text"], "answer_type": question["answer_type"],
            "concepts": missed or question["concepts"], "reference": question["reference"],
            "misconceptions": [], "followup_vague": None, "tags": question.get("tags", []),
            "is_followup": True, "followup_kind": fu["kind"]}


def adjust_level(state: dict, evaluation: dict) -> str:
    """Return 'harder' / 'easier' / 'same' and update state['level'] when adaptive."""
    flags = evaluation["flags"]
    change = "same"
    if flags["dont_know"] or flags["coverage"] < 0.3:
        change = "easier"
    elif flags["coverage"] >= 0.75 and not flags["misconceptions"]:
        change = "harder"
    if state["adaptive"]:
        state["level"] = max(0, min(2, state["level"] + {"harder": 1, "easier": -1, "same": 0}[change]))
    for n in flags["concepts_covered"]:
        if n not in state["covered"]:
            state["covered"].append(n)
    return change
