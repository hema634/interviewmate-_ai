"""InterviewSessionService: persistence, controls, answering, retry, completion.

Every public method takes `user_id` and enforces ownership server-side.
"""
from __future__ import annotations

import json
import time

from ..web import HttpError
from . import adaptive, evaluation, retrieval
from .plan import build_plan

VALID_MODES = adaptive.MODES
VALID_EXP = ("fresher", "junior", "mid", "senior")
VALID_DIFF = ("easy", "medium", "hard", "adaptive")
VALID_INPUT = ("typed", "voice")


def _j(s):
    return json.loads(s) if s else None


class SessionService:
    def __init__(self, db, provider, clock=time.time):
        self.db, self.provider, self.clock = db, provider, clock

    # ---------- ownership ----------
    def _session(self, user_id: int, session_id: int):
        row = self.db.one("SELECT * FROM interview_sessions WHERE id=? AND user_id=?", (session_id, user_id))
        if not row:
            raise HttpError(404, "Session not found", "not_found")  # 404 (not 403) avoids revealing existence
        return row

    def _question(self, user_id: int, question_id: int):
        row = self.db.one(
            "SELECT q.*, s.user_id AS owner FROM interview_questions q JOIN interview_sessions s ON s.id=q.session_id WHERE q.id=?",
            (question_id,))
        if not row or row["owner"] != user_id:
            raise HttpError(404, "Question not found", "not_found")
        return row

    def _profile_job(self, session_row):
        p = self.db.one("SELECT profile_json FROM candidate_profiles WHERE id=?", (session_row["profile_id"],)) if session_row["profile_id"] else None
        j = self.db.one("SELECT job_json FROM job_descriptions WHERE id=?", (session_row["job_id"],)) if session_row["job_id"] else None
        return (_j(p["profile_json"]) if p else None), (_j(j["job_json"]) if j else None)

    # ---------- time ----------
    def _elapsed(self, state: dict) -> float:
        e = state["elapsed_base"]
        if not state["paused"] and state["last_resume_ts"] is not None:
            e += self.clock() - state["last_resume_ts"]
        return e

    def _save_state(self, session_id, state, status=None):
        elapsed = int(self._elapsed(state))
        if status:
            self.db.execute("UPDATE interview_sessions SET state_json=?, elapsed_seconds=?, status=? WHERE id=?",
                            (json.dumps(state), elapsed, status, session_id))
        else:
            self.db.execute("UPDATE interview_sessions SET state_json=?, elapsed_seconds=? WHERE id=?",
                            (json.dumps(state), elapsed, session_id))

    # ---------- create ----------
    def create(self, user_id: int, cfg: dict, is_demo: bool = False) -> dict:
        mode = cfg.get("mode")
        if mode not in VALID_MODES:
            raise HttpError(400, f"mode must be one of {', '.join(VALID_MODES)}", "bad_request")
        exp = cfg.get("experience_level", "fresher")
        diff = cfg.get("difficulty", "adaptive")
        inp = cfg.get("input_mode", "typed")
        if exp not in VALID_EXP or diff not in VALID_DIFF or inp not in VALID_INPUT:
            raise HttpError(400, "Invalid experience_level, difficulty, or input_mode", "bad_request")
        try:
            n = int(cfg.get("num_questions", 5)); dur = int(cfg.get("duration_minutes", 30))
        except (TypeError, ValueError):
            raise HttpError(400, "num_questions and duration_minutes must be integers", "bad_request")
        if not (1 <= n <= 20) or not (5 <= dur <= 90):
            raise HttpError(400, "num_questions must be 1-20 and duration_minutes 5-90", "bad_request")
        role = str(cfg.get("target_role", "")).strip()[:120] or "Engineer"
        lang = str(cfg.get("language", "en"))[:10]
        profile_id, job_id = cfg.get("profile_id"), cfg.get("job_id")
        profile = job = None
        if profile_id:
            row = self.db.one("SELECT * FROM candidate_profiles WHERE id=? AND user_id=?", (profile_id, user_id))
            if not row:
                raise HttpError(404, "Profile not found", "not_found")
            profile = _j(row["profile_json"])
        if job_id:
            row = self.db.one("SELECT * FROM job_descriptions WHERE id=? AND user_id=?", (job_id, user_id))
            if not row:
                raise HttpError(404, "Job description not found", "not_found")
            job = _j(row["job_json"])
        config = {"mode": mode, "difficulty": diff, "experience_level": exp, "target_role": role,
                  "project_name": str(cfg.get("project_name", "")).strip()[:100] or None}
        state = adaptive.initial_state(config, profile, job)
        state["last_resume_ts"] = self.clock()
        cur = self.db.execute(
            "INSERT INTO interview_sessions(user_id,profile_id,job_id,mode,target_role,experience_level,difficulty,language,input_mode,"
            "num_questions,duration_minutes,status,state_json,is_demo) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?)",
            (user_id, profile_id, job_id, mode, role, exp, diff, lang, inp, n, dur, "active", json.dumps(state), 1 if is_demo else 0))
        sid = cur.lastrowid
        q = self._ask_next_main(sid, config, state, profile, job)
        if not q:
            raise HttpError(422, "No questions available for this configuration", "no_questions")
        self._save_state(sid, state)
        return self.get(user_id, sid)

    def _insert_question(self, sid, qd: dict, seq: int, parent_id=None):
        rubric = {k: qd[k] for k in ("concepts", "misconceptions", "reference", "answer_type", "followup_vague", "tags")}
        rubric["bank_id"] = qd["id"]
        cur = self.db.execute(
            "INSERT INTO interview_questions(session_id,seq,text,topic,category,difficulty,is_followup,parent_question_id,rubric_json) VALUES (?,?,?,?,?,?,?,?,?)",
            (sid, seq, qd["text"], qd["topic"], qd["category"], qd["difficulty"], 1 if qd.get("is_followup") else 0, parent_id, json.dumps(rubric)))
        return cur.lastrowid

    def _next_seq(self, sid):
        r = self.db.one("SELECT COALESCE(MAX(seq),0)+1 AS n FROM interview_questions WHERE session_id=?", (sid,))
        return r["n"]

    def _ask_next_main(self, sid, config, state, profile, job):
        qd = adaptive.next_main_question(config, state, profile, job)
        if not qd:
            return None
        adaptive.advance_after_question(state, qd)
        qid = self._insert_question(sid, qd, self._next_seq(sid))
        state["asked_ids"].append(qd["id"])
        state["main_count"] += 1
        state["current_question_id"] = qid
        return qid

    # ---------- read ----------
    def _q_dict(self, row):
        r = _j(row["rubric_json"])
        return {"id": r["bank_id"], "category": row["category"], "topic": row["topic"], "difficulty": row["difficulty"], "text": row["text"],
                "answer_type": r["answer_type"], "concepts": r["concepts"], "misconceptions": [tuple(m) for m in r["misconceptions"]],
                "reference": r["reference"], "followup_vague": r["followup_vague"], "tags": r["tags"], "is_followup": bool(row["is_followup"])}

    def get(self, user_id: int, session_id: int) -> dict:
        s = self._session(user_id, session_id)
        state = _j(s["state_json"])
        qrows = self.db.all("SELECT * FROM interview_questions WHERE session_id=? ORDER BY seq", (session_id,))
        questions = []
        for q in qrows:
            answers = []
            for a in self.db.all("SELECT * FROM interview_answers WHERE question_id=? ORDER BY attempt", (q["id"],)):
                ev = self.db.one("SELECT * FROM evaluation_results WHERE answer_id=?", (a["id"],))
                answers.append({"id": a["id"], "attempt": a["attempt"], "text": a["text"], "source": a["source"],
                                "evaluation": ({**_j(ev["result_json"]), "evaluation_id": ev["id"]} if ev else None)})
            questions.append({"id": q["id"], "seq": q["seq"], "text": q["text"], "topic": q["topic"], "category": q["category"],
                              "difficulty": q["difficulty"], "is_followup": bool(q["is_followup"]), "status": q["status"], "answers": answers})
        elapsed = int(self._elapsed(state))
        remaining = max(0, s["duration_minutes"] * 60 - elapsed)
        current = next((q for q in questions if q["id"] == state.get("current_question_id")), None) if s["status"] != "completed" else None
        return {
            "id": s["id"], "mode": s["mode"], "target_role": s["target_role"], "experience_level": s["experience_level"],
            "difficulty": s["difficulty"], "language": s["language"], "input_mode": s["input_mode"], "status": s["status"],
            "is_demo": bool(s["is_demo"]), "num_questions": s["num_questions"], "duration_minutes": s["duration_minutes"],
            "elapsed_seconds": elapsed, "remaining_seconds": remaining, "overall_score": s["overall_score"],
            "created_at": s["created_at"], "completed_at": s["completed_at"],
            "progress": {"main_asked": state["main_count"], "of": s["num_questions"], "covered_concepts": state["covered"], "current_level": adaptive.LEVELS[state["level"]],
                         "skipped": state["skipped"], "repeats": state["repeats"], "project": state.get("project")},
            "current_question": current, "questions": questions,
            "language_note": None if s["language"] == "en" else "Question bank and offline evaluator are English-only; other languages require a configured LLM provider.",
        }

    def list(self, user_id: int) -> list[dict]:
        rows = self.db.all("SELECT id,mode,target_role,difficulty,status,overall_score,created_at,completed_at,is_demo,num_questions FROM interview_sessions WHERE user_id=? ORDER BY id DESC", (user_id,))
        return [dict(r) for r in rows]

    def delete(self, user_id: int, session_id: int):
        self._session(user_id, session_id)
        self.db.execute("DELETE FROM interview_sessions WHERE id=?", (session_id,))

    # ---------- answering ----------
    def answer(self, user_id: int, session_id: int, question_id: int, text: str, source="typed", duration=None, allow_external=False) -> dict:
        s = self._session(user_id, session_id)
        state = _j(s["state_json"])
        if s["status"] == "completed":
            raise HttpError(409, "Session is already completed", "completed")
        if s["status"] == "paused":
            raise HttpError(409, "Session is paused. Resume to continue.", "paused")
        qrow = self._question(user_id, question_id)
        if qrow["session_id"] != session_id or state["current_question_id"] != question_id:
            raise HttpError(409, "This is not the current question", "not_current")
        text = (text or "").strip()
        if not text:
            raise HttpError(400, "Answer text is required. (Use skip if you prefer not to answer.)", "empty_answer")
        if len(text) > 8000:
            raise HttpError(400, "Answer is too long (8000 characters max)", "too_long")
        q = self._q_dict(qrow)
        ev, aid = self._evaluate_and_store(user_id, s, q, question_id, 1, text, source, duration, allow_external)
        self.db.execute("UPDATE interview_questions SET status='answered' WHERE id=?", (question_id,))
        config = {"mode": s["mode"], "difficulty": s["difficulty"], "experience_level": s["experience_level"], "target_role": s["target_role"]}
        profile, job = self._profile_job(s)
        change = adaptive.adjust_level(state, ev)
        used = state["followups_used"].get(str(question_id), 0)
        fu = adaptive.decide_followup(q, ev, state, followups_allowed=(not q["is_followup"]) and used < 1 and self._remaining(s, state) > 90)
        next_info = {"type": None}
        if fu:
            state["followups_used"][str(question_id)] = used + 1
            nq = self._insert_question(session_id, fu, self._next_seq(session_id), parent_id=question_id)
            state["current_question_id"] = nq
            next_info = {"type": "followup", "kind": fu["followup_kind"], "difficulty_change": change}
        else:
            nxt = self._advance(s, config, state, profile, job)
            next_info = {"type": "question" if nxt else "complete", "difficulty_change": change}
        self._save_state(session_id, state, status=("completed" if next_info["type"] == "complete" else None))
        if next_info["type"] == "complete":
            self._finalize(session_id)
        return {"evaluation": ev, "answer_id": aid, "next": next_info, "session": self.get(user_id, session_id)}

    def _remaining(self, s, state):
        return s["duration_minutes"] * 60 - self._elapsed(state)

    def _advance(self, s, config, state, profile, job) -> int | None:
        if state["main_count"] >= s["num_questions"] or self._remaining(s, state) <= 0:
            return None
        qid = self._ask_next_main(s["id"], config, state, profile, job)
        return qid

    def _evaluate_and_store(self, user_id, s, q, question_id, attempt, text, source, duration, allow_external):
        user = self.db.one("SELECT consent_ai_processing FROM users WHERE id=?", (user_id,))
        ext = bool(allow_external and user and user["consent_ai_processing"])
        ctx = retrieval.retrieve(q["text"] + " " + text, retrieval.reference_chunks(), k=2) if ext else []
        ev = evaluation.evaluate(self.provider, q, text, source, allow_external=ext, context_chunks=ctx)
        cur = self.db.execute("INSERT INTO interview_answers(question_id,attempt,text,source,duration_seconds) VALUES (?,?,?,?,?)",
                              (question_id, attempt, text, source, duration))
        aid = cur.lastrowid
        er = self.db.execute("INSERT INTO evaluation_results(answer_id,total_score,result_json,evaluator) VALUES (?,?,?,?)",
                             (aid, ev["total"], json.dumps(ev), ev["evaluator"]))
        ev["evaluation_id"] = er.lastrowid
        return ev, aid

    # ---------- controls ----------
    def control(self, user_id: int, session_id: int, action: str) -> dict:
        s = self._session(user_id, session_id)
        state = _j(s["state_json"])
        status = s["status"]
        if status == "completed" and action != "end":
            raise HttpError(409, "Session is already completed", "completed")
        config = {"mode": s["mode"], "difficulty": s["difficulty"], "experience_level": s["experience_level"], "target_role": s["target_role"]}
        if action == "pause":
            if status != "active":
                raise HttpError(409, "Session is not active", "bad_state")
            state["elapsed_base"] = self._elapsed(state); state["paused"] = True; state["last_resume_ts"] = None
            self._save_state(session_id, state, status="paused")
        elif action == "resume":
            if status != "paused":
                raise HttpError(409, "Session is not paused", "bad_state")
            state["paused"] = False; state["last_resume_ts"] = self.clock()
            self._save_state(session_id, state, status="active")
        elif action == "repeat":
            if status == "paused":
                raise HttpError(409, "Session is paused", "paused")
            state["repeats"] += 1
            self._save_state(session_id, state)
        elif action == "skip":
            if status == "paused":
                raise HttpError(409, "Session is paused", "paused")
            cur = state["current_question_id"]
            self.db.execute("UPDATE interview_questions SET status='skipped' WHERE id=?", (cur,))
            state["skipped"] += 1
            profile, job = self._profile_job(s)
            nxt = self._advance(s, config, state, profile, job)
            self._save_state(session_id, state, status=None if nxt else "completed")
            if not nxt:
                self._finalize(session_id)
        elif action == "end":
            if status != "completed":
                if status == "active":
                    state["elapsed_base"] = self._elapsed(state)
                state["paused"] = True; state["last_resume_ts"] = None
                self._save_state(session_id, state, status="completed")
                self._finalize(session_id)
        else:
            raise HttpError(400, "action must be pause, resume, repeat, skip, or end", "bad_request")
        return self.get(user_id, session_id)

    # ---------- completion ----------
    def _finalize(self, session_id: int):
        rows = self.db.all(
            "SELECT e.total_score FROM evaluation_results e JOIN interview_answers a ON a.id=e.answer_id "
            "JOIN interview_questions q ON q.id=a.question_id WHERE q.session_id=? AND a.attempt=1 AND e.total_score IS NOT NULL", (session_id,))
        scores = [r["total_score"] for r in rows]
        overall = round(sum(scores) / len(scores), 1) if scores else None
        self.db.execute("UPDATE interview_sessions SET overall_score=?, completed_at=CURRENT_TIMESTAMP WHERE id=?", (overall, session_id))
        plan = build_plan(self._collect_for_plan(session_id))
        self.db.execute("INSERT OR REPLACE INTO improvement_plans(session_id,plan_json) VALUES (?,?)", (session_id, json.dumps(plan)))

    def _collect_for_plan(self, session_id: int) -> dict:
        s = self.db.one("SELECT * FROM interview_sessions WHERE id=?", (session_id,))
        items = []
        for q in self.db.all("SELECT * FROM interview_questions WHERE session_id=? ORDER BY seq", (session_id,)):
            a = self.db.one("SELECT * FROM interview_answers WHERE question_id=? AND attempt=1", (q["id"],))
            if not a:
                continue
            ev = self.db.one("SELECT result_json FROM evaluation_results WHERE answer_id=?", (a["id"],))
            if ev:
                items.append({"question": q["text"], "topic": q["topic"], "category": q["category"], "evaluation": _j(ev["result_json"]), "question_id": q["id"]})
        return {"mode": s["mode"], "role": s["target_role"], "items": items}

    # ---------- retry ----------
    def retry(self, user_id: int, session_id: int, question_id: int, text: str, source="typed", allow_external=False) -> dict:
        s = self._session(user_id, session_id)
        if s["status"] == "paused":
            raise HttpError(409, "Session is paused", "paused")
        qrow = self._question(user_id, question_id)
        if qrow["session_id"] != session_id:
            raise HttpError(404, "Question not found", "not_found")
        text = (text or "").strip()
        if not text:
            raise HttpError(400, "Revised answer text is required", "empty_answer")
        first = self.db.one("SELECT * FROM interview_answers WHERE question_id=? AND attempt=1", (question_id,))
        if not first:
            raise HttpError(409, "Answer the question once before retrying it", "no_original")
        n = self.db.one("SELECT MAX(attempt) AS m FROM interview_answers WHERE question_id=?", (question_id,))["m"] + 1
        q = self._q_dict(qrow)
        ev2, aid2 = self._evaluate_and_store(user_id, s, q, question_id, n, text, source, None, allow_external)
        ev1 = _j(self.db.one("SELECT result_json FROM evaluation_results WHERE answer_id=?", (first["id"],))["result_json"])
        comp = compare_attempts(first["text"], ev1, text, ev2)
        self.db.execute("INSERT INTO retry_attempts(question_id,original_answer_id,revised_answer_id,comparison_json) VALUES (?,?,?,?)",
                        (question_id, first["id"], aid2, json.dumps(comp)))
        return {"comparison": comp, "revised_evaluation": ev2, "attempt": n}

    def retries(self, user_id: int, session_id: int) -> list[dict]:
        self._session(user_id, session_id)
        rows = self.db.all("SELECT r.*, q.text AS qtext FROM retry_attempts r JOIN interview_questions q ON q.id=r.question_id WHERE q.session_id=? ORDER BY r.id", (session_id,))
        out = []
        for r in rows:
            a1 = self.db.one("SELECT text FROM interview_answers WHERE id=?", (r["original_answer_id"],))
            a2 = self.db.one("SELECT text FROM interview_answers WHERE id=?", (r["revised_answer_id"],))
            out.append({"id": r["id"], "question_id": r["question_id"], "question": r["qtext"], "original_answer": a1["text"],
                        "revised_answer": a2["text"], "comparison": _j(r["comparison_json"])})
        return out


def compare_attempts(text1, ev1, text2, ev2) -> dict:
    cats = {}
    for k, label in __import__("interviewmate.scoring", fromlist=["x"]).CATEGORY_LABELS.items():
        s1, s2 = ev1["categories"][k]["score"], ev2["categories"][k]["score"]
        cats[k] = {"label": label, "first": s1, "second": s2, "change": (s2 - s1) if (s1 is not None and s2 is not None) else None}
    t1, t2 = ev1["total"], ev2["total"]
    f1, f2 = ev1["flags"], ev2["flags"]
    new_concepts = [c for c in f2["concepts_covered"] if c not in f1["concepts_covered"]]
    corrected = [m for m in f1["misconceptions"] if m not in f2["misconceptions"]]
    q1 = {e["quote"] for c in ev1["categories"].values() for e in c["evidence"]}
    new_evidence = sorted({e["quote"] for c in ev2["categories"].values() for e in c["evidence"]} - q1)[:5]
    wc1, wc2 = len(text1.split()), len(text2.split())
    comm = cats["communication"]["change"]
    clarity = ("Communication score changed by %+d." % comm) if comm is not None else "Communication could not be compared (insufficient evidence in one attempt)."
    return {
        "score_change": (round(t2 - t1, 1) if (t1 is not None and t2 is not None) else None),
        "first_total": t1, "second_total": t2, "categories": cats,
        "technical_concepts_now_covered": new_concepts, "misconceptions_corrected": corrected,
        "previously_missing_now_present": new_concepts,
        "new_evidence_quotes": new_evidence,
        "clarity_note": clarity + f" Length {wc1} → {wc2} words.",
        "remaining_gaps": f2["concepts_missing"],
        "disclaimer": "Score change = second attempt minus first attempt. Improvement here does not guarantee a real interviewer would score you the same.",
    }
