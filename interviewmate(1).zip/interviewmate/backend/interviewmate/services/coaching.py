"""Coaching actions and coding review. Everything here is labelled as an EXAMPLE or AI suggestion;
model answers are never presented as the candidate's own experience."""
from __future__ import annotations

import ast
import re

from .evaluation import _sentences, analyze_concepts

EXAMPLE_LABEL = "EXAMPLE answer — illustrative only, not a claim about your own experience. Do not claim skills or achievements you do not have."
ACTIONS = ("why_weak", "better_answer", "next_followup", "shorter_clearer", "explain_concept", "practice_example")


def coach(action: str, question: dict, answer: str, evaluation: dict) -> dict:
    an = analyze_concepts(question, answer)
    misses, hits = an["misses"], an["hits"]
    if action == "why_weak":
        lines = [f"Not yet demonstrated — {c['name']}: {c['teach']}" for c in misses]
        lines += [f"Possible incorrect claim: {m['correction']}" for m in an["misconceptions"]]
        for k, c in evaluation["categories"].items():
            if c["status"] == "scored" and c["score"] < 60:
                lines.append(f"{k.replace('_', ' ').title()} scored {c['score']}: {c['suggestion']}")
        return {"title": "Why your answer scored lower", "label": "AI-generated suggestions", "items": lines or ["No major weaknesses found against this rubric."]}
    if action == "better_answer":
        if question["answer_type"] == "technical":
            body = " ".join(c["teach"] for c in question["concepts"])
            return {"title": "A stronger answer (example)", "label": EXAMPLE_LABEL, "text": body}
        if question["id"] in ("hr_team", "hr_conflict", "hr_leader", "hr_adapt"):
            return {"title": "A stronger answer (STAR template)", "label": EXAMPLE_LABEL,
                    "text": "Situation: [one sentence about your real situation]. Task: [your specific responsibility]. Action: [what YOU did, two or three concrete steps, using 'I']. "
                            "Result: [the real outcome, with a number if you honestly have one]. Lesson: [one sentence]."}
        return {"title": "A stronger answer (template)", "label": EXAMPLE_LABEL,
                "text": " ".join(f"[{c['name']}: {c['teach']}]" for c in question["concepts"]) + " Fill the brackets with your real details only."}
    if action == "next_followup":
        from .adaptive import decide_followup
        fu = decide_followup(question, {**evaluation}, {}, True)
        return {"title": "A follow-up you may get", "label": "AI-generated prediction; real interviewers vary.",
                "text": fu["text"] if fu else (question.get("followup_vague") or "A deeper question on the same topic, e.g. about trade-offs or a real example.")}
    if action == "shorter_clearer":
        keep = [answer[s:e].strip() for s, e in _sentences(answer) if any(h["quote"] and answer[s:e].strip() and h["quote"] in answer[s:e] for h in hits)]
        sents = keep or [answer[s:e].strip() for s, e in _sentences(answer)][:2]
        return {"title": "Shorter version of YOUR answer", "label": "Built only from sentences you wrote; nothing was added.", "text": " ".join(sents)}
    if action == "explain_concept":
        if not misses:
            return {"title": "Concept review", "label": "AI-generated", "items": ["You covered every rubric concept."], "reference": question["reference"]}
        return {"title": "Missing concept", "label": "From approved reference notes",
                "items": [f"{c['name']}: {c['teach']}" for c in misses[:3]], "reference": question["reference"]}
    if action == "practice_example":
        target = misses[0]["name"] if misses else question["topic"]
        return {"title": "Practice prompt", "label": "AI-generated practice task",
                "text": f"In 60-90 seconds, explain '{target}' as it relates to {question['topic']}. Include one example and one limitation. Then record yourself and re-check against: {question['reference']}"}
    raise ValueError("unknown action")


# ---------------- coding review (static; code is NEVER executed) ----------------
PROBLEMS = [
    {"id": "two_sum", "title": "Two Sum", "statement": "Given a list of integers and a target, return indices of two numbers that add up to the target.",
     "expected_complexity": "O(n) time, O(n) space (hash map)", "edge_cases": ["empty list", "no solution", "duplicates", "negative numbers"]},
    {"id": "valid_parens", "title": "Valid Parentheses", "statement": "Given a string of brackets ()[]{}, decide whether it is valid.",
     "expected_complexity": "O(n) time, O(n) space (stack)", "edge_cases": ["empty string", "single bracket", "mismatched types", "extra closers"]},
    {"id": "reverse_words", "title": "Reverse Words", "statement": "Reverse the order of words in a sentence.",
     "expected_complexity": "O(n) time, O(n) space", "edge_cases": ["empty string", "multiple spaces", "single word"]},
]
LANGS = ("python", "javascript", "java", "cpp")


def review_code(language: str, problem_id: str, code: str, explanation: str) -> dict:
    prob = next((p for p in PROBLEMS if p["id"] == problem_id), None)
    if language not in LANGS or not prob:
        raise ValueError("unsupported language or problem")
    notes, syntax_ok, depth = [], None, None
    if language == "python":
        try:
            tree = ast.parse(code)
            syntax_ok = True
            depth = _loop_depth(tree)
        except SyntaxError as e:
            syntax_ok = False
            notes.append(f"Syntax error at line {e.lineno}: {e.msg}")
    else:
        syntax_ok = all(code.count(a) == code.count(b) for a, b in ("()", "{}", "[]"))
        if not syntax_ok:
            notes.append("Unbalanced brackets detected.")
        depth = max([len(re.findall(r"\b(for|while)\b", code))] + [0])
        depth = 2 if depth >= 2 and re.search(r"(for|while)[^{]*\{[^}]*(for|while)", code, re.S) else min(depth, 1)
    ex = (explanation or "").lower()
    code_l = code.lower()
    checks = {
        "reasoning": any(w in ex for w in ("hash", "map", "dict", "stack", "two pointer", "approach", "because", "iterate", "sort", "dynamic")),
        "complexity_stated": bool(re.search(r"o\(", ex)),
        "edge_cases_mentioned": any(w in ex for w in ("empty", "edge", "duplicate", "negative", "null", "none", "single")),
        "edge_cases_in_code": bool(re.search(r"(not \w+|len\(.*\) *[=<]=? *[01]|== *(0|null|none|\"\")|is none|\.empty\(\)|\.length *(===|==) *0)", code_l)),
        "tests_mentioned": any(w in ex or w in code_l for w in ("test", "assert", "example", "expected")),
    }
    complexity_note = None
    if depth is not None:
        est = {0: "roughly O(n) or better", 1: "roughly O(n) (single loop level)", 2: "roughly O(n^2) (nested loops)"}.get(min(depth, 2), "O(n^k), deeply nested loops")
        complexity_note = f"Static estimate from loop nesting: {est}. Expected for this problem: {prob['expected_complexity']}."
    scores = {
        "algorithmic_reasoning": 70 if checks["reasoning"] else 30,
        "correctness": (None if syntax_ok is None else (0 if not syntax_ok else 50)),
        "edge_cases": 30 * checks["edge_cases_mentioned"] + 40 * checks["edge_cases_in_code"] + 30 * (1 if (checks["edge_cases_mentioned"] and checks["edge_cases_in_code"]) else 0),
        "testing": 80 if checks["tests_mentioned"] else 20,
        "complexity": 80 if checks["complexity_stated"] else 25,
    }
    return {
        "execution": "not_run",
        "limitations": ["Code was NOT executed: no isolated sandbox is configured, so untrusted code is never run on the application server.",
                        "'correctness' reflects syntax/structure checks only, capped at 50; it cannot confirm the program returns correct outputs.",
                        "Reasoning, edge-case, and testing scores come from your explanation text and simple code patterns."],
        "problem": prob, "language": language, "syntax_ok": syntax_ok, "checks": checks, "scores": scores,
        "complexity_note": complexity_note, "notes": notes,
        "suggestions": ["State the time and space complexity explicitly." if not checks["complexity_stated"] else "Good: complexity stated.",
                        "Handle: " + ", ".join(prob["edge_cases"]) + ".",
                        "Add 2-3 test cases (including an edge case) and walk through them aloud."],
        "label": "AI-generated static review",
    }


def _loop_depth(tree) -> int:
    def walk(node, d):
        best = d
        for child in ast.iter_child_nodes(node):
            nd = d + 1 if isinstance(child, (ast.For, ast.While, ast.ListComp, ast.GeneratorExp, ast.SetComp, ast.DictComp)) else d
            best = max(best, walk(child, nd))
        return best
    return walk(tree, 0)
