"""Tiny dependency-free PDF writer (text only, Helvetica, A4, auto-pagination, UTF-8 -> Latin-1 safe)."""
from __future__ import annotations

import textwrap

PAGE_W, PAGE_H, MARGIN = 595, 842, 50


def _esc(s: str) -> str:
    s = s.replace("–", "-").replace("—", "-").replace("’", "'").replace("‘", "'").replace("“", '"').replace("”", '"').replace("•", "-").replace("→", "->").replace("×", "x").replace("≤", "<=").replace("≥", ">=").replace("π", "pi").replace("²", "2")
    s = s.encode("latin-1", "replace").decode("latin-1")
    return s.replace("\\", "\\\\").replace("(", "\\(").replace(")", "\\)")


def make_pdf(blocks: list[tuple[str, str]]) -> bytes:
    """blocks: (style, text) with style in h1,h2,p,b (bullet),q (quote),n (note)."""
    styles = {"h1": (18, 22, 70), "h2": (13, 18, 85), "p": (10, 14, 95), "b": (10, 14, 90), "q": (9, 13, 88), "n": (8.5, 12, 100)}
    pages, cur, y = [], [], PAGE_H - MARGIN
    for style, text in blocks:
        size, lead, width = styles.get(style, styles["p"])
        indent = 14 if style in ("b", "q") else 0
        prefix = "- " if style == "b" else ('"' if style == "q" else "")
        lines = []
        for para in (text or " ").split("\n"):
            wrapped = textwrap.wrap(para, width=width - (3 if indent else 0)) or [""]
            lines += wrapped
        if style in ("h1", "h2"):
            y -= 6
        for i, line in enumerate(lines):
            if y < MARGIN + lead:
                pages.append(cur); cur, y = [], PAGE_H - MARGIN
            txt = (prefix if i == 0 else "") + line + ('"' if style == "q" and i == len(lines) - 1 else "")
            font = "F2" if style in ("h1", "h2") else ("F3" if style in ("q", "n") else "F1")
            cur.append(f"BT /{font} {size} Tf {MARGIN + indent} {y:.1f} Td ({_esc(txt)}) Tj ET")
            y -= lead
        y -= 3
    pages.append(cur)
    objs = []
    def add(b):
        objs.append(b); return len(objs)
    add(b"<< /Type /Catalog /Pages 2 0 R >>")
    add(b"")  # pages placeholder
    f1 = add(b"<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica /Encoding /WinAnsiEncoding >>")
    f2 = add(b"<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica-Bold /Encoding /WinAnsiEncoding >>")
    f3 = add(b"<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica-Oblique /Encoding /WinAnsiEncoding >>")
    kids = []
    for p in pages:
        stream = "\n".join(p).encode("latin-1", "replace")
        cid = add(b"<< /Length %d >>\nstream\n" % len(stream) + stream + b"\nendstream")
        pid = add(f"<< /Type /Page /Parent 2 0 R /MediaBox [0 0 {PAGE_W} {PAGE_H}] /Resources << /Font << /F1 {f1} 0 R /F2 {f2} 0 R /F3 {f3} 0 R >> >> /Contents {cid} 0 R >>".encode())
        kids.append(pid)
    objs[1] = f"<< /Type /Pages /Kids [{' '.join(f'{k} 0 R' for k in kids)}] /Count {len(kids)} >>".encode()
    out = bytearray(b"%PDF-1.4\n")
    offsets = []
    for i, o in enumerate(objs, start=1):
        offsets.append(len(out))
        out += f"{i} 0 obj\n".encode() + o + b"\nendobj\n"
    xref = len(out)
    out += f"xref\n0 {len(objs)+1}\n0000000000 65535 f \n".encode()
    for off in offsets:
        out += f"{off:010d} 00000 n \n".encode()
    out += f"trailer\n<< /Size {len(objs)+1} /Root 1 0 R >>\nstartxref\n{xref}\n%%EOF\n".encode()
    return bytes(out)
