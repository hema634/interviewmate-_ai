"""RetrievalService: chunk + rank resume / job description / approved reference notes.

Retrieval is lexical (BM25-style TF-IDF) so it works offline with no embeddings service.
The interface (`retrieve`) is stable, so a vector-embedding backend can replace it later.
"""
from __future__ import annotations

import math
import re
from collections import Counter

from ..data.bank import QUESTIONS

STOP = set("a an the and or of to in for with on at by is are was were be been it this that as from i my we our you your their his her its".split())


def tokens(text: str) -> list[str]:
    return [t for t in re.findall(r"[a-z0-9+#.]+", text.lower()) if t not in STOP and len(t) > 1]


def chunk(text: str, source: str, size: int = 60, overlap: int = 15) -> list[dict]:
    words = text.split()
    out, i = [], 0
    while i < len(words):
        out.append({"source": source, "text": " ".join(words[i:i + size])})
        if i + size >= len(words):
            break
        i += size - overlap
    return out


def reference_chunks() -> list[dict]:
    return [{"source": "reference", "text": f"{q['topic']}: {q['reference']}", "qid": q["id"]} for q in QUESTIONS]


def retrieve(query: str, chunks: list[dict], k: int = 3) -> list[dict]:
    qt = tokens(query)
    if not qt or not chunks:
        return []
    docs = [Counter(tokens(c["text"])) for c in chunks]
    n = len(docs)
    df = Counter(t for d in docs for t in d)
    avg = sum(sum(d.values()) for d in docs) / n or 1
    scored = []
    for c, d in zip(chunks, docs):
        dl = sum(d.values()) or 1
        s = 0.0
        for t in set(qt):
            if t in d:
                idf = math.log(1 + (n - df[t] + 0.5) / (df[t] + 0.5))
                s += idf * d[t] * 2.2 / (d[t] + 1.2 * (0.25 + 0.75 * dl / avg))
        if s > 0:
            scored.append((s, c))
    scored.sort(key=lambda x: -x[0])
    return [dict(c, score=round(s, 3)) for s, c in scored[:k]]
