"""ProgressAnalyticsService: trends, weak areas, next-practice recommendation."""
from __future__ import annotations

import json

from ..scoring import CATEGORY_LABELS

MODE_FOR_TOPIC = {"hr": "hr", "software": "software", "electrical": "electrical", "project": "project"}


def progress(db, user_id: int) -> dict:
    sessions = db.all("SELECT id,mode,overall_score,created_at,is_demo FROM interview_sessions WHERE user_id=? AND status='completed' ORDER BY id", (user_id,))
    trend, cat_trend = [], []
    topic_scores: dict[str, list[float]] = {}
    category_scores: dict[str, list[float]] = {}
    cat_ins = 0
    for s in sessions:
        rows = db.all("SELECT q.topic,q.category,e.result_json FROM interview_questions q JOIN interview_answers a ON a.question_id=q.id AND a.attempt=1 "
                      "JOIN evaluation_results e ON e.answer_id=a.id WHERE q.session_id=?", (s["id"],))
        sums, cnt = {}, {}
        for r in rows:
            res = json.loads(r["result_json"])
            if res["total"] is not None:
                topic_scores.setdefault(r["topic"], []).append(res["total"])
                category_scores.setdefault(r["category"], []).append(res["total"])
            for k, c in res["categories"].items():
                if c["status"] == "scored":
                    sums[k] = sums.get(k, 0) + c["score"]; cnt[k] = cnt.get(k, 0) + 1
                else:
                    cat_ins += 1
        trend.append({"session_id": s["id"], "date": s["created_at"], "mode": s["mode"], "score": s["overall_score"], "is_demo": bool(s["is_demo"])})
        cat_trend.append({"session_id": s["id"], **{k: (round(sums[k] / cnt[k], 1) if k in cnt else None) for k in CATEGORY_LABELS}})
    weak = sorted(({"topic": t, "average": round(sum(v) / len(v), 1), "n": len(v)} for t, v in topic_scores.items()), key=lambda x: x["average"])
    scored = [t["score"] for t in trend if t["score"] is not None]
    recent_avg = round(sum(scored[-3:]) / len(scored[-3:]), 1) if scored else None
    change = round(scored[-1] - scored[0], 1) if len(scored) >= 2 else None
    cat_avgs = {}
    for k in CATEGORY_LABELS:
        vals = [c[k] for c in cat_trend if c[k] is not None]
        cat_avgs[k] = round(sum(vals) / len(vals), 1) if vals else None
    rec = recommend(weak, category_scores, cat_avgs, sessions)
    return {"sessions_completed": len(sessions), "trend": trend, "category_trend": cat_trend, "category_averages": cat_avgs,
            "average_score": round(sum(scored) / len(scored), 1) if scored else None, "recent_average": recent_avg,
            "change_first_to_last": change, "weak_areas": weak[:6], "recommendation": rec,
            "note": "Demo sessions are included and labelled in the trend. Scores are practice indicators, not hiring predictions."}


def recommend(weak, category_scores, cat_avgs, sessions) -> dict:
    if not sessions:
        return {"mode": "mixed", "reason": "Start with a mixed mock interview to establish your baseline.", "focus": None}
    comm = cat_avgs.get("communication"); struct = cat_avgs.get("structure")
    if weak and weak[0]["average"] < 70:
        w = weak[0]
        cat = next((c for c, vals in category_scores.items() if w["topic"] and c), "mixed")
        topic_cat = None
        return {"mode": _mode_for_topic(w["topic"]), "reason": f"Your lowest average is in {w['topic']} ({w['average']}).", "focus": w["topic"]}
    if (comm is not None and comm < 70) or (struct is not None and struct < 70):
        return {"mode": "hr", "reason": "Communication/structure averages are below 70; practice behavioral answers with STAR.", "focus": "communication"}
    return {"mode": "mixed", "reason": "Scores are steady; try a harder mixed session to stretch yourself.", "focus": None}


def _mode_for_topic(topic: str) -> str:
    t = topic.lower()
    if any(x in t for x in ("self", "strength", "team", "conflict", "leader", "adapt", "career")):
        return "hr"
    if any(x in t for x in ("object", "data struct", "algorithm", "database", "api", "system design", "programming")):
        return "software"
    if any(x in t for x in ("problem", "motivation", "architecture", "component", "calculation", "testing", "limitation", "cost", "future")):
        return "project"
    return "electrical"
