"""Seven-day improvement plan generated from observed evaluation results (AI-generated suggestions)."""
from __future__ import annotations

from ..data.bank import QUESTIONS

_QBANK = {q["id"]: q for q in QUESTIONS}
CATEGORY_LABELS = {"technical_correctness": "Technical correctness", "communication": "Communication",
                   "structure": "Answer structure", "relevance": "Relevance", "improvement_potential": "Improvement potential"}


def _gap_topics(items):
    gaps = {}
    for it in items:
        flags = it["evaluation"]["flags"]
        bank = _QBANK.get((it["evaluation"].get("question_id") or "").replace("_fu", ""))
        for name in flags["concepts_missing"]:
            teach = next((c["teach"] for c in (bank["concepts"] if bank else []) if c["name"] == name), None)
            key = (it["topic"], name)
            gaps[key] = {"topic": it["topic"], "concept": name, "teach": teach or f"Review {name}.",
                         "score": it["evaluation"]["total"] if it["evaluation"]["total"] is not None else 0}
    return sorted(gaps.values(), key=lambda g: g["score"])


def category_averages(items):
    sums, cnt, insufficient = {}, {}, {}
    for it in items:
        for k, c in it["evaluation"]["categories"].items():
            if c["status"] == "scored":
                sums[k] = sums.get(k, 0) + c["score"]; cnt[k] = cnt.get(k, 0) + 1
            else:
                insufficient[k] = insufficient.get(k, 0) + 1
    return {k: {"average": round(sums[k] / cnt[k], 1), "n": cnt[k], "insufficient": insufficient.get(k, 0)} for k in sums} | {
        k: {"average": None, "n": 0, "insufficient": v} for k, v in insufficient.items() if k not in sums}


def build_plan(data: dict) -> dict:
    items = data["items"]
    gaps = _gap_topics(items)
    avgs = category_averages(items)
    weakest_cat = min((k for k, v in avgs.items() if v["average"] is not None and k != "improvement_potential"),
                      key=lambda k: avgs[k]["average"], default=None)
    weak_items = sorted([i for i in items if i["evaluation"]["total"] is not None], key=lambda i: i["evaluation"]["total"])[:2]
    g = gaps + [{"topic": "Core fundamentals", "concept": "key concepts for your role", "teach": "Revise the fundamentals of your target role.", "score": 0}] * 3
    days = []
    def day(n, topic, tasks, minutes, criteria):
        days.append({"day": n, "topic": topic, "tasks": tasks, "minutes": minutes, "completion_criteria": criteria})
    day(1, f"{g[0]['topic']}: {g[0]['concept']}",
        [g[0]["teach"], "Write a 5-sentence explanation in your own words.", "Re-answer the original question out loud once."], 45,
        "You can explain the concept without notes and name one real example.")
    day(2, f"{g[1]['topic']}: {g[1]['concept']}",
        [g[1]["teach"], "Draw or list the key steps/formulae on one page."], 40, "One-page summary done; self-quiz 3 questions correctly.")
    wc = CATEGORY_LABELS.get(weakest_cat, "Communication")
    day(3, f"Communication drill — focus: {wc}",
        ["Answer 3 questions aloud in 60-90 seconds each: claim, reason, example.", "Record yourself and listen once; note unclear sentences."], 40,
        "Each answer has a one-sentence opening and one concrete example.")
    day(4, f"{g[2]['topic']}: {g[2]['concept']}",
        [g[2]["teach"], "Solve or explain two small practice problems on it."], 45, "Both practice items answered correctly without looking.")
    retry_q = weak_items[0]["question"] if weak_items else "your weakest question"
    day(5, "Retry your weakest questions",
        [f'Use Retry mode on: "{retry_q}"', "Add the missing concepts and a real, honest example from your own experience."], 40,
        "Retry score improves by at least 10 points, or reaches 70 or above.")
    day(6, "Full mock interview",
        [f"Run a new {data['mode']} interview with the same settings.", "Do not look at notes during the session."], 45,
        "Overall score is at least 5 points above this session, and no category is 'insufficient evidence' due to very short answers.")
    day(7, "Review and plan next steps",
        ["Compare Day 6 with this session in Progress Analytics.", "List the two topics still weakest and schedule them."], 30,
        "Written list of next two topics with dates.")
    return {"label": "AI-generated suggestions based on your observed answers; adjust to your own schedule.",
            "total_minutes": sum(d["minutes"] for d in days), "days": days,
            "study_topics": list({(x["topic"], x["concept"]): {"topic": x["topic"], "concept": x["concept"]} for x in gaps}.values())[:6]}
