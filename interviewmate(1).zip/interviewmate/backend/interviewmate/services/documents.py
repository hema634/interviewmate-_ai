"""DocumentParser + CandidateProfileService.

Treats uploaded text strictly as data. Extraction is rule-based and conservative: anything not
found is left empty/unknown rather than guessed. Injection-looking lines are flagged and removed
from the text that can ever reach a prompt.
"""
from __future__ import annotations

import io
import re
import zipfile

from ..web import HttpError

ALLOWED_EXT = {".pdf", ".docx", ".txt"}
MAGIC = {".pdf": b"%PDF", ".docx": b"PK"}

INJECTION_PATTERNS = [
    r"ignore (all |any )?(previous|prior|above) (instructions|prompts)",
    r"disregard (the )?(system|previous) (prompt|instructions)",
    r"you are now\b", r"act as (an? )?(?!engineer|developer)",
    r"reveal (your|the) (system )?prompt", r"give (me|this candidate) (a )?(full|perfect|100)",
    r"score (this|the) (candidate|answer) (as )?(100|perfect|full)",
]
INJECTION_RE = re.compile("|".join(INJECTION_PATTERNS), re.I)


def extract_text(filename: str, data: bytes, max_bytes: int) -> str:
    name = (filename or "").lower()
    ext = "." + name.rsplit(".", 1)[-1] if "." in name else ""
    if ext not in ALLOWED_EXT:
        raise HttpError(415, "Unsupported file type. Upload a PDF, DOCX, or TXT file.", "unsupported_type")
    if len(data) == 0:
        raise HttpError(400, "The file is empty.", "empty_file")
    if len(data) > max_bytes:
        raise HttpError(413, f"File too large (limit {max_bytes // (1024*1024)} MB).", "too_large")
    if ext in MAGIC and not data.startswith(MAGIC[ext]):
        raise HttpError(400, f"File content does not look like a valid {ext[1:].upper()}.", "bad_content")
    try:
        if ext == ".txt":
            text = data.decode("utf-8", "replace")
        elif ext == ".pdf":
            from pypdf import PdfReader
            reader = PdfReader(io.BytesIO(data))
            if reader.is_encrypted:
                raise HttpError(400, "Encrypted PDFs are not supported.", "encrypted")
            text = "\n".join((p.extract_text() or "") for p in reader.pages[:30])
        else:
            if not zipfile.is_zipfile(io.BytesIO(data)):
                raise HttpError(400, "Invalid DOCX file.", "bad_content")
            with zipfile.ZipFile(io.BytesIO(data)) as z:
                if sum(i.file_size for i in z.infolist()) > 50 * 1024 * 1024:
                    raise HttpError(400, "DOCX expands too large.", "zip_bomb")
            import docx
            d = docx.Document(io.BytesIO(data))
            parts = [p.text for p in d.paragraphs]
            for t in d.tables:
                for row in t.rows:
                    parts.append(" | ".join(c.text for c in row.cells))
            text = "\n".join(parts)
    except HttpError:
        raise
    except Exception:
        raise HttpError(400, "Could not read this file. Try a TXT or a different export.", "parse_failed")
    text = re.sub(r"[\x00-\x08\x0b\x0c\x0e-\x1f]", " ", text).strip()
    if len(text) < 20:
        raise HttpError(422, "No readable text found (scanned image PDFs are not supported without OCR).", "no_text")
    return text[:60000]


def sanitize_untrusted(text: str) -> tuple[str, list[str]]:
    """Drop lines that look like instructions to the AI; report them. Content stays data only."""
    kept, flagged = [], []
    for line in text.splitlines():
        if INJECTION_RE.search(line):
            flagged.append(line.strip()[:200])
        else:
            kept.append(line)
    return "\n".join(kept), flagged


# ---------------- skill vocabularies (extraction only matches what is literally present) ----------------
TECH_SKILLS = [
    "python", "java", "c++", "c#", "javascript", "typescript", "react", "node.js", "sql", "mysql", "postgresql",
    "mongodb", "fastapi", "django", "flask", "html", "css", "git", "docker", "linux", "rest api", "aws", "azure",
    "data structures", "algorithms", "machine learning", "tensorflow", "pandas", "numpy",
    "matlab", "simulink", "plc", "scada", "hmi", "ladder logic", "modbus", "opc ua", "arduino", "raspberry pi",
    "esp32", "stm32", "microcontroller", "embedded c", "iot", "mqtt", "pid", "control systems", "power electronics",
    "power systems", "electrical machines", "transformer", "induction motor", "inverter", "pwm", "autocad", "eplan",
    "proteus", "labview", "pspice", "etap", "sensors", "instrumentation", "vhdl", "verilog", "fpga", "pcb design",
    "solidworks", "sap2000", "relay", "motor drives", "vfd", "renewable energy", "solar",
]
SOFT_SKILLS = ["communication", "teamwork", "leadership", "problem solving", "problem-solving", "time management",
               "adaptability", "critical thinking", "creativity", "collaboration", "presentation", "mentoring"]
SECTION_ALIASES = {
    "education": ["education", "academic", "qualification"],
    "projects": ["projects", "academic projects", "project work", "personal projects"],
    "experience": ["experience", "internship", "internships", "work experience", "employment", "training"],
    "certifications": ["certifications", "certification", "certificates", "courses"],
    "achievements": ["achievements", "awards", "accomplishments", "honors", "honours", "extracurricular"],
    "skills": ["skills", "technical skills", "key skills", "core competencies"],
    "responsibilities": ["responsibilities", "duties", "what you will do", "role", "key responsibilities", "job description"],
    "required": ["requirements", "required skills", "qualifications", "must have", "required", "what we need", "minimum qualifications"],
    "preferred": ["preferred", "nice to have", "good to have", "preferred skills", "bonus", "plus"],
}


def _norm_heading(line: str) -> str:
    return re.sub(r"[^a-z ]", "", line.lower()).strip()


def split_sections(text: str) -> dict[str, list[str]]:
    sections: dict[str, list[str]] = {"_header": []}
    current = "_header"
    alias_map = {a: k for k, v in SECTION_ALIASES.items() for a in v}
    for raw in text.splitlines():
        line = raw.strip()
        if not line:
            continue
        h = _norm_heading(line)
        if len(line) <= 45 and h in alias_map and not line.startswith(("-", "•", "*")):
            current = alias_map[h]
            sections.setdefault(current, [])
            continue
        sections.setdefault(current, []).append(line)
    return sections


def _skills_in(text: str, vocab: list[str]) -> list[str]:
    low = " " + text.lower() + " "
    found = []
    for s in vocab:
        pat = r"(?<![a-z0-9])" + re.escape(s) + r"(?![a-z0-9])"
        if re.search(pat, low):
            found.append(s)
    return found


def _bullets(lines: list[str]) -> list[str]:
    out = []
    for l in lines:
        l = re.sub(r"^[\-•*●\d.)\s]+", "", l).strip()
        if len(l) > 3:
            out.append(l[:300])
    return out


def _group_projects(lines: list[str]) -> list[dict]:
    projects, cur = [], None
    for raw in lines:
        is_bullet = raw.startswith(("-", "•", "*", "●"))
        line = re.sub(r"^[\-•*●\s]+", "", raw).strip()
        if not line:
            continue
        if not is_bullet and (len(line) < 90) and (cur is None or len(cur["details"]) > 0 or line[:1].isupper()):
            if cur:
                projects.append(cur)
            name, _, rest = line.partition(":")
            cur = {"name": name.strip(" -–"), "details": [rest.strip()] if rest.strip() else []}
        else:
            if cur is None:
                cur = {"name": line[:60], "details": []}
            else:
                cur["details"].append(line[:300])
    if cur:
        projects.append(cur)
    for p in projects:
        p["skills"] = _skills_in(" ".join([p["name"]] + p["details"]), TECH_SKILLS)
    return projects[:8]


def extract_candidate_profile(text: str) -> dict:
    text, flagged = sanitize_untrusted(text)
    sec = split_sections(text)
    joined_skills_text = "\n".join(sec.get("skills", [])) or text
    tech = _skills_in(text, TECH_SKILLS)
    soft = _skills_in(text, SOFT_SKILLS)
    header = sec.get("_header", [])
    name = header[0] if header and len(header[0]) < 60 and "@" not in header[0] else ""
    profile = {
        "name": name or None,
        "technical_skills": tech,
        "soft_skills": soft,
        "education": _bullets(sec.get("education", [])),
        "projects": _group_projects(sec.get("projects", [])),
        "experience": _bullets(sec.get("experience", [])),
        "certifications": _bullets(sec.get("certifications", [])),
        "achievements": _bullets(sec.get("achievements", [])),
        "unknown_fields": [],
        "flagged_instruction_lines": flagged,
    }
    for field in ("education", "projects", "experience", "certifications", "achievements"):
        if not profile[field]:
            profile["unknown_fields"].append(field)
    if not tech:
        profile["unknown_fields"].append("technical_skills")
    _ = joined_skills_text
    return profile


def extract_job_profile(text: str) -> dict:
    text, flagged = sanitize_untrusted(text)
    sec = split_sections(text)
    header = sec.get("_header", [])
    title = header[0][:80] if header else None
    required_text = "\n".join(sec.get("required", []))
    preferred_text = "\n".join(sec.get("preferred", []))
    req = _skills_in(required_text, TECH_SKILLS)
    pref = [s for s in _skills_in(preferred_text, TECH_SKILLS) if s not in req]
    if not req and not pref:
        req = _skills_in(text, TECH_SKILLS)
    prof = {
        "title": title,
        "responsibilities": _bullets(sec.get("responsibilities", [])),
        "required_skills": req,
        "preferred_skills": pref,
        "required_notes": _bullets(sec.get("required", [])),
        "soft_skills": _skills_in(text, SOFT_SKILLS),
        "unknown_fields": [],
        "flagged_instruction_lines": flagged,
    }
    if not prof["responsibilities"]:
        prof["unknown_fields"].append("responsibilities")
    if not req:
        prof["unknown_fields"].append("required_skills")
    return prof


def compare_profiles(candidate: dict, job: dict) -> dict:
    cand = {s.lower() for s in candidate.get("technical_skills", [])}
    req = [s.lower() for s in job.get("required_skills", [])]
    pref = [s.lower() for s in job.get("preferred_skills", [])]
    matching = [s for s in req + pref if s in cand]
    missing_req = [s for s in req if s not in cand]
    missing_pref = [s for s in pref if s not in cand]
    relevant_projects = []
    wanted = set(req + pref)
    for p in candidate.get("projects", []):
        hit = sorted(set(p.get("skills", [])) & wanted)
        if hit:
            relevant_projects.append({"name": p["name"], "matched_skills": hit})
    return {
        "matching_skills": matching,
        "missing_or_unverified_required": missing_req,
        "missing_or_unverified_preferred": missing_pref,
        "relevant_projects": relevant_projects,
        "suggested_topics": (matching[:4] + missing_req[:3]),
        "note": "Missing means 'not found in the resume text', not 'candidate lacks the skill'. Unverified skills are unknown, not assumed.",
    }
