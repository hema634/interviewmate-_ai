"""Demo mode: loads the sample resume/JD and plays scripted sample answers through the REAL
interview/evaluation code. Everything created is flagged is_demo and labelled DEMO."""
from __future__ import annotations

import json
from pathlib import Path

from ..web import HttpError
from . import documents

SAMPLES = Path(__file__).resolve().parents[3] / "samples"

DEMO_ANSWERS = {
    "hr_team": "In my final year project our team had to build a conveyor controller. My role was the PLC programming. I wrote the ladder logic and tested it on the trainer kit. As a result we finished two days early and won second prize.",
    "hr_intro": "I am a final year electrical and electronics student. I built a PLC conveyor controller and an IoT energy monitor during my projects. I want to start a career in industrial automation because I enjoy control systems.",
    "el_induction": "An induction motor runs below synchronous speed because the rotor needs relative motion with the rotating field so that an emf is induced in it. The difference is called slip. At synchronous speed there would be no induced emf, so no torque.",
    "plc_scan": "A PLC reads the inputs, then executes the ladder logic, and then updates the outputs. For a latching circuit I put the output contact in parallel with the start button, and a normally closed stop button in series to break the latch.",
    "cs_pid": "A PID controller uses the error. The proportional part reacts to it and the integral part helps with the steady state error.",
    "scada_role": "I am not sure about the full difference, but I think SCADA is used for monitoring.",
    "cs_stability": "A closed-loop system is stable when its poles lie in the left half of the s-plane.",
    "cs_loop": "Open-loop has no feedback, like a toaster timer. Closed-loop uses feedback to correct the error, like a thermostat.",
    "hr_strength": "One strength I rely on is debugging systematically. For example, in my PLC project I traced a faulty sensor input by checking wiring first and then the program. An area I am improving is public speaking, so I started presenting in class and asking for feedback.",
    "hr_goals": "In three to five years I want to become a confident automation engineer. I plan to learn SCADA and drives, and this role fits that because it covers PLC commissioning. First I want to gain field experience.",
    "hr_conflict": "In a group project my teammate and I disagreed about the sensor choice. I listened to his reasons, then suggested we test both. As a result we picked the cheaper sensor after the test and I learned to decide with data.",
    "sw_oop": "OOP has encapsulation, abstraction, inheritance and polymorphism.",
    "sn_thermo": "A thermocouple works on the Seebeck effect and produces a small emf, and it needs cold junction compensation. An RTD like a Pt100 changes resistance with temperature. RTDs are more accurate and stable, while thermocouples have a wider range.",
    "proj_problem": "My project addresses the problem that small factories lack low-cost energy monitoring. The objective was a meter under a fixed budget for technicians in small units.",
    "proj_motivation": "I chose it because I noticed our lab had no way to see power use. Existing meters were expensive, which was the gap I wanted to address.",
    "proj_architecture": "The architecture has a sensor block, an ESP32 module and a dashboard. First the current sensor sends readings, then the ESP32 publishes them with MQTT, and finally a Python script stores them.",
}
FALLBACK = "I don't know this one well yet."


def seed_demo(ctx, uid: int) -> dict:
    u = ctx.db.one("SELECT consent_documents FROM users WHERE id=?", (uid,))
    if not u["consent_documents"]:
        raise HttpError(403, "Demo loads sample (fictional) documents; please grant document-processing consent first.", "consent_required")
    try:
        resume = (SAMPLES / "sample_resume.txt").read_text()
        jd = (SAMPLES / "sample_job_description.txt").read_text()
    except OSError:
        raise HttpError(500, "Sample files are missing", "internal")
    db = ctx.db
    rdoc = db.execute("INSERT INTO uploaded_documents(user_id,kind,filename,text) VALUES (?,?,?,?)", (uid, "resume", "DEMO sample_resume.txt", resume)).lastrowid
    jdoc = db.execute("INSERT INTO uploaded_documents(user_id,kind,filename,text) VALUES (?,?,?,?)", (uid, "job_description", "DEMO sample_job_description.txt", jd)).lastrowid
    pid = db.execute("INSERT INTO candidate_profiles(user_id,document_id,profile_json) VALUES (?,?,?)", (uid, rdoc, json.dumps(documents.extract_candidate_profile(resume)))).lastrowid
    jid = db.execute("INSERT INTO job_descriptions(user_id,document_id,job_json) VALUES (?,?,?)", (uid, jdoc, json.dumps(documents.extract_job_profile(jd)))).lastrowid
    S = ctx.sessions
    sess = S.create(uid, {"mode": "mixed", "target_role": "Graduate Engineer Trainee (DEMO)", "experience_level": "fresher", "difficulty": "adaptive",
                          "num_questions": 6, "duration_minutes": 30, "profile_id": pid, "job_id": jid}, is_demo=True)
    guard = 0
    while sess["status"] == "active" and guard < 30:
        guard += 1
        cq = sess["current_question"]
        bank_key = None
        row = db.one("SELECT rubric_json FROM interview_questions WHERE id=?", (cq["id"],))
        bank_key = json.loads(row["rubric_json"])["bank_id"]
        text = DEMO_ANSWERS.get(bank_key, FALLBACK)
        sess = S.answer(uid, sess["id"], cq["id"], text, "typed")["session"]
    # demonstrate retry on the weakest answered question that has a scripted improved answer
    better = {
        "cs_pid": "The proportional term acts on the present error, the integral term accumulates error to remove steady state error, and the derivative term reacts to the rate of change to add damping. However, too much integral causes windup and overshoot, and derivative amplifies noise, so tuning matters.",
        "scada_role": "A PLC does real-time control of the process at the field level, while SCADA supervises: it provides the HMI, data acquisition, alarms and a historian. They communicate over protocols such as Modbus or OPC UA.",
        "cs_stability": "A closed-loop system is stable when all closed-loop poles lie in the left half of the s-plane. I can check this with the Routh-Hurwitz criterion without solving for roots, or with Nyquist and Bode plots using gain margin and phase margin. In time response, a stable system gives a bounded step response that settles instead of oscillating forever.",
    }
    scored = [(q, q["answers"][0]["evaluation"]["total"], json.loads(db.one("SELECT rubric_json FROM interview_questions WHERE id=?", (q["id"],))["rubric_json"])["bank_id"])
              for q in sess["questions"] if q["answers"] and q["answers"][0]["evaluation"]["total"] is not None]
    candidates = [(q, t) for q, t, key in scored if key in better]
    if candidates:
        weakest = min(candidates, key=lambda x: x[1])[0]
        key = json.loads(db.one("SELECT rubric_json FROM interview_questions WHERE id=?", (weakest["id"],))["rubric_json"])["bank_id"]
        S.retry(uid, sess["id"], weakest["id"], better[key], "typed")
    return {"demo": True, "label": "DEMO session created from fictional sample documents and scripted sample answers; scores are real outputs of the evaluator.",
            "session_id": sess["id"], "profile_id": pid, "job_id": jid}
