"""HTTP API wiring. Auth, consent, documents/profiles, sessions, voice, reports, privacy, demo."""
from __future__ import annotations

import json
from pathlib import Path

from . import scoring
from .config import Settings
from .db import Database
from .llm import build_provider
from .security import EMAIL_RE, RateLimiter, hash_password, make_token, read_token, verify_password
from .services import analytics, coaching, documents, report
from .services.demo import seed_demo
from .services.sessions import SessionService
from .services.speech import SpeechTranscriptionService, TextToSpeechService
from .web import App, HttpError, Request, Response

MAX_LIST = 60
FRONTEND = Path(__file__).resolve().parents[2] / "frontend"


class Context:
    def __init__(self, settings: Settings):
        self.settings = settings
        self.db = Database(settings.db_path)
        self.provider = build_provider(settings)
        self.sessions = SessionService(self.db, self.provider)
        self.stt = SpeechTranscriptionService(settings)
        self.tts = TextToSpeechService(settings)
        self.limiter = RateLimiter(settings.rate_limit_per_min)
        self.auth_limiter = RateLimiter(10)


def _clean_list(v, maxlen=200, maxn=MAX_LIST):
    if not isinstance(v, list):
        raise HttpError(400, "Expected a list", "bad_request")
    return [str(x).strip()[:maxlen] for x in v[:maxn] if str(x).strip()]


def _clean_profile(p: dict) -> dict:
    if not isinstance(p, dict):
        raise HttpError(400, "profile must be an object", "bad_request")
    out = {"name": (str(p["name"]).strip()[:80] if p.get("name") else None),
           "technical_skills": [s.lower() for s in _clean_list(p.get("technical_skills", []), 60)],
           "soft_skills": [s.lower() for s in _clean_list(p.get("soft_skills", []), 60)],
           "education": _clean_list(p.get("education", []), 300), "experience": _clean_list(p.get("experience", []), 300),
           "certifications": _clean_list(p.get("certifications", []), 300), "achievements": _clean_list(p.get("achievements", []), 300), "projects": []}
    for pr in (p.get("projects") or [])[:10]:
        if isinstance(pr, dict) and str(pr.get("name", "")).strip():
            details = _clean_list(pr.get("details", []), 300, 12)
            out["projects"].append({"name": str(pr["name"]).strip()[:100], "details": details,
                                    "skills": [s.lower() for s in _clean_list(pr.get("skills", []), 60, 20)] or documents._skills_in(" ".join(details), documents.TECH_SKILLS)})
    out["unknown_fields"] = [f for f in ("education", "projects", "experience", "certifications", "achievements", "technical_skills") if not out[f]]
    out["flagged_instruction_lines"] = []
    return out


def _clean_job(j: dict) -> dict:
    if not isinstance(j, dict):
        raise HttpError(400, "job must be an object", "bad_request")
    out = {"title": (str(j["title"]).strip()[:120] if j.get("title") else None),
           "responsibilities": _clean_list(j.get("responsibilities", []), 300),
           "required_skills": [s.lower() for s in _clean_list(j.get("required_skills", []), 60)],
           "preferred_skills": [s.lower() for s in _clean_list(j.get("preferred_skills", []), 60)],
           "required_notes": _clean_list(j.get("required_notes", []), 300), "soft_skills": [s.lower() for s in _clean_list(j.get("soft_skills", []), 60)]}
    out["unknown_fields"] = [f for f in ("responsibilities", "required_skills") if not out[f]]
    out["flagged_instruction_lines"] = []
    return out


def create_app(settings: Settings | None = None) -> tuple[App, Context]:
    ctx = Context(settings or Settings.load())
    db, S = ctx.db, ctx.sessions
    app = App()
    app.static_dir = FRONTEND

    def before(req: Request, auth_required: bool):
        limiter = ctx.auth_limiter if req.path in ("/api/auth/login", "/api/auth/register") else ctx.limiter
        if not limiter.allow(req.client):
            raise HttpError(429, "Too many requests. Please slow down.", "rate_limited")
        if auth_required:
            h = req.headers.get("Authorization", "")
            if not h.startswith("Bearer "):
                raise HttpError(401, "Authentication required", "unauthorized")
            uid = read_token(ctx.settings.secret_key, h[7:])
            if uid is None or not db.one("SELECT id FROM users WHERE id=?", (uid,)):
                raise HttpError(401, "Invalid or expired session. Please sign in again.", "unauthorized")
            req.user_id = uid
    app.before = before

    def user_public(u):
        return {"id": u["id"], "email": u["email"], "display_name": u["display_name"],
                "consent_documents": bool(u["consent_documents"]), "consent_ai_processing": bool(u["consent_ai_processing"]),
                "consent_audio": bool(u["consent_audio"])}

    def me(req):
        return db.one("SELECT * FROM users WHERE id=?", (req.user_id,))

    # ---------------- health / meta ----------------
    @app.route("GET", "/api/health", auth=False)
    def health(req):
        return {"status": "ok", "llm_provider": ctx.provider.name, "stt_configured": ctx.stt.available, "tts_configured": ctx.tts.available}

    @app.route("GET", "/api/privacy", auth=False)
    def privacy(req):
        external = []
        if ctx.provider.is_llm:
            external.append({"purpose": "Question follow-ups and answer evaluation (only if you opt in)", "provider": ctx.provider.name, "data": "answer text, selected reference notes"})
        if ctx.stt.available:
            external.append({"purpose": "Speech-to-text (only after microphone consent)", "provider": ctx.settings.stt_base_url, "data": "audio recording (not stored by InterviewMate)"})
        if ctx.tts.available:
            external.append({"purpose": "Text-to-speech", "provider": ctx.settings.tts_base_url, "data": "question text"})
        return {"external_providers": external, "default": "No data leaves this server unless you opt in and a provider is configured.",
                "stores": ["account email", "extracted resume/job text you upload", "interview answers and evaluations"],
                "does_not_store": ["raw audio", "camera video"], "browser_tts_note": "Browser read-aloud may use your browser vendor's voice service."}

    @app.route("GET", "/api/rubric", auth=False)
    def rubric(req):
        return {
            "weights": {k: {"label": scoring.CATEGORY_LABELS[k], "weight": w} for k, w in scoring.CATEGORY_WEIGHTS.items()},
            "formula": "Total = 0.35×Technical + 0.25×Communication + 0.20×Structure/STAR + 0.10×Relevance + 0.10×Improvement Potential",
            "definitions": {
                "technical_correctness": "Objective: share of question-specific rubric concepts demonstrated, minus 15 points per known-incorrect claim. Equivalent phrasings are accepted. Not applicable to behavioral questions.",
                "communication": "Clarity and organization: length adequacy (40-200 words ideal), signposting cues, average sentence length. Accent, dialect, grammar and filler words are NOT penalized.",
                "structure": "Behavioral questions use STAR (25 points per element). Technical and project questions use a domain structure: definition, reasoning, example, trade-off.",
                "relevance": "How directly the answer addresses the question: rubric coverage plus topical term overlap.",
                "improvement_potential": "60% rubric coverage (a foundation to build on) + 40% diagnosability (answer long enough to give specific advice). Reproducible; weak answers do not score high.",
            },
            "insufficient_evidence": "If a category cannot be judged (e.g., answer too short, or STAR on a technical question), it is not scored. The remaining weights are renormalised, the total is flagged 'partial', and the weights used are shown.",
            "limitations": ["The offline evaluator uses keyword rubrics and can miss correct answers phrased unusually.",
                            "Having a rubric does not make scoring unbiased. Treat scores as practice indicators, not hiring predictions.",
                            "Protected characteristics and personal details are never used in scoring.",
                            "Camera data is never used in scoring."],
            "flagging": "Use 'Flag this evaluation' on any result you believe is incorrect."}

    # ---------------- auth ----------------
    @app.route("POST", "/api/auth/register", auth=False)
    def register(req):
        d = req.json()
        email, pw = str(d.get("email", "")).strip().lower(), str(d.get("password", ""))
        if not EMAIL_RE.match(email) or len(email) > 200:
            raise HttpError(400, "Enter a valid email address", "bad_email")
        if len(pw) < 8 or len(pw) > 200:
            raise HttpError(400, "Password must be at least 8 characters", "weak_password")
        if db.one("SELECT id FROM users WHERE email=?", (email,)):
            raise HttpError(409, "An account with this email already exists", "exists")
        cur = db.execute("INSERT INTO users(email,password_hash,display_name) VALUES (?,?,?)",
                         (email, hash_password(pw), str(d.get("display_name", ""))[:80]))
        u = db.one("SELECT * FROM users WHERE id=?", (cur.lastrowid,))
        return {"token": make_token(ctx.settings.secret_key, u["id"]), "user": user_public(u)}

    @app.route("POST", "/api/auth/login", auth=False)
    def login(req):
        d = req.json()
        u = db.one("SELECT * FROM users WHERE email=?", (str(d.get("email", "")).strip().lower(),))
        if not u or not verify_password(str(d.get("password", "")), u["password_hash"]):
            raise HttpError(401, "Incorrect email or password", "bad_credentials")
        return {"token": make_token(ctx.settings.secret_key, u["id"]), "user": user_public(u)}

    @app.route("GET", "/api/me")
    def get_me(req):
        return user_public(me(req))

    @app.route("PUT", "/api/me")
    def put_me(req):
        d = req.json()
        u = me(req)
        vals = {k: (1 if d[k] else 0) if k in d else u[k] for k in ("consent_documents", "consent_ai_processing", "consent_audio")}
        name = str(d["display_name"])[:80] if "display_name" in d else u["display_name"]
        db.execute("UPDATE users SET display_name=?, consent_documents=?, consent_ai_processing=?, consent_audio=? WHERE id=?",
                   (name, vals["consent_documents"], vals["consent_ai_processing"], vals["consent_audio"], req.user_id))
        return user_public(me(req))

    @app.route("DELETE", "/api/me")
    def delete_me(req):
        db.execute("DELETE FROM users WHERE id=?", (req.user_id,))
        return {"deleted": True}

    @app.route("GET", "/api/export")
    def export(req):
        uid = req.user_id
        return {"user": user_public(me(req)),
                "documents": [dict(r) for r in db.all("SELECT id,kind,filename,created_at FROM uploaded_documents WHERE user_id=?", (uid,))],
                "profiles": [json.loads(r["profile_json"]) for r in db.all("SELECT profile_json FROM candidate_profiles WHERE user_id=?", (uid,))],
                "sessions": [S.get(uid, r["id"]) for r in db.all("SELECT id FROM interview_sessions WHERE user_id=?", (uid,))]}

    # ---------------- documents / profiles ----------------
    def store_document(uid, kind, filename, text):
        if kind not in ("resume", "job_description"):
            raise HttpError(400, "kind must be 'resume' or 'job_description'", "bad_request")
        u = db.one("SELECT consent_documents FROM users WHERE id=?", (uid,))
        if not u["consent_documents"]:
            raise HttpError(403, "Please give consent to process your document first (Settings & Privacy).", "consent_required")
        did = db.execute("INSERT INTO uploaded_documents(user_id,kind,filename,text) VALUES (?,?,?,?)", (uid, kind, filename[:200], text)).lastrowid
        if kind == "resume":
            extracted = documents.extract_candidate_profile(text)
            rid = db.execute("INSERT INTO candidate_profiles(user_id,document_id,profile_json) VALUES (?,?,?)", (uid, did, json.dumps(extracted))).lastrowid
            return {"document_id": did, "kind": kind, "profile_id": rid, "extracted": extracted}
        extracted = documents.extract_job_profile(text)
        rid = db.execute("INSERT INTO job_descriptions(user_id,document_id,job_json) VALUES (?,?,?)", (uid, did, json.dumps(extracted))).lastrowid
        return {"document_id": did, "kind": kind, "job_id": rid, "extracted": extracted}

    @app.route("POST", "/api/documents")
    def upload(req):
        fields, files = req.multipart()
        if "file" not in files:
            raise HttpError(400, "Attach a file in the 'file' field", "bad_request")
        filename, data = files["file"]
        text = documents.extract_text(filename, data, ctx.settings.max_upload_bytes)
        return store_document(req.user_id, fields.get("kind", ""), filename, text)

    @app.route("POST", "/api/documents/text")
    def upload_text(req):
        d = req.json()
        text = str(d.get("text", "")).strip()
        if len(text) < 20:
            raise HttpError(422, "Paste at least a few lines of text", "no_text")
        return store_document(req.user_id, str(d.get("kind", "")), str(d.get("filename", "pasted.txt")), text[:60000])

    @app.route("GET", "/api/documents")
    def list_docs(req):
        return [dict(r) for r in db.all("SELECT id,kind,filename,created_at FROM uploaded_documents WHERE user_id=? ORDER BY id DESC", (req.user_id,))]

    @app.route("DELETE", "/api/documents/<id>")
    def del_doc(req):
        r = db.one("SELECT id FROM uploaded_documents WHERE id=? AND user_id=?", (req.params["id"], req.user_id))
        if not r:
            raise HttpError(404, "Document not found", "not_found")
        db.execute("DELETE FROM candidate_profiles WHERE document_id=? AND user_id=?", (r["id"], req.user_id))
        db.execute("DELETE FROM job_descriptions WHERE document_id=? AND user_id=?", (r["id"], req.user_id))
        db.execute("DELETE FROM uploaded_documents WHERE id=?", (r["id"],))
        return {"deleted": True}

    @app.route("GET", "/api/profiles")
    def list_profiles(req):
        return [{"id": r["id"], "document_id": r["document_id"], "user_corrected": bool(r["user_corrected"]), "profile": json.loads(r["profile_json"])}
                for r in db.all("SELECT * FROM candidate_profiles WHERE user_id=? ORDER BY id DESC", (req.user_id,))]

    @app.route("PUT", "/api/profiles/<id>")
    def put_profile(req):
        r = db.one("SELECT id FROM candidate_profiles WHERE id=? AND user_id=?", (req.params["id"], req.user_id))
        if not r:
            raise HttpError(404, "Profile not found", "not_found")
        clean = _clean_profile(req.json().get("profile"))
        db.execute("UPDATE candidate_profiles SET profile_json=?, user_corrected=1 WHERE id=?", (json.dumps(clean), r["id"]))
        return {"id": r["id"], "profile": clean, "user_corrected": True}

    @app.route("GET", "/api/jobs")
    def list_jobs(req):
        return [{"id": r["id"], "document_id": r["document_id"], "user_corrected": bool(r["user_corrected"]), "job": json.loads(r["job_json"])}
                for r in db.all("SELECT * FROM job_descriptions WHERE user_id=? ORDER BY id DESC", (req.user_id,))]

    @app.route("PUT", "/api/jobs/<id>")
    def put_job(req):
        r = db.one("SELECT id FROM job_descriptions WHERE id=? AND user_id=?", (req.params["id"], req.user_id))
        if not r:
            raise HttpError(404, "Job description not found", "not_found")
        clean = _clean_job(req.json().get("job"))
        db.execute("UPDATE job_descriptions SET job_json=?, user_corrected=1 WHERE id=?", (json.dumps(clean), r["id"]))
        return {"id": r["id"], "job": clean, "user_corrected": True}

    @app.route("GET", "/api/compare")
    def compare(req):
        try:
            pid, jid = int(req.query["profile_id"][0]), int(req.query["job_id"][0])
        except (KeyError, ValueError, IndexError):
            raise HttpError(400, "profile_id and job_id are required", "bad_request")
        p = db.one("SELECT profile_json FROM candidate_profiles WHERE id=? AND user_id=?", (pid, req.user_id))
        j = db.one("SELECT job_json FROM job_descriptions WHERE id=? AND user_id=?", (jid, req.user_id))
        if not p or not j:
            raise HttpError(404, "Profile or job not found", "not_found")
        return documents.compare_profiles(json.loads(p["profile_json"]), json.loads(j["job_json"]))

    # ---------------- sessions ----------------
    @app.route("POST", "/api/sessions")
    def create_session(req):
        return S.create(req.user_id, req.json())

    @app.route("GET", "/api/sessions")
    def list_sessions(req):
        return S.list(req.user_id)

    @app.route("GET", "/api/sessions/<id>")
    def get_session(req):
        return S.get(req.user_id, int(req.params["id"]))

    @app.route("DELETE", "/api/sessions/<id>")
    def del_session(req):
        S.delete(req.user_id, int(req.params["id"]))
        return {"deleted": True}

    @app.route("POST", "/api/sessions/<id>/answer")
    def answer(req):
        d = req.json()
        return S.answer(req.user_id, int(req.params["id"]), int(d.get("question_id", 0)), d.get("text", ""), str(d.get("source", "typed")),
                        d.get("duration_seconds"), allow_external=bool(d.get("allow_external", False)))

    @app.route("POST", "/api/sessions/<id>/control")
    def control(req):
        return S.control(req.user_id, int(req.params["id"]), str(req.json().get("action", "")))

    @app.route("POST", "/api/sessions/<id>/retry")
    def retry(req):
        d = req.json()
        return S.retry(req.user_id, int(req.params["id"]), int(d.get("question_id", 0)), d.get("text", ""), str(d.get("source", "typed")),
                       allow_external=bool(d.get("allow_external", False)))

    @app.route("GET", "/api/sessions/<id>/retries")
    def retries(req):
        return S.retries(req.user_id, int(req.params["id"]))

    @app.route("POST", "/api/sessions/<id>/coach")
    def coach(req):
        d = req.json()
        s = S.get(req.user_id, int(req.params["id"]))
        action = str(d.get("action", ""))
        if action not in coaching.ACTIONS:
            raise HttpError(400, "Unknown coaching action", "bad_request")
        qrow = S._question(req.user_id, int(d.get("question_id", 0)))
        if qrow["session_id"] != s["id"]:
            raise HttpError(404, "Question not found", "not_found")
        q = S._q_dict(qrow)
        qa = next((x for x in s["questions"] if x["id"] == qrow["id"]), None)
        if not qa or not qa["answers"]:
            raise HttpError(409, "Answer the question first", "no_answer")
        last = qa["answers"][-1]
        return coaching.coach(action, q, last["text"], last["evaluation"])

    @app.route("GET", "/api/sessions/<id>/report")
    def get_report(req):
        sid = int(req.params["id"])
        return report.build_report(S, req.user_id, sid)

    @app.route("GET", "/api/sessions/<id>/report.html")
    def get_report_html(req):
        rep = report.build_report(S, req.user_id, int(req.params["id"]))
        return Response(raw=report.report_html(rep).encode(), content_type="text/html; charset=utf-8")

    @app.route("GET", "/api/sessions/<id>/report.pdf")
    def get_report_pdf(req):
        rep = report.build_report(S, req.user_id, int(req.params["id"]))
        return Response(raw=report.report_pdf(rep), content_type="application/pdf",
                        headers={"Content-Disposition": f'attachment; filename="interviewmate-report-{rep["overview"]["session_id"]}.pdf"'})

    # ---------------- evaluations ----------------
    @app.route("POST", "/api/evaluations/<id>/flag")
    def flag(req):
        d = req.json()
        row = db.one("SELECT e.id FROM evaluation_results e JOIN interview_answers a ON a.id=e.answer_id JOIN interview_questions q ON q.id=a.question_id "
                     "JOIN interview_sessions s ON s.id=q.session_id WHERE e.id=? AND s.user_id=?", (req.params["id"], req.user_id))
        if not row:
            raise HttpError(404, "Evaluation not found", "not_found")
        msg = str(d.get("message", "")).strip()
        if not msg:
            raise HttpError(400, "Please describe what looks incorrect", "bad_request")
        db.execute("INSERT INTO user_feedback(user_id,evaluation_id,category,message) VALUES (?,?,?,?)",
                   (req.user_id, row["id"], str(d.get("category", ""))[:40] or None, msg[:1000]))
        return {"flagged": True}

    @app.route("GET", "/api/flags")
    def my_flags(req):
        return [dict(r) for r in db.all("SELECT id,evaluation_id,category,message,created_at FROM user_feedback WHERE user_id=? ORDER BY id DESC", (req.user_id,))]

    # ---------------- analytics / dashboard ----------------
    @app.route("GET", "/api/progress")
    def prog(req):
        return analytics.progress(db, req.user_id)

    @app.route("GET", "/api/dashboard")
    def dashboard(req):
        p = analytics.progress(db, req.user_id)
        return {"recent_sessions": S.list(req.user_id)[:5], "average_score": p["average_score"], "sessions_completed": p["sessions_completed"],
                "weak_areas": p["weak_areas"][:3], "recommendation": p["recommendation"], "category_averages": p["category_averages"],
                "has_profile": bool(db.one("SELECT 1 FROM candidate_profiles WHERE user_id=?", (req.user_id,)))}

    @app.route("GET", "/api/plans/<id>")
    def plan(req):
        S._session(req.user_id, int(req.params["id"]))
        r = db.one("SELECT plan_json FROM improvement_plans WHERE session_id=?", (req.params["id"],))
        if not r:
            raise HttpError(404, "Plan is generated when the interview is completed", "not_found")
        return json.loads(r["plan_json"])

    # ---------------- voice ----------------
    @app.route("POST", "/api/speech/transcribe")
    def transcribe(req):
        if not me(req)["consent_audio"]:
            raise HttpError(403, "Microphone use requires your consent (Settings & Privacy).", "consent_required")
        fields, files = req.multipart()
        if "audio" not in files:
            raise HttpError(400, "Attach recorded audio in the 'audio' field", "bad_request")
        fname, data = files["audio"]
        return ctx.stt.transcribe(fname, data, fields.get("content_type", "audio/webm"), fields.get("language"))

    @app.route("POST", "/api/speech/synthesize")
    def synthesize(req):
        audio, ctype = ctx.tts.speak(str(req.json().get("text", "")))
        return Response(raw=audio, content_type=ctype)

    # ---------------- coding ----------------
    @app.route("GET", "/api/coding/problems")
    def problems(req):
        return {"problems": coaching.PROBLEMS, "languages": list(coaching.LANGS), "execution": "not_available"}

    @app.route("POST", "/api/coding/review")
    def code_review(req):
        d = req.json()
        code = str(d.get("code", ""))
        if not code.strip() or len(code) > 20000:
            raise HttpError(400, "Provide code (max 20,000 characters)", "bad_request")
        try:
            return coaching.review_code(str(d.get("language", "")), str(d.get("problem_id", "")), code, str(d.get("explanation", ""))[:4000])
        except ValueError:
            raise HttpError(400, "Unsupported language or problem", "bad_request")

    # ---------------- demo ----------------
    @app.route("POST", "/api/demo")
    def demo(req):
        return seed_demo(ctx, req.user_id)

    return app, ctx
