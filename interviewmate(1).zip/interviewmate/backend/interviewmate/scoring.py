"""Weighted scoring and structured-result validation.

Total = 0.35*Technical + 0.25*Communication + 0.20*Structure + 0.10*Relevance + 0.10*Improvement.
If some categories are 'insufficient_evidence', the remaining weights are renormalised and the
result is flagged `partial` with the weights actually used, so nothing is silently invented.
"""
from __future__ import annotations

CATEGORY_WEIGHTS = {
    "technical_correctness": 0.35,
    "communication": 0.25,
    "structure": 0.20,
    "relevance": 0.10,
    "improvement_potential": 0.10,
}
CATEGORY_LABELS = {
    "technical_correctness": "Technical Correctness",
    "communication": "Communication",
    "structure": "Structure / STAR",
    "relevance": "Relevance",
    "improvement_potential": "Improvement Potential",
}
STATUSES = ("scored", "insufficient_evidence")


class ValidationError(ValueError):
    pass


def compute_total(categories: dict) -> dict:
    """Return {'total': float|None, 'partial': bool, 'weights_used': {...}, 'missing': [...]}."""
    scored = {k: v for k, v in categories.items() if v.get("status") == "scored"}
    missing = [k for k in CATEGORY_WEIGHTS if k not in scored]
    if not scored:
        return {"total": None, "partial": True, "weights_used": {}, "missing": missing}
    wsum = sum(CATEGORY_WEIGHTS[k] for k in scored)
    total = sum(CATEGORY_WEIGHTS[k] * scored[k]["score"] for k in scored) / wsum
    weights_used = {k: round(CATEGORY_WEIGHTS[k] / wsum, 4) for k in scored}
    return {
        "total": round(max(0.0, min(100.0, total)), 1),
        "partial": bool(missing),
        "weights_used": weights_used,
        "missing": missing,
    }


def validate_evidence(quote: str, transcript: str) -> bool:
    """A quote is valid only if it is a non-empty exact substring of the transcript."""
    return bool(quote) and quote.strip() != "" and quote in transcript


def validate_evaluation(result: dict, transcript: str) -> dict:
    """Validate (and sanitise) a structured evaluation, e.g. from an LLM.

    - every category present with a known status
    - scored => integer-valued 0..100 score, >=1 evidence item, every quote an exact transcript substring
    - fabricated evidence is NOT repaired: the category is downgraded to insufficient_evidence
    Returns a new dict with `evidence_downgrades` listing what was changed.
    """
    if not isinstance(result, dict) or not isinstance(result.get("categories"), dict):
        raise ValidationError("missing 'categories' object")
    out_cats, downgrades = {}, []
    for key in CATEGORY_WEIGHTS:
        cat = result["categories"].get(key)
        if not isinstance(cat, dict):
            raise ValidationError(f"missing category: {key}")
        status = cat.get("status")
        if status not in STATUSES:
            raise ValidationError(f"{key}: invalid status {status!r}")
        for field in ("explanation", "suggestion"):
            if not isinstance(cat.get(field), str) or not cat[field].strip():
                raise ValidationError(f"{key}: missing {field}")
        evidence = cat.get("evidence") or []
        if not isinstance(evidence, list):
            raise ValidationError(f"{key}: evidence must be a list")
        clean = dict(cat)
        if status == "scored":
            score = cat.get("score")
            if isinstance(score, bool) or not isinstance(score, (int, float)) or not (0 <= score <= 100):
                raise ValidationError(f"{key}: score must be a number in 0..100")
            valid, bad = [], []
            for ev in evidence:
                q = ev.get("quote") if isinstance(ev, dict) else None
                (valid if isinstance(q, str) and validate_evidence(q, transcript) else bad).append(ev)
            if not valid:
                clean.update(status="insufficient_evidence", score=None, evidence=[])
                clean["explanation"] = (
                    "Not scored: no supporting excerpt matched the transcript exactly. "
                    + cat["explanation"]
                )
                downgrades.append({"category": key, "reason": "no valid transcript evidence",
                                   "rejected_quotes": [e.get("quote") if isinstance(e, dict) else None for e in bad]})
            else:
                clean["score"] = int(round(score))
                clean["evidence"] = [
                    {"quote": e["quote"], "why_it_matters": str(e.get("why_it_matters") or "Supports this score.")}
                    for e in valid
                ]
        else:
            clean["score"] = None
            clean["evidence"] = []
        out_cats[key] = clean
    totals = compute_total(out_cats)
    return {**{k: v for k, v in result.items() if k != "categories"},
            "categories": out_cats, "total": totals["total"], "partial": totals["partial"],
            "weights_used": totals["weights_used"], "evidence_downgrades": downgrades}
