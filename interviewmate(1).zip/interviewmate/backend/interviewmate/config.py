import os
from dataclasses import dataclass


def _env(name: str, default: str = "") -> str:
    return os.environ.get(name, default)


@dataclass
class Settings:
    secret_key: str
    db_path: str
    host: str
    port: int
    max_upload_bytes: int
    rate_limit_per_min: int
    llm_provider: str
    llm_base_url: str
    llm_api_key: str
    llm_model: str
    stt_base_url: str
    stt_api_key: str
    stt_model: str
    tts_base_url: str
    tts_api_key: str
    tts_model: str

    @staticmethod
    def load() -> "Settings":
        return Settings(
            secret_key=_env("IM_SECRET_KEY", "dev-insecure-secret-change-me"),
            db_path=_env("IM_DB_PATH", "./interviewmate.db"),
            host=_env("IM_HOST", "127.0.0.1"),
            port=int(_env("IM_PORT", "8000")),
            max_upload_bytes=int(float(_env("IM_MAX_UPLOAD_MB", "5")) * 1024 * 1024),
            rate_limit_per_min=int(_env("IM_RATE_LIMIT_PER_MIN", "120")),
            llm_provider=_env("IM_LLM_PROVIDER", "offline"),
            llm_base_url=_env("IM_LLM_BASE_URL"),
            llm_api_key=_env("IM_LLM_API_KEY"),
            llm_model=_env("IM_LLM_MODEL"),
            stt_base_url=_env("IM_STT_BASE_URL"),
            stt_api_key=_env("IM_STT_API_KEY"),
            stt_model=_env("IM_STT_MODEL", "whisper-1"),
            tts_base_url=_env("IM_TTS_BASE_URL"),
            tts_api_key=_env("IM_TTS_API_KEY"),
            tts_model=_env("IM_TTS_MODEL"),
        )
