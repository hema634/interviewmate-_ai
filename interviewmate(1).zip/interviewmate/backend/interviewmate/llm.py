"""Provider-independent LLM layer.

`OfflineProvider` is the default: no network, deterministic rule-based evaluation lives in
services/evaluation.py. `OpenAICompatibleProvider` talks to any /chat/completions-style API
using only the standard library. Documents are sent to it only when the user has given
consent (checked by the caller) and the provider is configured on the server.
"""
from __future__ import annotations

import json
import re
import urllib.error
import urllib.request


class LLMError(Exception):
    pass


class OfflineProvider:
    name = "offline"
    is_llm = False

    def complete_json(self, system: str, user: str) -> dict:
        raise LLMError("offline provider cannot generate free-form output")


class OpenAICompatibleProvider:
    is_llm = True

    def __init__(self, base_url: str, api_key: str, model: str, timeout: int = 45):
        self.base_url, self.api_key, self.model, self.timeout = base_url.rstrip("/"), api_key, model, timeout
        self.name = f"openai_compatible:{model}"

    def complete_json(self, system: str, user: str) -> dict:
        body = json.dumps({
            "model": self.model,
            "temperature": 0,
            "response_format": {"type": "json_object"},
            "messages": [{"role": "system", "content": system}, {"role": "user", "content": user}],
        }).encode()
        req = urllib.request.Request(self.base_url + "/chat/completions", data=body, method="POST",
                                     headers={"Content-Type": "application/json",
                                              "Authorization": f"Bearer {self.api_key}"})
        try:
            with urllib.request.urlopen(req, timeout=self.timeout) as r:
                payload = json.loads(r.read())
            content = payload["choices"][0]["message"]["content"]
        except (urllib.error.URLError, TimeoutError, KeyError, IndexError, ValueError) as e:
            raise LLMError(f"LLM request failed: {type(e).__name__}") from e
        m = re.search(r"\{.*\}", content, re.S)
        if not m:
            raise LLMError("LLM returned no JSON object")
        try:
            return json.loads(m.group(0))
        except ValueError as e:
            raise LLMError("LLM returned invalid JSON") from e


def build_provider(settings) -> "OfflineProvider | OpenAICompatibleProvider":
    if settings.llm_provider == "openai_compatible" and settings.llm_api_key and settings.llm_base_url and settings.llm_model:
        return OpenAICompatibleProvider(settings.llm_base_url, settings.llm_api_key, settings.llm_model)
    return OfflineProvider()
