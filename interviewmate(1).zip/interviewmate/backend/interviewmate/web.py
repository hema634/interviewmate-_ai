"""Minimal HTTP framework on the standard library: routing, JSON, multipart, static files."""
import json
import mimetypes
import re
from email.parser import BytesParser
from email.policy import default as email_default
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import parse_qs, urlparse


class HttpError(Exception):
    def __init__(self, status: int, message: str, code: str = "error"):
        super().__init__(message)
        self.status, self.message, self.code = status, message, code


class Request:
    def __init__(self, method, path, query, headers, body, client):
        self.method, self.path, self.query = method, path, query
        self.headers, self.body, self.client = headers, body, client
        self.params: dict[str, str] = {}
        self.user_id: int | None = None

    def json(self):
        if not self.body:
            return {}
        try:
            data = json.loads(self.body)
        except ValueError:
            raise HttpError(400, "Invalid JSON body", "bad_json")
        if not isinstance(data, dict):
            raise HttpError(400, "JSON body must be an object", "bad_json")
        return data

    def multipart(self) -> tuple[dict[str, str], dict[str, tuple[str, bytes]]]:
        ctype = self.headers.get("Content-Type", "")
        if "multipart/form-data" not in ctype:
            raise HttpError(400, "Expected multipart/form-data", "bad_content_type")
        raw = b"Content-Type: " + ctype.encode() + b"\r\n\r\n" + self.body
        msg = BytesParser(policy=email_default).parsebytes(raw)
        fields, files = {}, {}
        for part in msg.iter_parts():
            name = part.get_param("name", header="content-disposition")
            filename = part.get_filename()
            payload = part.get_payload(decode=True) or b""
            if filename is not None:
                files[name] = (filename, payload)
            elif name:
                fields[name] = payload.decode("utf-8", "replace")
        return fields, files


class Response:
    def __init__(self, data=None, status=200, headers=None, raw: bytes | None = None, content_type="application/json"):
        self.status, self.headers, self.content_type = status, headers or {}, content_type
        self.raw = raw if raw is not None else json.dumps(data, default=str).encode()


class App:
    def __init__(self):
        self.routes: list[tuple[str, re.Pattern, callable, bool]] = []
        self.static_dir: Path | None = None
        self.before = None  # callable(req, auth_required) -> None

    def route(self, method: str, pattern: str, auth: bool = True):
        regex = re.compile("^" + re.sub(r"<(\w+)>", r"(?P<\1>[^/]+)", pattern) + "$")

        def deco(fn):
            self.routes.append((method, regex, fn, auth))
            return fn
        return deco

    def dispatch(self, req: Request) -> Response:
        try:
            if req.path.startswith("/api/"):
                path_match = False
                for method, regex, fn, auth in self.routes:
                    m = regex.match(req.path)
                    if not m:
                        continue
                    path_match = True
                    if method != req.method:
                        continue
                    req.params = m.groupdict()
                    if self.before:
                        self.before(req, auth)
                    result = fn(req)
                    return result if isinstance(result, Response) else Response(result)
                if path_match:
                    raise HttpError(405, "Method not allowed", "method_not_allowed")
                raise HttpError(404, "Not found", "not_found")
            return self.serve_static(req)
        except HttpError as e:
            return Response({"error": {"code": e.code, "message": e.message}}, status=e.status)
        except Exception as e:  # never leak internals
            import traceback
            traceback.print_exc()
            return Response({"error": {"code": "internal", "message": "Internal server error"}}, status=500)

    def serve_static(self, req: Request) -> Response:
        if req.method != "GET" or not self.static_dir:
            raise HttpError(404, "Not found", "not_found")
        rel = req.path.lstrip("/") or "index.html"
        target = (self.static_dir / rel).resolve()
        root = self.static_dir.resolve()
        if root not in target.parents and target != root or not target.is_file():
            target = root / "index.html"  # SPA fallback (also covers path-traversal attempts)
            if not target.is_file():
                raise HttpError(404, "Not found", "not_found")
        ctype = mimetypes.guess_type(str(target))[0] or "application/octet-stream"
        return Response(raw=target.read_bytes(), content_type=ctype,
                        headers={"Cache-Control": "no-cache"})


def make_handler(app: App, max_body: int):
    class Handler(BaseHTTPRequestHandler):
        def log_message(self, *a):
            pass

        def _handle(self):
            parsed = urlparse(self.path)
            length = int(self.headers.get("Content-Length") or 0)
            if length > max_body:
                resp = Response({"error": {"code": "too_large", "message": "Request body too large"}}, status=413)
                self.rfile.read(0)
            else:
                body = self.rfile.read(length) if length else b""
                req = Request(self.command, parsed.path, parse_qs(parsed.query), self.headers, body, self.client_address[0])
                resp = app.dispatch(req)
            self.send_response(resp.status)
            self.send_header("Content-Type", resp.content_type)
            self.send_header("Content-Length", str(len(resp.raw)))
            self.send_header("X-Content-Type-Options", "nosniff")
            self.send_header("Content-Security-Policy", "default-src 'self'; style-src 'self' 'unsafe-inline'; img-src 'self' data:; media-src 'self' blob:")
            for k, v in resp.headers.items():
                self.send_header(k, v)
            self.end_headers()
            self.wfile.write(resp.raw)

        do_GET = do_POST = do_PUT = do_DELETE = _handle

    return Handler


def serve(app: App, host: str, port: int, max_body: int):
    ThreadingHTTPServer((host, port), make_handler(app, max_body)).serve_forever()
