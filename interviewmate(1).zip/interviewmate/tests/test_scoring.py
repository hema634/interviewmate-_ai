import unittest

from helpers import AppTestCase  # noqa: F401  (sets sys.path)
from interviewmate import scoring
from interviewmate.scoring import ValidationError, compute_total, validate_evaluation

TRANSCRIPT = "I used a PID controller because it removes steady state error. Then I tuned Kp first."
KEYS = list(scoring.CATEGORY_WEIGHTS)


def cat(score=None, status="scored", quote=None):
    ev = [{"quote": quote, "why_it_matters": "x"}] if quote else []
    return {"status": status, "score": score, "explanation": "e", "suggestion": "s", "evidence": ev}


def full(scores, quote="I used a PID controller"):
    return {"categories": {k: cat(v, quote=quote) for k, v in zip(KEYS, scores)}}


class ScoringTests(unittest.TestCase):
    def test_weights(self):
        self.assertAlmostEqual(sum(scoring.CATEGORY_WEIGHTS.values()), 1.0)
        self.assertEqual(scoring.CATEGORY_WEIGHTS, {"technical_correctness": .35, "communication": .25, "structure": .20, "relevance": .10, "improvement_potential": .10})

    def test_total_matches_specified_formula(self):
        s = dict(zip(KEYS, [80, 60, 70, 90, 50]))
        expected = 0.35 * 80 + 0.25 * 60 + 0.20 * 70 + 0.10 * 90 + 0.10 * 50
        r = compute_total({k: cat(v) for k, v in s.items()})
        self.assertAlmostEqual(r["total"], expected); self.assertAlmostEqual(r["total"], 71.0); self.assertFalse(r["partial"])

    def test_bounds(self):
        for v in (0, 100):
            self.assertEqual(compute_total({k: cat(v) for k in KEYS})["total"], float(v))

    def test_insufficient_evidence_renormalises_and_flags_partial(self):
        cats = {k: cat(80) for k in KEYS}
        cats["structure"] = cat(None, status="insufficient_evidence")
        r = compute_total(cats)
        self.assertTrue(r["partial"]); self.assertIn("structure", r["missing"]); self.assertNotIn("structure", r["weights_used"])
        self.assertAlmostEqual(r["total"], 80.0); self.assertAlmostEqual(sum(r["weights_used"].values()), 1.0, places=2)

    def test_nothing_scored_gives_no_total(self):
        self.assertIsNone(compute_total({k: cat(None, status="insufficient_evidence") for k in KEYS})["total"])

    def test_valid_exact_evidence_is_kept(self):
        out = validate_evaluation(full([80, 70, 60, 90, 50]), TRANSCRIPT)
        self.assertEqual(out["evidence_downgrades"], [])
        self.assertTrue(all(c["status"] == "scored" for c in out["categories"].values()))
        self.assertAlmostEqual(out["total"], 0.35 * 80 + 0.25 * 70 + 0.20 * 60 + 0.10 * 90 + 0.10 * 50)

    def test_fabricated_quote_is_downgraded_not_repaired(self):
        res = full([80, 70, 60, 90, 50])
        res["categories"]["communication"]["evidence"] = [{"quote": "I led a team of ten engineers", "why_it_matters": "x"}]
        out = validate_evaluation(res, TRANSCRIPT)
        c = out["categories"]["communication"]
        self.assertEqual((c["status"], c["score"], c["evidence"]), ("insufficient_evidence", None, []))
        self.assertTrue(out["partial"]); self.assertEqual(out["evidence_downgrades"][0]["category"], "communication")

    def test_quote_must_match_exactly(self):
        self.assertTrue(scoring.validate_evidence("I used a PID controller", TRANSCRIPT))
        self.assertFalse(scoring.validate_evidence("i used a pid controller", TRANSCRIPT))
        self.assertFalse(scoring.validate_evidence("", TRANSCRIPT))
        self.assertFalse(scoring.validate_evidence("   ", TRANSCRIPT))

    def test_invalid_scores_rejected(self):
        for bad in (-1, 101, "90", True, None):
            res = full([80, 70, 60, 90, 50]); res["categories"]["relevance"]["score"] = bad
            with self.subTest(bad=bad), self.assertRaises(ValidationError):
                validate_evaluation(res, TRANSCRIPT)

    def test_missing_category_or_field_rejected(self):
        res = full([80, 70, 60, 90, 50]); del res["categories"]["structure"]
        with self.assertRaises(ValidationError): validate_evaluation(res, TRANSCRIPT)
        res = full([80, 70, 60, 90, 50]); res["categories"]["relevance"]["explanation"] = ""
        with self.assertRaises(ValidationError): validate_evaluation(res, TRANSCRIPT)
        with self.assertRaises(ValidationError): validate_evaluation({"nope": 1}, TRANSCRIPT)


if __name__ == "__main__":
    unittest.main()
