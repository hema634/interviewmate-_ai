import unittest

import helpers  # noqa: F401
from interviewmate import scoring
from interviewmate.data.bank import QUESTIONS
from interviewmate.llm import LLMError
from interviewmate.services import evaluation

ANSWERS = [
    "I built a line follower robot using an Arduino and two IR sensors. First I read the sensors, then a PID loop adjusted the motors, because proportional alone oscillated. As a result it finished the track in 40 seconds.",
    "I don't know.",
    "Maybe it depends. I think it is good.",
    "An induction motor works because the stator creates a rotating magnetic field that induces current in the rotor, so torque is produced. Slip is the speed difference, for example 4 percent at full load.",
]


def qd(question):
    d = dict(question); d["misconceptions"] = [tuple(m) for m in question["misconceptions"]]; d["is_followup"] = False
    return d


def by_id(i): return qd(next(x for x in QUESTIONS if x["id"] == i))


class BrokenProvider:
    name, is_llm = "broken", True
    def complete_json(self, s, u): raise LLMError("down")


class FabricatingProvider:
    name, is_llm = "liar", True
    def complete_json(self, s, u):
        c = {"status": "scored", "score": 99, "explanation": "great", "suggestion": "none",
             "evidence": [{"quote": "this was never said", "why_it_matters": "x"}]}
        return {"categories": {k: dict(c) for k in scoring.CATEGORY_WEIGHTS}}


class EvaluationTests(unittest.TestCase):
    def test_every_question_quotes_exactly_and_total_matches_formula(self):
        for question in QUESTIONS:
            for answer in ANSWERS:
                with self.subTest(q=question["id"], a=answer[:20]):
                    ev = evaluation.evaluate_offline(qd(question), answer)
                    for key, c in ev["categories"].items():
                        if c["status"] == "scored":
                            self.assertTrue(c["evidence"], f"{key} scored without evidence")
                            self.assertTrue(0 <= c["score"] <= 100)
                        else:
                            self.assertIsNone(c["score"])
                        for e in c["evidence"]:
                            self.assertIn(e["quote"], answer, f"fabricated quote in {key}")
                    self.assertEqual(ev["total"], scoring.compute_total(ev["categories"])["total"])
                    self.assertTrue(ev["total"] is None or 0 <= ev["total"] <= 100)

    def test_dont_know_is_flagged_and_scores_below_a_good_answer(self):
        q = by_id("hr_intro")
        good = evaluation.evaluate_offline(q, ANSWERS[0] + " I am a final year student looking for a role.")
        dk = evaluation.evaluate_offline(q, "I don't know.")
        self.assertTrue(dk["flags"]["dont_know"])
        if good["total"] is not None and dk["total"] is not None:
            self.assertGreater(good["total"], dk["total"])

    def test_provider_failure_falls_back_with_notice(self):
        ev = evaluation.evaluate(BrokenProvider(), by_id("hr_intro"), ANSWERS[0], allow_external=True)
        self.assertEqual(ev["evaluator"], evaluation.EVALUATOR_NAME)
        self.assertTrue(any("unavailable" in l for l in ev["limitations"]))

    def test_llm_not_called_without_consent(self):
        class Spy(BrokenProvider):
            called = False
            def complete_json(self, s, u): Spy.called = True; raise LLMError("x")
        evaluation.evaluate(Spy(), by_id("hr_intro"), ANSWERS[0], allow_external=False)
        self.assertFalse(Spy.called)

    def test_llm_fabricated_evidence_never_scores(self):
        ev = evaluation.evaluate(FabricatingProvider(), by_id("hr_intro"), ANSWERS[0], allow_external=True)
        self.assertTrue(all(c["status"] == "insufficient_evidence" for c in ev["categories"].values()))
        self.assertIsNone(ev["total"]); self.assertTrue(ev["evidence_downgrades"])


if __name__ == "__main__":
    unittest.main()
