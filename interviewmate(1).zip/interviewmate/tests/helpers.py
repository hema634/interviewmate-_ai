"""Shared test helpers (standard library only; run with: python -m unittest discover -s tests)."""
import json
import os
import sys
import tempfile
import unittest
from urllib.parse import parse_qs

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "backend"))

from interviewmate.app import create_app  # noqa: E402
from interviewmate.config import Settings  # noqa: E402
from interviewmate.web import Request  # noqa: E402


class Client:
    def __init__(self, app, ip="1.1.1.1"):
        self.app, self.ip, self.token = app, ip, None

    def call(self, method, path, body=None, raw_body=None, headers=None, token="__own__"):
        h = dict(headers or {})
        tok = self.token if token == "__own__" else token
        if tok:
            h["Authorization"] = "Bearer " + tok
        data = raw_body if raw_body is not None else (json.dumps(body).encode() if body is not None else b"")
        path, _, qs = path.partition("?")
        resp = self.app.dispatch(Request(method, path, parse_qs(qs), h, data, self.ip))
        payload = json.loads(resp.raw) if resp.content_type.startswith("application/json") else resp.raw
        return resp.status, payload

    def get(self, p, **k): return self.call("GET", p, **k)
    def post(self, p, b=None, **k): return self.call("POST", p, b if b is not None else {}, **k)
    def put(self, p, b=None, **k): return self.call("PUT", p, b, **k)
    def delete(self, p, **k): return self.call("DELETE", p, **k)

    def register(self, email, pw="password123"):
        st, r = self.post("/api/auth/register", {"email": email, "password": pw})
        assert st == 200, r
        self.token = r["token"]
        return r["user"]

    def upload_multipart(self, path, filename, data, fields=None, field_name="file"):
        boundary = "XBOUNDARYX"
        parts = []
        for k, v in (fields or {}).items():
            parts.append(f'--{boundary}\r\nContent-Disposition: form-data; name="{k}"\r\n\r\n{v}\r\n'.encode())
        parts.append(f'--{boundary}\r\nContent-Disposition: form-data; name="{field_name}"; filename="{filename}"\r\nContent-Type: application/octet-stream\r\n\r\n'.encode() + data + b"\r\n")
        parts.append(f"--{boundary}--\r\n".encode())
        return self.call("POST", path, raw_body=b"".join(parts), headers={"Content-Type": f"multipart/form-data; boundary={boundary}"})


def make_env(db_path=None, provider=None):
    s = Settings.load()
    s.db_path = db_path or os.path.join(tempfile.mkdtemp(), "t.db")
    s.secret_key = "test-secret-key-0123456789abcdef"
    s.llm_provider = "offline"
    app, ctx = create_app(s)
    ctx.limiter.per_minute = ctx.auth_limiter.per_minute = 100000
    if provider:
        ctx.provider = ctx.sessions.provider = provider
    return app, ctx


class AppTestCase(unittest.TestCase):
    def setUp(self):
        self.app, self.ctx = make_env()
        self.alice = Client(self.app, "10.0.0.1"); self.alice.register("alice@example.com")
        self.bob = Client(self.app, "10.0.0.2"); self.bob.register("bob@example.com")
