"""Exercises the STT / TTS / LLM HTTP adapters against a local fake OpenAI-compatible server (no real keys)."""
import json
import threading
import unittest
from http.server import BaseHTTPRequestHandler, HTTPServer

from helpers import AppTestCase, Client, make_env
from interviewmate import scoring
from interviewmate.llm import OpenAICompatibleProvider
from interviewmate.services import evaluation
from interviewmate.web import HttpError

TRANSCRIPT = "I used a PID controller because it removes steady state error."
STATE = {"stt_text": "hello from the microphone", "chat_quote": "I used a PID controller"}


class Fake(BaseHTTPRequestHandler):
    def log_message(self, *a): pass

    def do_POST(self):
        body = self.rfile.read(int(self.headers.get("Content-Length", 0)))
        if self.headers.get("Authorization") != "Bearer test-key":
            self.send_response(401); self.end_headers(); return
        if self.path.endswith("/audio/transcriptions"):
            out, ctype = json.dumps({"text": STATE["stt_text"]}).encode(), "application/json"
        elif self.path.endswith("/audio/speech"):
            out, ctype = b"ID3fakeaudio", "audio/mpeg"
        else:
            cat = {"status": "scored", "score": 80, "explanation": "good", "suggestion": "add detail",
                   "evidence": [{"quote": STATE["chat_quote"], "why_it_matters": "shows method"}]}
            content = json.dumps({"categories": {k: dict(cat) for k in scoring.CATEGORY_WEIGHTS}})
            out, ctype = json.dumps({"choices": [{"message": {"content": content}}]}).encode(), "application/json"
        self.send_response(200); self.send_header("Content-Type", ctype); self.send_header("Content-Length", str(len(out))); self.end_headers(); self.wfile.write(out)


class ProviderTests(AppTestCase):
    @classmethod
    def setUpClass(cls):
        cls.srv = HTTPServer(("127.0.0.1", 0), Fake); cls.base = f"http://127.0.0.1:{cls.srv.server_port}/v1"
        threading.Thread(target=cls.srv.serve_forever, daemon=True).start()

    @classmethod
    def tearDownClass(cls): cls.srv.shutdown()

    def configure(self, **kw):
        for k, v in kw.items(): setattr(self.ctx.settings, k, v)

    def test_stt_transcribes_and_handles_silence_and_failure(self):
        self.configure(stt_base_url=self.base, stt_api_key="test-key")
        self.alice.put("/api/me", {"consent_audio": True})
        r = self.ctx.stt.transcribe("a.webm", b"x" * 2000, "audio/webm")
        self.assertEqual(r["text"], "hello from the microphone"); self.assertTrue(r["editable"])
        with self.assertRaises(HttpError) as e: self.ctx.stt.transcribe("a.webm", b"x" * 10, "audio/webm")
        self.assertEqual(e.exception.code, "silence")
        STATE["stt_text"] = "   "
        with self.assertRaises(HttpError) as e: self.ctx.stt.transcribe("a.webm", b"x" * 2000, "audio/webm")
        self.assertEqual(e.exception.code, "silence")
        STATE["stt_text"] = "hello from the microphone"
        self.configure(stt_api_key="wrong")
        with self.assertRaises(HttpError) as e: self.ctx.stt.transcribe("a.webm", b"x" * 2000, "audio/webm")
        self.assertEqual(e.exception.code, "stt_failed")

    def test_stt_endpoint_over_http_layer_and_unconfigured_fallback(self):
        self.alice.put("/api/me", {"consent_audio": True})
        st, body = self.alice.upload_multipart("/api/speech/transcribe", "a.webm", b"x" * 2000, field_name="audio")
        self.assertEqual((st, body["error"]["code"]), (503, "stt_unavailable"))  # typed fallback signalled
        self.configure(stt_base_url=self.base, stt_api_key="test-key")
        st, body = self.alice.upload_multipart("/api/speech/transcribe", "a.webm", b"x" * 2000, field_name="audio")
        self.assertEqual((st, body["text"]), (200, "hello from the microphone"))
        self.assertEqual(self.ctx.db.one("SELECT COUNT(*) n FROM uploaded_documents")["n"], 0)  # audio not persisted

    def test_tts(self):
        self.assertEqual(self.alice.post("/api/speech/synthesize", {"text": "hi"})[0], 503)
        self.configure(tts_base_url=self.base, tts_api_key="test-key", tts_model="tts-1")
        st, audio = self.alice.post("/api/speech/synthesize", {"text": "Hello"})
        self.assertEqual((st, audio), (200, b"ID3fakeaudio"))

    def test_llm_evaluator_accepts_exact_quotes_and_rejects_invented_ones(self):
        prov = OpenAICompatibleProvider(self.base, "test-key", "fake-model")
        q = {"id": "x", "text": "Q?", "answer_type": "technical", "concepts": [], "reference": "r", "misconceptions": [], "is_followup": False, "topic": "t", "category": "electrical"}
        STATE["chat_quote"] = "I used a PID controller"
        ev = evaluation.evaluate(prov, q, TRANSCRIPT, allow_external=True)
        self.assertTrue(ev["evaluator"].startswith("llm:")); self.assertAlmostEqual(ev["total"], 80.0)
        STATE["chat_quote"] = "a sentence the candidate never said"
        ev = evaluation.evaluate(prov, q, TRANSCRIPT, allow_external=True)
        self.assertIsNone(ev["total"]); self.assertTrue(ev["evidence_downgrades"])
        bad = OpenAICompatibleProvider(self.base, "wrong-key", "m")
        ev = evaluation.evaluate(bad, q, TRANSCRIPT, allow_external=True)
        self.assertEqual(ev["evaluator"], evaluation.EVALUATOR_NAME)  # provider failure -> graceful fallback
        STATE["chat_quote"] = "I used a PID controller"


if __name__ == "__main__":
    unittest.main()
