// Safe DOM helpers: text is always inserted as text nodes (never HTML), so uploaded resumes and
// transcripts cannot inject markup.
const SVGNS = 'http://www.w3.org/2000/svg';

function apply(el, attrs) {
  for (const [k, v] of Object.entries(attrs || {})) {
    if (v === null || v === undefined || v === false) continue;
    if (k.startsWith('on') && typeof v === 'function') el.addEventListener(k.slice(2).toLowerCase(), v);
    else if (k === 'class') el.setAttribute('class', v);
    else if (k === 'value') el.value = v;
    else if (k === 'checked') el.checked = !!v;
    else if (k === 'disabled') el.disabled = !!v;
    else if (v === true) el.setAttribute(k, '');
    else el.setAttribute(k, String(v));
  }
}
function append(el, children) {
  for (const c of children) {
    if (c === null || c === undefined || c === false) continue;
    if (Array.isArray(c)) append(el, c);
    else if (typeof c === 'object' && c.nodeType) el.appendChild(c);
    else el.appendChild(document.createTextNode(String(c)));
  }
}
export function h(tag, attrs, ...children) {
  const el = document.createElement(tag);
  apply(el, attrs); append(el, children); return el;
}
export function s(tag, attrs, ...children) {
  const el = document.createElementNS(SVGNS, tag);
  apply(el, attrs); append(el, children); return el;
}
export function clear(el) { while (el.firstChild) el.removeChild(el.firstChild); return el; }
export function mount(el, ...nodes) { clear(el); append(el, nodes); return el; }

export function fmtTime(sec) {
  sec = Math.max(0, Math.floor(sec));
  return String(Math.floor(sec / 60)).padStart(2, '0') + ':' + String(sec % 60).padStart(2, '0');
}
export function fmtScore(x) { return x === null || x === undefined ? '—' : (Number.isInteger(x) ? String(x) : x.toFixed(1)); }
export function fmtDate(d) {
  if (!d) return '—';
  const t = new Date(String(d).replace(' ', 'T') + (String(d).includes('Z') ? '' : 'Z'));
  return isNaN(t) ? String(d) : t.toLocaleString(undefined, { dateStyle: 'medium', timeStyle: 'short' });
}
export function modeLabel(m) {
  return { hr: 'HR & Behavioral', software: 'Software Technical', electrical: 'Electrical & Control', project: 'Project Viva', mixed: 'Mixed HR + Technical' }[m] || m;
}
export function toast(msg, ms = 3200) {
  const t = h('div', { class: 'toast', role: 'status' }, msg);
  document.body.appendChild(t); setTimeout(() => t.remove(), ms);
}
export function scoreTone(x) { return x === null || x === undefined ? 'warn' : x >= 75 ? 'ok' : x >= 50 ? 'warn' : 'bad'; }
export function lines(text) { return String(text || '').split(/\r?\n/).map(x => x.trim()).filter(Boolean); }
export function csv(text) { return String(text || '').split(/[,\n]/).map(x => x.trim()).filter(Boolean); }
