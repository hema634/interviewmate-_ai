import { h, mount } from './util.js';
import { api, auth } from './api.js';
import { banner } from './components.js';
import * as core from './pages_core.js';
import * as iv from './pages_interview.js';
import { results } from './pages_results.js';

const root = document.getElementById('app');

const ctx = {
  user: null,
  go(path) { location.hash = '#' + path; },
  query() { const q = location.hash.split('?')[1] || ''; return Object.fromEntries(new URLSearchParams(q)); },
};

const NAV = [
  ['/dashboard', 'Dashboard'], ['/start', 'Start Interview'], ['/history', 'Interview History'], ['/progress', 'Progress Analytics'],
  ['/plan', 'Improvement Plan'], ['/rubric', 'Evaluation Rubric'], ['/settings', 'Settings & Privacy'],
];
// route -> [handler, needsAuth]
const ROUTES = {
  '': [core.landing, false], '/': [core.landing, false], '/auth': [core.authPage, false],
  '/dashboard': [core.dashboard, true], '/start': [iv.startPage, true], '/history': [core.history, true], '/progress': [core.progress, true],
  '/plan': [core.plan, true], '/rubric': [core.rubric, false], '/settings': [core.settings, true],
  '/interview': [iv.liveInterview, true], '/results': [results, true],
};

let cleanup = null;
let renderToken = 0;

function shell(path, content) {
  const side = h('aside', { class: 'side', id: 'side', 'aria-label': 'Main navigation' },
    h('div', { class: 'brand gold-text' }, 'InterviewMate AI'),
    h('nav', { class: 'nav' }, NAV.map(([p, label]) => h('a', { href: '#' + p, 'aria-current': path === p || (p !== '/' && path.startsWith(p + '/')) ? 'page' : null, onclick: () => side.classList.remove('open') }, label))),
    h('div', { style: 'margin-top:24px' }, ctx.user ? h('p', { class: 'muted small' }, ctx.user.email) : null,
      h('button', { class: 'btn small ghost', onclick: () => { auth.set(null); ctx.user = null; ctx.go('/'); } }, 'Sign out')));
  const top = h('div', { class: 'topbar' }, h('span', { class: 'brand gold-text', style: 'margin:0' }, 'InterviewMate AI'),
    h('button', { class: 'btn small', 'aria-controls': 'side', onclick: () => side.classList.toggle('open') }, 'Menu'));
  return h('div', {}, top, h('div', { class: 'shell' }, side, h('main', { class: 'main', id: 'main' }, content)));
}

async function render() {
  const token = ++renderToken;
  if (cleanup) { try { cleanup(); } catch (e) { /* ignore */ } cleanup = null; }
  const [pathRaw] = location.hash.replace(/^#/, '').split('?');
  const parts = pathRaw.split('/').filter(Boolean);
  const base = '/' + (parts[0] || ''), param = parts[1];
  const entry = ROUTES[base === '/' ? '/' : base] || ROUTES[pathRaw];
  if (!entry) { mount(root, banner('Page not found.', 'err'), h('a', { class: 'btn', href: '#/' }, 'Home')); return; }
  const [handler, needsAuth] = entry;
  if (needsAuth && !auth.token) { ctx.go('/auth?next=' + (parts[0] || 'dashboard')); return; }
  if (auth.token && !ctx.user) {
    try { ctx.user = await api('/api/me'); } catch (e) { auth.set(null); if (needsAuth) { ctx.go('/auth'); return; } }
  }
  if (token !== renderToken) return;
  const standalone = base === '/' || base === '' || base === '/auth';
  if (standalone) { cleanup = await handler(root, ctx, param) || null; return; }
  const content = h('div', {});
  mount(root, shell(base, content));
  document.title = (NAV.find(n => n[0] === base) || ['', 'InterviewMate AI'])[1] + ' — InterviewMate AI';
  const c = await handler(content, ctx, param);
  if (token === renderToken) cleanup = c || null; else if (typeof c === 'function') c();
  const m = document.getElementById('main'); if (m) m.focus && window.scrollTo(0, 0);
}

window.addEventListener('hashchange', render);
window.addEventListener('im-logout', () => { ctx.user = null; ctx.go('/auth'); });
render();
