import { s } from './util.js';

export function lineChart(points, { width = 640, height = 220, min = 0, max = 100, label = 'Score trend' } = {}) {
  const pad = { l: 36, r: 14, t: 14, b: 28 };
  const w = width - pad.l - pad.r, hh = height - pad.t - pad.b;
  const n = points.length;
  const x = i => pad.l + (n <= 1 ? w / 2 : (i * w) / (n - 1));
  const y = v => pad.t + hh - ((v - min) / (max - min)) * hh;
  const svg = s('svg', { viewBox: `0 0 ${width} ${height}`, class: 'chart', role: 'img', 'aria-label': label, width: '100%' });
  for (const g of [0, 25, 50, 75, 100]) {
    svg.appendChild(s('line', { x1: pad.l, x2: width - pad.r, y1: y(g), y2: y(g), stroke: '#2a3142', 'stroke-width': 1 }));
    svg.appendChild(s('text', { x: pad.l - 6, y: y(g) + 4, 'text-anchor': 'end' }, String(g)));
  }
  const valid = points.map((p, i) => ({ ...p, i })).filter(p => p.value !== null && p.value !== undefined);
  if (valid.length > 1) {
    svg.appendChild(s('polyline', { fill: 'none', stroke: '#d4af37', 'stroke-width': 2.5, points: valid.map(p => `${x(p.i)},${y(p.value)}`).join(' ') }));
  }
  for (const p of valid) {
    svg.appendChild(s('circle', { cx: x(p.i), cy: y(p.value), r: 4.5, fill: p.demo ? '#0a0e1a' : '#f3d77a', stroke: '#d4af37', 'stroke-width': 2 },
      s('title', {}, `${p.label}: ${p.value}${p.demo ? ' (demo)' : ''}`)));
    svg.appendChild(s('text', { x: x(p.i), y: height - 8, 'text-anchor': 'middle' }, p.label));
  }
  return svg;
}

export function barChart(items, { width = 640, rowH = 30, label = 'Averages' } = {}) {
  const pad = { l: 170, r: 50 };
  const height = items.length * rowH + 8;
  const svg = s('svg', { viewBox: `0 0 ${width} ${height}`, class: 'chart', role: 'img', 'aria-label': label, width: '100%' });
  items.forEach((it, i) => {
    const y = i * rowH + 4, bw = width - pad.l - pad.r;
    svg.appendChild(s('text', { x: pad.l - 8, y: y + 17, 'text-anchor': 'end' }, it.label));
    svg.appendChild(s('rect', { x: pad.l, y: y + 5, width: bw, height: 14, rx: 7, fill: '#0a0e1a', stroke: '#2a3142' }));
    if (it.value !== null && it.value !== undefined) {
      svg.appendChild(s('rect', { x: pad.l, y: y + 5, width: Math.max(2, (it.value / 100) * bw), height: 14, rx: 7, fill: '#d4af37' }));
    }
    svg.appendChild(s('text', { x: width - pad.r + 8, y: y + 17 }, it.value === null || it.value === undefined ? 'n/a' : String(it.value)));
  });
  return svg;
}
