import { h, mount, fmtScore, fmtDate, modeLabel, toast, scoreTone } from './util.js';
import { api, download } from './api.js';
import { banner, guard, bar, evaluationView, coachPanel, CAT_LABELS } from './components.js';

function signed(n) { return n === null || n === undefined ? '—' : (n > 0 ? '+' : '') + n; }

export function comparisonView(c, firstText, secondText) {
  const tone = c.score_change === null ? 'warn' : c.score_change > 0 ? 'ok' : c.score_change < 0 ? 'bad' : 'warn';
  const list = (title, items, empty) => h('div', {}, h('strong', {}, title),
    items && items.length ? h('ul', {}, items.map(i => h('li', {}, i))) : h('p', { class: 'muted small' }, empty));
  return h('div', {},
    h('div', { class: 'row spread' },
      h('div', {}, h('span', { class: 'score', style: 'font-size:30px' }, fmtScore(c.first_total)), h('span', { class: 'muted' }, '  →  '),
        h('span', { class: 'score', style: 'font-size:30px' }, fmtScore(c.second_total))),
      h('span', { class: 'tag ' + tone }, 'Score change (second − first): ' + signed(c.score_change))),
    (firstText || secondText) ? h('div', { class: 'compare', style: 'margin:12px 0' },
      h('div', { class: 'card flat' }, h('strong', {}, 'First attempt'), h('p', { class: 'small' }, firstText || '')),
      h('div', { class: 'card flat' }, h('strong', {}, 'Revised attempt'), h('p', { class: 'small' }, secondText || ''))) : null,
    h('table', {}, h('thead', {}, h('tr', {}, ['Category', 'First', 'Revised', 'Change'].map(x => h('th', {}, x)))),
      h('tbody', {}, Object.values(c.categories).map(r => h('tr', {}, h('td', {}, r.label), h('td', {}, fmtScore(r.first)), h('td', {}, fmtScore(r.second)),
        h('td', { class: 'score' }, signed(r.change)))))),
    h('div', { class: 'grid g2', style: 'margin-top:12px' },
      list('Technical concepts now covered', c.technical_concepts_now_covered, 'No new concepts covered.'),
      list('Misconceptions corrected', c.misconceptions_corrected, 'None to correct, or none corrected.'),
      list('New transcript evidence', (c.new_evidence_quotes || []).map(q => '“' + q + '”'), 'No new evidence quotes.'),
      list('Remaining gaps', c.remaining_gaps, 'No gaps left against the rubric.')),
    h('p', { class: 'small' }, c.clarity_note),
    h('p', { class: 'muted small' }, c.disclaimer));
}

export async function results(root, ctx, idParam) {
  const sid = Number(idParam);
  mount(root, h('p', { class: 'muted' }, 'Loading results…'));
  await guard(root, async () => {
    const [sess, rep] = await Promise.all([api('/api/sessions/' + sid), api('/api/sessions/' + sid + '/report')]);
    if (sess.status !== 'completed') { ctx.go('/interview/' + sid); return; }
    const retriesBox = h('div', {});
    const drawRetries = async () => {
      const rs = await api('/api/sessions/' + sid + '/retries');
      retriesBox.replaceChildren(rs.length ? h('div', {}, rs.map(r => h('div', { class: 'card flat', style: 'margin:10px 0' },
        h('strong', {}, r.question), comparisonView(r.comparison, r.original_answer, r.revised_answer)))) : h('p', { class: 'muted' }, 'No retries yet. Use “Retry this question” on any answered question below.'));
    };

    const qCards = sess.questions.map(q => {
      if (!q.answers.length) return h('div', { class: 'card', style: 'margin-top:12px' }, h('strong', {}, 'Q' + q.seq + '. ' + q.text), h('p', { class: 'muted small' }, 'Status: ' + q.status + ' (not scored)'));
      const first = q.answers[0];
      const retryOut = h('div', {});
      const ta = h('textarea', { 'aria-label': 'Revised answer', placeholder: 'Write an improved answer to the same question…' });
      const retryBox = h('details', { style: 'margin-top:10px' }, h('summary', {}, h('span', { class: 'btn small' }, 'Retry this question')),
        h('div', { style: 'margin-top:10px' }, ta,
          h('button', { class: 'btn primary small', style: 'margin-top:8px', onclick: async (e) => {
            const text = ta.value.trim(); if (!text) { toast('Write a revised answer first.'); return; }
            e.target.disabled = true;
            try {
              const r = await api('/api/sessions/' + sid + '/retry', { method: 'POST', body: { question_id: q.id, text, allow_external: !!ctx.user.consent_ai_processing } });
              retryOut.replaceChildren(h('div', { class: 'card flat', style: 'margin-top:10px' }, h('h3', {}, 'Retry comparison'), comparisonView(r.comparison, first.text, text),
                h('details', {}, h('summary', { class: 'small muted' }, 'Full evaluation of the revised answer'), evaluationView(r.revised_evaluation, { evaluationId: r.revised_evaluation.evaluation_id }))));
              drawRetries();
            } catch (ex) { toast(ex.message); }
            e.target.disabled = false;
          } }, 'Submit revised answer'), retryOut));
      return h('div', { class: 'card', style: 'margin-top:12px' },
        h('div', { class: 'row spread' }, h('strong', {}, 'Q' + q.seq + '. ' + q.text), h('span', {}, h('span', { class: 'tag gold' }, q.topic), q.is_followup ? h('span', { class: 'tag ok' }, 'follow-up') : null)),
        h('div', { class: 'card flat', style: 'margin:10px 0' }, h('span', { class: 'tag' }, 'Your answer (' + first.source + ')'), h('p', { class: 'small', style: 'white-space:pre-wrap;margin:6px 0 0' }, first.text)),
        first.evaluation ? h('details', {}, h('summary', {}, h('span', { class: 'score' }, fmtScore(first.evaluation.total) + ' / 100'), h('span', { class: 'muted small' }, '  — show scoring, transcript evidence and feedback')),
          evaluationView(first.evaluation, { evaluationId: first.evaluation.evaluation_id })) : null,
        h('details', { style: 'margin-top:8px' }, h('summary', { class: 'small muted' }, 'Coaching actions'), coachPanel(sid, q.id)),
        retryBox);
    });

    const cs = rep.category_scores;
    mount(root,
      h('div', { class: 'row spread' }, h('h1', {}, 'Interview Results'), h('div', { class: 'row' },
        h('button', { class: 'btn', onclick: () => download('/api/sessions/' + sid + '/report.html', '', true).catch(e => toast(e.message)) }, 'Print-friendly report'),
        h('button', { class: 'btn primary', onclick: () => download('/api/sessions/' + sid + '/report.pdf', 'interviewmate-report-' + sid + '.pdf').catch(e => toast(e.message)) }, 'Download PDF'),
        h('a', { class: 'btn', href: '#/plan/' + sid }, '7-day plan'))),
      sess.is_demo ? banner('DEMO session: sample data, clearly labelled. It is not a record of your own performance.') : null,
      h('div', { class: 'card' },
        h('div', { class: 'row spread' },
          h('div', {}, h('div', { class: 'muted small' }, modeLabel(sess.mode) + ' · ' + sess.target_role + ' · ' + sess.difficulty + ' · ' + fmtDate(sess.completed_at)),
            h('div', {}, h('span', { class: 'score gold-text', style: 'font-size:44px' }, fmtScore(sess.overall_score)), h('span', { class: 'muted' }, ' / 100  overall (mean of first attempts)'))),
          h('span', { class: 'tag' }, 'AI-generated · practice indicator, not a hiring prediction')),
        Object.entries(CAT_LABELS).map(([k, label]) => {
          const v = cs[label]; const avg = v ? v.average : null;
          return h('div', { class: 'row', style: 'margin:6px 0;flex-wrap:nowrap' }, h('div', { style: 'flex:0 0 190px' }, label, h('span', { class: 'muted small' }, ' · ' + Math.round(rep.weights[label] * 100) + '%')),
            h('div', { style: 'flex:1' }, bar(avg)), h('div', { class: 'score', style: 'flex:0 0 120px;text-align:right' }, avg === null || avg === undefined ? 'insufficient evidence' : fmtScore(avg)));
        })),
      h('div', { class: 'grid g2', style: 'margin-top:16px' },
        h('div', { class: 'card' }, h('h3', {}, 'Technical strengths (observed against rubric)'), rep.technical_strengths.length ? h('ul', {}, rep.technical_strengths.slice(0, 12).map(x => h('li', {}, x))) : h('p', { class: 'muted' }, 'None observed yet.')),
        h('div', { class: 'card' }, h('h3', {}, 'Knowledge gaps'), rep.technical_gaps.length ? h('ul', {}, rep.technical_gaps.slice(0, 12).map(x => h('li', {}, x))) : h('p', { class: 'muted' }, 'No gaps against the rubrics.'))),
      rep.not_assessed.length ? h('div', { class: 'card', style: 'margin-top:16px' }, h('h3', {}, 'Could not be assessed reliably'),
        h('ul', { class: 'small' }, rep.not_assessed.slice(0, 10).map(n => h('li', {}, n.category + ' — ' + n.reason)))) : null,
      rep.study_topics && rep.study_topics.length ? h('div', { class: 'card', style: 'margin-top:16px' }, h('h3', {}, 'Recommended topics to study (AI suggestion)'), h('p', {}, rep.study_topics.map(t => h('span', { class: 'tag gold' }, typeof t === 'string' ? t : (t.topic || JSON.stringify(t)))))) : null,
      h('h2', { style: 'margin-top:28px' }, 'Question-by-question review'), ...qCards,
      h('h2', { style: 'margin-top:28px' }, 'Retry comparisons'), retriesBox,
      h('p', { class: 'muted small', style: 'margin-top:24px' }, rep.labels.observed + ' ' + rep.labels.ai + ' ' + rep.labels.unassessed + ' ' + rep.labels.disclaimer));
    await drawRetries();
  }, mount);
}
