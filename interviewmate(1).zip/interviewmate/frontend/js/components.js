import { h, fmtScore, scoreTone } from './util.js';
import { api } from './api.js';
import { toast } from './util.js';

export const CAT_LABELS = {
  technical_correctness: 'Technical Correctness', communication: 'Communication', structure: 'Structure / STAR',
  relevance: 'Relevance', improvement_potential: 'Improvement Potential',
};
export const CAT_WEIGHTS = { technical_correctness: 35, communication: 25, structure: 20, relevance: 10, improvement_potential: 10 };

export function banner(msg, kind = '') { return h('div', { class: 'banner ' + kind, role: kind === 'err' ? 'alert' : 'status' }, msg); }

export async function guard(root, fn, mount) {
  try { return await fn(); }
  catch (e) {
    mount(root, banner(e.message || 'Something went wrong.', 'err'), h('a', { class: 'btn', href: '#/dashboard' }, 'Back to dashboard'));
  }
}

export function bar(value) {
  return h('div', { class: 'bar', role: 'img', 'aria-label': value === null || value === undefined ? 'not scored' : 'score ' + value + ' of 100' },
    h('i', { style: 'width:' + (value === null || value === undefined ? 0 : Math.max(0, Math.min(100, value))) + '%' }));
}

export function categoryRows(categories) {
  return Object.keys(CAT_LABELS).map(k => {
    const c = categories[k];
    return h('div', { class: 'row', style: 'margin:6px 0;flex-wrap:nowrap' },
      h('div', { style: 'flex:0 0 190px' }, CAT_LABELS[k], h('span', { class: 'muted small' }, ' · ' + CAT_WEIGHTS[k] + '%')),
      h('div', { style: 'flex:1' }, bar(c.score)),
      h('div', { class: 'score', style: 'flex:0 0 60px;text-align:right' }, c.status === 'scored' ? fmtScore(c.score) : 'n/a'));
  });
}

export function evaluationView(ev, { evaluationId, onFlagged } = {}) {
  const tone = scoreTone(ev.total);
  const wrap = h('div', {});
  wrap.appendChild(h('div', { class: 'row spread' },
    h('div', {}, h('span', { class: 'score', style: 'font-size:34px' }, fmtScore(ev.total)), h('span', { class: 'muted' }, ' / 100'),
      ' ', h('span', { class: 'tag ' + tone }, ev.partial ? 'partial score' : 'full score'),
      h('span', { class: 'tag' }, 'AI-generated · ' + ev.evaluator)),
  ));
  if (ev.partial) {
    wrap.appendChild(banner('Some categories could not be assessed reliably, so the total uses only the scored categories (weights renormalised: ' +
      Object.entries(ev.weights_used || {}).map(([k, v]) => CAT_LABELS[k] + ' ' + Math.round(v * 100) + '%').join(', ') + ').'));
  }
  if (ev.evidence_downgrades && ev.evidence_downgrades.length) {
    wrap.appendChild(banner('A model-provided quote did not match the transcript exactly, so that category was not scored.', 'err'));
  }
  for (const k of Object.keys(CAT_LABELS)) {
    const c = ev.categories[k];
    const block = h('div', { class: 'cat' },
      h('div', { class: 'row spread' }, h('strong', {}, CAT_LABELS[k]),
        h('span', {}, c.status === 'scored' ? h('span', { class: 'score' }, fmtScore(c.score) + ' / 100') : h('span', { class: 'tag warn' }, 'Insufficient evidence'),
          c.confidence ? h('span', { class: 'tag' }, 'confidence: ' + c.confidence) : null)),
      bar(c.score),
      h('p', { class: 'small', style: 'margin-top:8px' }, c.explanation),
      ...(c.evidence || []).map(e => h('blockquote', { class: 'ev' }, '“' + e.quote + '”', h('div', { class: 'muted small' }, 'Why it matters: ' + e.why_it_matters))),
      h('p', { class: 'small muted' }, h('strong', {}, 'Suggestion (AI): '), c.suggestion));
    wrap.appendChild(block);
  }
  const fb = ev.feedback;
  if (fb) {
    const list = (title, items) => items && items.length ? h('div', {}, h('strong', {}, title), h('ul', {}, items.map(i => h('li', {}, i)))) : null;
    wrap.appendChild(h('div', { class: 'card flat', style: 'margin-top:12px' },
      list('What was good', fb.good), list('What was missing', fb.missing), list('What was incorrect', fb.incorrect), list('How to improve', fb.improve),
      h('p', { class: 'muted small' }, fb.label)));
  }
  wrap.appendChild(h('details', { style: 'margin-top:10px' }, h('summary', { class: 'small muted' }, 'Evaluation limitations'),
    h('ul', { class: 'small muted' }, (ev.limitations || []).map(l => h('li', {}, l)))));
  if (evaluationId) {
    wrap.appendChild(h('button', {
      class: 'btn small ghost', onclick: async () => {
        const msg = prompt('What looks incorrect about this evaluation? (e.g., a correct technical point that was missed)');
        if (!msg) return;
        try { await api('/api/evaluations/' + evaluationId + '/flag', { method: 'POST', body: { message: msg } }); toast('Thanks — flagged for review.'); onFlagged && onFlagged(); }
        catch (e) { toast(e.message); }
      }
    }, 'Flag this evaluation as incorrect'));
  }
  return wrap;
}

export const COACH_ACTIONS = [
  ['why_weak', 'Why was my answer weak?'], ['better_answer', 'Show me a better answer'], ['next_followup', 'What follow-up may come next?'],
  ['shorter_clearer', 'Make this answer shorter and clearer'], ['explain_concept', 'Explain the missing technical concept'], ['practice_example', 'Give me a practice example'],
];

export function coachPanel(sessionId, questionId) {
  const out = h('div', { 'aria-live': 'polite' });
  const row = h('div', { class: 'row' }, COACH_ACTIONS.map(([a, label]) => h('button', {
    class: 'btn small', onclick: async () => {
      out.replaceChildren(h('p', { class: 'muted small' }, 'Thinking…'));
      try {
        const r = await api('/api/sessions/' + sessionId + '/coach', { method: 'POST', body: { question_id: questionId, action: a } });
        out.replaceChildren(h('div', { class: 'card flat', style: 'margin-top:10px' }, h('strong', {}, r.title),
          h('p', { class: 'tag gold', style: 'display:block;margin:6px 0' }, r.label),
          r.text ? h('p', {}, r.text) : null,
          r.items ? h('ul', {}, r.items.map(i => h('li', {}, i))) : null,
          r.reference ? h('p', { class: 'muted small' }, 'Reference note: ' + r.reference) : null));
      } catch (e) { out.replaceChildren(banner(e.message, 'err')); }
    }
  }, label)));
  return h('div', {}, row, out);
}
