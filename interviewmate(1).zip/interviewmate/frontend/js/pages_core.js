import { h, mount, fmtDate, fmtScore, modeLabel, toast, scoreTone } from './util.js';
import { api, auth, download } from './api.js';
import { banner, guard, bar, categoryRows, CAT_LABELS } from './components.js';
import { lineChart, barChart } from './charts.js';

// ---------------- landing ----------------
export function landing(root, ctx) {
  const feat = (t, d) => h('div', { class: 'card feature' }, h('h3', {}, t), h('p', { class: 'muted' }, d));
  mount(root, h('div', { class: 'land' },
    h('nav', {}, h('div', { class: 'brand gold-text' }, 'InterviewMate AI'),
      h('div', { class: 'row' }, h('a', { class: 'btn ghost', href: '#/rubric' }, 'How scoring works'),
        auth.token ? h('a', { class: 'btn', href: '#/dashboard' }, 'Open dashboard') : h('a', { class: 'btn', href: '#/auth' }, 'Sign in'))),
    h('section', { class: 'hero' },
      h('h1', {}, 'Practice interviews that ', h('span', { class: 'gold-text' }, 'adapt to you')),
      h('p', {}, 'An AI mock interviewer for HR rounds, technical interviews, project vivas, and coding practice — personalised from your resume and the job description, scored with a rubric you can inspect.'),
      h('a', { class: 'btn primary', href: auth.token ? '#/start' : '#/auth?next=start', style: 'font-size:17px;padding:13px 26px' }, 'Start Practicing')),
    h('section', { class: 'grid g3' },
      feat('Personalised questions', 'Upload a resume and job description, review what was extracted, correct it, then get questions based on your real background.'),
      feat('Adaptive follow-ups', 'Vague answers get a clarifying follow-up, incorrect claims get a diagnostic one, strong answers move to deeper topics.'),
      feat('Exact transcript evidence', 'Every score cites the exact words you said. If something cannot be assessed reliably, it says so instead of guessing.'),
      feat('Retry and compare', 'Retry any question and see category-by-category changes, concepts you fixed, and what is still missing.'),
      feat('Voice or typed', 'Answer by voice (editable transcript) or typing. Audio is never stored by default.'),
      feat('Seven-day plan', 'A personalised plan with daily topics, practice tasks, time estimates, and measurable completion criteria.')),
    h('section', { class: 'card', style: 'margin-top:28px' }, h('h3', {}, 'Honest by design'),
      h('p', { class: 'muted' }, 'Scores are practice indicators, not predictions of any hiring decision. A rubric does not make an AI unbiased, so every evaluation shows its evidence and limitations and can be flagged. Your documents are only sent to an external AI provider if one is configured and you opt in.'))));
}

// ---------------- auth ----------------
export function authPage(root, ctx) {
  let mode = 'login';
  const q = ctx.query();
  const err = h('div', { 'aria-live': 'assertive' });
  const form = h('form', { onsubmit: async (e) => {
    e.preventDefault();
    const fd = new FormData(form);
    err.replaceChildren();
    try {
      const r = await api('/api/auth/' + mode, { method: 'POST', body: { email: fd.get('email'), password: fd.get('password'), display_name: fd.get('display_name') || '' } });
      auth.set(r.token); ctx.user = r.user;
      ctx.go(q.next ? '/' + q.next : '/dashboard');
    } catch (ex) { err.replaceChildren(banner(ex.message, 'err')); }
  } });
  const draw = () => {
    form.replaceChildren(
      mode === 'register' ? h('div', {}, h('label', { for: 'dn' }, 'Name (optional)'), h('input', { id: 'dn', type: 'text', name: 'display_name', autocomplete: 'name' })) : null,
      h('label', { for: 'em' }, 'Email'), h('input', { id: 'em', type: 'email', name: 'email', required: true, autocomplete: 'email' }),
      h('label', { for: 'pw' }, mode === 'register' ? 'Password (8+ characters)' : 'Password'),
      h('input', { id: 'pw', type: 'password', name: 'password', required: true, minlength: 8, autocomplete: mode === 'register' ? 'new-password' : 'current-password' }),
      h('div', { class: 'row', style: 'margin-top:16px' }, h('button', { class: 'btn primary', type: 'submit' }, mode === 'register' ? 'Create account' : 'Sign in')));
    tabs.replaceChildren(
      h('button', { role: 'tab', 'aria-selected': String(mode === 'login'), onclick: () => { mode = 'login'; draw(); } }, 'Sign in'),
      h('button', { role: 'tab', 'aria-selected': String(mode === 'register'), onclick: () => { mode = 'register'; draw(); } }, 'Create account'));
  };
  const tabs = h('div', { class: 'tabs', role: 'tablist' });
  mount(root, h('div', { style: 'max-width:440px;margin:60px auto;padding:0 16px' },
    h('a', { href: '#/', class: 'brand gold-text', style: 'text-decoration:none;display:block' }, 'InterviewMate AI'),
    h('div', { class: 'card' }, tabs, err, form, h('p', { class: 'muted small', style: 'margin-top:14px' }, 'Email + password. We store only what the features need; you can delete everything from Settings.'))));
  draw();
}

// ---------------- dashboard ----------------
export async function dashboard(root, ctx) {
  mount(root, h('p', { class: 'muted' }, 'Loading…'));
  await guard(root, async () => {
    const d = await api('/api/dashboard');
    const rec = d.recommendation;
    mount(root,
      h('h1', {}, 'Welcome back' + (ctx.user.display_name ? ', ' + ctx.user.display_name : '')),
      d.sessions_completed === 0 ? h('div', { class: 'banner' }, h('strong', {}, 'New here? '), 'Start a practice interview, or ',
        h('button', { class: 'btn small', onclick: async (e) => {
          e.target.disabled = true;
          try { const r = await api('/api/demo', { method: 'POST', body: {} }); toast('Demo session loaded (sample data).'); ctx.go('/results/' + r.session_id); }
          catch (ex) { toast(ex.code === 'consent_required' ? 'Grant document consent in Settings first.' : ex.message); e.target.disabled = false; }
        } }, 'load a labelled DEMO session'), ' to see how results look.') : null,
      h('div', { class: 'grid g4' },
        h('div', { class: 'card stat' }, h('div', { class: 'v' }, String(d.sessions_completed)), h('div', { class: 'l' }, 'Completed sessions')),
        h('div', { class: 'card stat' }, h('div', { class: 'v gold-text' }, fmtScore(d.average_score)), h('div', { class: 'l' }, 'Average score')),
        ...Object.entries(CAT_LABELS).slice(0, 2).map(([k, l]) => h('div', { class: 'card stat' }, h('div', { class: 'v' }, fmtScore(d.category_averages[k])), h('div', { class: 'l' }, l + ' (avg)')))),
      h('div', { class: 'grid g2', style: 'margin-top:16px' },
        h('div', { class: 'card' }, h('h3', {}, 'Next recommended practice'),
          h('p', {}, rec.reason), h('p', {}, h('span', { class: 'tag gold' }, modeLabel(rec.mode)), rec.focus ? h('span', { class: 'tag' }, 'focus: ' + rec.focus) : null),
          h('a', { class: 'btn primary', href: '#/start?mode=' + rec.mode }, 'Start this practice')),
        h('div', { class: 'card' }, h('h3', {}, 'Weak areas'),
          d.weak_areas.length ? h('table', {}, h('tbody', {}, d.weak_areas.map(w => h('tr', {}, h('td', {}, w.topic), h('td', {}, bar(w.average)), h('td', { class: 'score' }, fmtScore(w.average)))))) : h('p', { class: 'muted' }, 'Complete a session to see weak areas.'))),
      h('div', { class: 'card', style: 'margin-top:16px' }, h('h3', {}, 'Recent sessions'), sessionTable(d.recent_sessions)));
  }, mount);
}

export function sessionTable(rows, onDelete) {
  if (!rows.length) return h('p', { class: 'muted' }, 'No sessions yet.');
  return h('div', { style: 'overflow:auto' }, h('table', {}, h('thead', {}, h('tr', {}, ['Date', 'Mode', 'Role', 'Status', 'Score', ''].map(x => h('th', {}, x)))),
    h('tbody', {}, rows.map(r => h('tr', {},
      h('td', {}, fmtDate(r.created_at)), h('td', {}, modeLabel(r.mode), r.is_demo ? h('span', { class: 'tag warn' }, 'DEMO') : null), h('td', {}, r.target_role),
      h('td', {}, h('span', { class: 'tag ' + (r.status === 'completed' ? 'ok' : 'gold') }, r.status)),
      h('td', { class: 'score' }, fmtScore(r.overall_score)),
      h('td', {}, h('div', { class: 'row' },
        r.status === 'completed' ? h('a', { class: 'btn small', href: '#/results/' + r.id }, 'Review') : h('a', { class: 'btn small primary', href: '#/interview/' + r.id }, 'Continue'),
        onDelete ? h('button', { class: 'btn small danger', onclick: () => onDelete(r) }, 'Delete') : null)))))));
}

// ---------------- history ----------------
export async function history(root, ctx) {
  mount(root, h('p', { class: 'muted' }, 'Loading…'));
  await guard(root, async () => {
    const draw = async () => {
      const rows = await api('/api/sessions');
      mount(root, h('h1', {}, 'Interview History'), h('p', { class: 'muted' }, 'Your sessions are saved to your account and available whenever you sign in.'),
        h('div', { class: 'card' }, sessionTable(rows, async (r) => {
          if (!confirm('Delete this session and all its answers and evaluations? This cannot be undone.')) return;
          try { await api('/api/sessions/' + r.id, { method: 'DELETE' }); toast('Session deleted.'); draw(); } catch (e) { toast(e.message); }
        })));
    };
    await draw();
  }, mount);
}

// ---------------- progress ----------------
export async function progress(root, ctx) {
  mount(root, h('p', { class: 'muted' }, 'Loading…'));
  await guard(root, async () => {
    const p = await api('/api/progress');
    if (!p.sessions_completed) { mount(root, h('h1', {}, 'Progress Analytics'), h('div', { class: 'card' }, h('p', {}, 'Complete a session to see trends here.'), h('a', { class: 'btn primary', href: '#/start' }, 'Start Interview'))); return; }
    const points = p.trend.map((t, i) => ({ label: '#' + (i + 1), value: t.score, demo: t.is_demo }));
    const rec = p.recommendation;
    mount(root, h('h1', {}, 'Progress Analytics'),
      h('div', { class: 'grid g4' },
        h('div', { class: 'card stat' }, h('div', { class: 'v' }, String(p.sessions_completed)), h('div', { class: 'l' }, 'Sessions')),
        h('div', { class: 'card stat' }, h('div', { class: 'v gold-text' }, fmtScore(p.average_score)), h('div', { class: 'l' }, 'Average score')),
        h('div', { class: 'card stat' }, h('div', { class: 'v' }, fmtScore(p.recent_average)), h('div', { class: 'l' }, 'Last 3 average')),
        h('div', { class: 'card stat' }, h('div', { class: 'v' }, p.change_first_to_last === null ? '—' : (p.change_first_to_last > 0 ? '+' : '') + p.change_first_to_last), h('div', { class: 'l' }, 'Change, first → latest'))),
      h('div', { class: 'card', style: 'margin-top:16px' }, h('h3', {}, 'Score trend'), lineChart(points), h('p', { class: 'muted small' }, 'Hollow points are DEMO sessions. ' + p.note)),
      h('div', { class: 'grid g2', style: 'margin-top:16px' },
        h('div', { class: 'card' }, h('h3', {}, 'Category averages'), barChart(Object.entries(CAT_LABELS).map(([k, l]) => ({ label: l, value: p.category_averages[k] })))),
        h('div', { class: 'card' }, h('h3', {}, 'Weak areas (lowest first)'),
          h('table', {}, h('tbody', {}, p.weak_areas.map(w => h('tr', {}, h('td', {}, w.topic), h('td', {}, bar(w.average)), h('td', { class: 'score' }, fmtScore(w.average)), h('td', { class: 'muted small' }, 'n=' + w.n)))))),
      ),
      h('div', { class: 'card', style: 'margin-top:16px' }, h('h3', {}, 'Recommended next practice'), h('p', {}, rec.reason),
        h('a', { class: 'btn primary', href: '#/start?mode=' + rec.mode }, 'Start ' + modeLabel(rec.mode))),
      h('div', { class: 'card', style: 'margin-top:16px' }, h('h3', {}, 'Category changes by session'),
        h('div', { style: 'overflow:auto' }, h('table', {}, h('thead', {}, h('tr', {}, h('th', {}, 'Session'), Object.values(CAT_LABELS).map(l => h('th', {}, l)))),
          h('tbody', {}, p.category_trend.map((c, i) => h('tr', {}, h('td', {}, '#' + (i + 1)), Object.keys(CAT_LABELS).map(k => h('td', {}, fmtScore(c[k]))))))))));
  }, mount);
}

// ---------------- plan ----------------
export async function plan(root, ctx, idParam) {
  mount(root, h('p', { class: 'muted' }, 'Loading…'));
  await guard(root, async () => {
    const sessions = (await api('/api/sessions')).filter(s => s.status === 'completed');
    if (!sessions.length) { mount(root, h('h1', {}, 'Improvement Plan'), h('div', { class: 'card' }, h('p', {}, 'Your seven-day plan is generated when you complete an interview.'), h('a', { class: 'btn primary', href: '#/start' }, 'Start Interview'))); return; }
    const sid = idParam ? Number(idParam) : sessions[0].id;
    const pl = await api('/api/plans/' + sid);
    const key = 'im_plan_' + sid;
    let done = {};
    try { done = JSON.parse(localStorage.getItem(key) || '{}'); } catch (e) { done = {}; }
    const counter = h('span', { class: 'tag gold' });
    const upd = () => { counter.textContent = Object.values(done).filter(Boolean).length + ' / ' + pl.days.length + ' days done'; };
    upd();
    mount(root, h('h1', {}, 'Seven-Day Improvement Plan'),
      h('div', { class: 'row spread' }, h('p', { class: 'muted' }, pl.label), h('div', { class: 'row' }, counter,
        h('select', { 'aria-label': 'Choose session', onchange: (e) => ctx.go('/plan/' + e.target.value) },
          sessions.map(s => h('option', { value: s.id, selected: s.id === sid }, '#' + s.id + ' · ' + modeLabel(s.mode) + ' · ' + fmtDate(s.created_at)))))),
      h('p', { class: 'small muted' }, 'About ' + pl.total_minutes + ' minutes in total. Checkmarks are saved in this browser only.'),
      h('div', { class: 'grid' }, pl.days.map(d => h('div', { class: 'card day' },
        h('label', { class: 'check', style: 'margin:0' }, h('input', { type: 'checkbox', checked: !!done[d.day], onchange: (e) => { done[d.day] = e.target.checked; try { localStorage.setItem(key, JSON.stringify(done)); } catch (x) { /* ignore */ } upd(); } }),
          h('span', {}, h('strong', {}, 'Day ' + d.day + ': ' + d.topic), h('span', { class: 'tag', style: 'margin-left:8px' }, '~' + d.minutes + ' min'))),
        h('ul', {}, d.tasks.map(t => h('li', {}, t))),
        h('p', { class: 'small' }, h('strong', {}, 'Done when: '), d.completion_criteria)))),
      h('p', {}, h('a', { class: 'btn', href: '#/results/' + sid }, 'Back to results')));
  }, mount);
}

// ---------------- rubric ----------------
export async function rubric(root, ctx) {
  mount(root, h('p', { class: 'muted' }, 'Loading…'));
  await guard(root, async () => {
    const r = await api('/api/rubric');
    mount(root, h('h1', {}, 'Evaluation Rubric & Fairness'),
      h('div', { class: 'card' }, h('h3', {}, 'Scoring formula'), h('p', { class: 'gold-text', style: 'font-size:18px;font-weight:650' }, r.formula),
        h('table', {}, h('thead', {}, h('tr', {}, h('th', {}, 'Category'), h('th', {}, 'Weight'), h('th', {}, 'How it is scored'))),
          h('tbody', {}, Object.entries(r.weights).map(([k, v]) => h('tr', {}, h('td', {}, v.label), h('td', {}, Math.round(v.weight * 100) + '%'), h('td', { class: 'small' }, r.definitions[k])))))),
      h('div', { class: 'card', style: 'margin-top:16px' }, h('h3', {}, 'When evidence is insufficient'), h('p', {}, r.insufficient_evidence)),
      h('div', { class: 'card', style: 'margin-top:16px' }, h('h3', {}, 'Limitations — please read'), h('ul', {}, r.limitations.map(l => h('li', {}, l))), h('p', { class: 'muted' }, r.flagging)));
  }, mount);
}

// ---------------- settings & privacy ----------------
export async function settings(root, ctx) {
  mount(root, h('p', { class: 'muted' }, 'Loading…'));
  let camStream = null;
  await guard(root, async () => {
    const [me, priv, docs] = await Promise.all([api('/api/me'), api('/api/privacy'), api('/api/documents')]);
    ctx.user = me;
    const save = async (patch) => { try { ctx.user = await api('/api/me', { method: 'PUT', body: patch }); toast('Saved.'); } catch (e) { toast(e.message); } };
    const nameIn = h('input', { type: 'text', id: 'dn', value: me.display_name || '' });
    const video = h('video', { class: 'cam', autoplay: true, playsinline: true, muted: true, hidden: true, 'aria-label': 'Camera framing preview' });
    const camMsg = h('p', { class: 'muted small' });
    const camBtn = h('button', { class: 'btn', onclick: async () => {
      if (camStream) { camStream.getTracks().forEach(t => t.stop()); camStream = null; video.hidden = true; video.srcObject = null; camBtn.textContent = 'Turn on camera preview'; camMsg.textContent = 'Camera is off.'; return; }
      try { camStream = await navigator.mediaDevices.getUserMedia({ video: true }); video.srcObject = camStream; video.hidden = false; camBtn.textContent = 'Turn off camera'; camMsg.textContent = 'Preview only. Nothing is recorded, uploaded, analysed, or scored.'; }
      catch (e) { camMsg.textContent = 'Camera unavailable or permission denied.'; }
    } }, 'Turn on camera preview');
    mount(root, h('h1', {}, 'Settings & Privacy'),
      h('div', { class: 'card' }, h('h3', {}, 'Profile'), h('label', { for: 'dn' }, 'Display name'), nameIn,
        h('p', { class: 'muted small' }, 'Signed in as ' + me.email), h('button', { class: 'btn', onclick: () => save({ display_name: nameIn.value }) }, 'Save name')),
      h('div', { class: 'card', style: 'margin-top:16px' }, h('h3', {}, 'Consent'),
        h('label', { class: 'check' }, h('input', { type: 'checkbox', checked: me.consent_documents, onchange: (e) => save({ consent_documents: e.target.checked }) }),
          h('span', {}, 'Process my uploaded resume and job description in this app (text extraction and skill matching run on this server).')),
        h('label', { class: 'check' }, h('input', { type: 'checkbox', checked: me.consent_audio, onchange: (e) => save({ consent_audio: e.target.checked }) }),
          h('span', {}, 'Allow microphone recording for voice answers. Audio is converted to text and not stored.')),
        h('label', { class: 'check' }, h('input', { type: 'checkbox', checked: me.consent_ai_processing, disabled: !priv.external_providers.some(p => p.purpose.startsWith('Question')), onchange: (e) => save({ consent_ai_processing: e.target.checked }) }),
          h('span', {}, 'Allow sending my answers to the configured external AI provider for evaluation.',
            priv.external_providers.some(p => p.purpose.startsWith('Question')) ? '' : ' (No external AI provider is configured on this server, so nothing is sent.)'))),
      h('div', { class: 'card', style: 'margin-top:16px' }, h('h3', {}, 'Where your data goes'), h('p', {}, priv.default),
        priv.external_providers.length ? h('ul', {}, priv.external_providers.map(p => h('li', {}, p.purpose + ' — ' + p.provider + ' (' + p.data + ')'))) : h('p', { class: 'tag ok' }, 'No external providers configured'),
        h('p', { class: 'small muted' }, 'Stored: ' + priv.stores.join('; ') + '. Not stored: ' + priv.does_not_store.join(', ') + '. ' + priv.browser_tts_note)),
      h('div', { class: 'card', style: 'margin-top:16px' }, h('h3', {}, 'Camera framing guide (optional, off by default)'),
        h('p', { class: 'small muted' }, 'Shows your own camera so you can check lighting and framing. No posture, expression, gaze or personality analysis is performed, nothing is saved, and camera data never affects scores.'),
        camBtn, camMsg, video),
      h('div', { class: 'card', style: 'margin-top:16px' }, h('h3', {}, 'Your documents'),
        docs.length ? h('table', {}, h('tbody', {}, docs.map(d => h('tr', {}, h('td', {}, d.kind === 'resume' ? 'Resume' : 'Job description'), h('td', {}, d.filename), h('td', { class: 'small muted' }, fmtDate(d.created_at)),
          h('td', {}, h('button', { class: 'btn small danger', onclick: async () => { if (!confirm('Delete this document and the profile extracted from it?')) return; try { await api('/api/documents/' + d.id, { method: 'DELETE' }); toast('Deleted.'); settings(root, ctx); } catch (e) { toast(e.message); } } }, 'Delete')))))) : h('p', { class: 'muted' }, 'No documents uploaded.')),
      h('div', { class: 'card', style: 'margin-top:16px' }, h('h3', {}, 'Your data'),
        h('div', { class: 'row' },
          h('button', { class: 'btn', onclick: () => download('/api/export', 'interviewmate-export.json').catch(e => toast(e.message)) }, 'Export my data (JSON)'),
          h('button', { class: 'btn danger', onclick: async () => {
            if (prompt('This permanently deletes your account, documents, sessions, and evaluations. Type DELETE to confirm.') !== 'DELETE') return;
            try { await api('/api/me', { method: 'DELETE' }); auth.set(null); ctx.user = null; ctx.go('/'); } catch (e) { toast(e.message); }
          } }, 'Delete my account and all data'))));
  }, mount);
  return () => { if (camStream) camStream.getTracks().forEach(t => t.stop()); };
}
