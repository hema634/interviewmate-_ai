import { h, mount, clear, fmtTime, fmtScore, modeLabel, toast, lines, csv } from './util.js';
import { api, ApiError } from './api.js';
import { banner, guard, evaluationView, coachPanel, CAT_LABELS } from './components.js';

const MODES = [
  ['hr', 'HR & Behavioral', 'Self-introduction, strengths, teamwork, leadership, conflict, adaptability, goals'],
  ['software', 'Software Technical', 'Programming, DSA, OOP, databases, APIs, system design'],
  ['electrical', 'Electrical & Control', 'Machines, power systems, power electronics, PLC/SCADA, control, sensors, embedded, IoT, MATLAB, safety'],
  ['project', 'Project Viva & Defense', 'Problem, motivation, architecture, components, calculations, testing, limitations, cost, future'],
  ['mixed', 'Mixed HR + Technical', 'Alternates behavioral, technical, and project questions'],
];

// ======================= Start page (wizard + coding) =======================
export async function startPage(root, ctx) {
  const q = ctx.query();
  let tab = q.tab === 'coding' ? 'coding' : 'mock';
  const body = h('div', {});
  const tabs = h('div', { class: 'tabs', role: 'tablist' });
  let cleanup = null;
  const draw = async () => {
    tabs.replaceChildren(
      h('button', { role: 'tab', 'aria-selected': String(tab === 'mock'), onclick: () => { tab = 'mock'; draw(); } }, 'Mock interview'),
      h('button', { role: 'tab', 'aria-selected': String(tab === 'coding'), onclick: () => { tab = 'coding'; draw(); } }, 'Coding practice'));
    if (cleanup) { cleanup(); cleanup = null; }
    clear(body);
    if (tab === 'mock') await wizard(body, ctx, q); else codingPanel(body, ctx);
  };
  mount(root, h('h1', {}, 'Start Interview'), tabs, body);
  await draw();
}

async function wizard(root, ctx, q) {
  const st = { step: 1, profile: null, job: null, profiles: [], jobs: [], cmp: null };
  const stepsBar = h('div', { class: 'steps', 'aria-label': 'Progress' });
  const view = h('div', {});
  mount(root, stepsBar, view);
  const names = ['1 · Documents', '2 · Review & correct', '3 · Configure'];
  const redraw = () => {
    stepsBar.replaceChildren(...names.map((n, i) => h('span', { class: 'step ' + (st.step === i + 1 ? 'on' : st.step > i + 1 ? 'done' : '') }, n)));
    [step1, step2, step3][st.step - 1]();
  };
  const reload = async () => {
    const [ps, js] = await Promise.all([api('/api/profiles'), api('/api/jobs')]);
    st.profiles = ps; st.jobs = js;
  };
  try { await reload(); } catch (e) { mount(root, banner(e.message, 'err')); return; }

  // ---- step 1
  function step1() {
    const consent = h('input', { type: 'checkbox', id: 'consent', checked: ctx.user.consent_documents });
    const msg = h('div', { 'aria-live': 'polite' });
    const ensureConsent = async () => {
      if (!consent.checked) { msg.replaceChildren(banner('Please tick the consent box first — it lets this app read and process the document you upload.', 'err')); return false; }
      if (!ctx.user.consent_documents) ctx.user = await api('/api/me', { method: 'PUT', body: { consent_documents: true } });
      return true;
    };
    const cont = h('button', { class: 'btn primary', onclick: () => { st.step = (st.profile || st.job) ? 2 : 3; redraw(); } });
    const updateCont = () => { cont.textContent = (st.profile || st.job) ? 'Continue to review' : 'Skip documents'; };
    updateCont();
    const uploader = (kind, label) => {
      const file = h('input', { type: 'file', accept: '.pdf,.docx,.txt', id: 'f_' + kind });
      const paste = h('textarea', { placeholder: 'Or paste the text here…', 'aria-label': label + ' text' });
      const saved = kind === 'resume' ? st.profiles : st.jobs;
      const useSaved = h('select', { 'aria-label': 'Use saved ' + label }, h('option', { value: '' }, saved.length ? 'Use a saved one…' : 'No saved ones yet'),
        saved.map(p => h('option', { value: p.id }, '#' + p.id + ' · ' + (kind === 'resume' ? (p.profile.name || 'resume') : (p.job.title || 'job description')))));
      useSaved.addEventListener('change', () => {
        if (!useSaved.value) return;
        const item = saved.find(p => String(p.id) === useSaved.value);
        if (kind === 'resume') st.profile = { id: item.id, profile: item.profile }; else st.job = { id: item.id, job: item.job };
        toast(label + ' selected.');
      });
      const go = h('button', { class: 'btn', onclick: async (e) => {
        msg.replaceChildren();
        if (!(await ensureConsent())) return;
        e.target.disabled = true;
        try {
          let r;
          if (file.files[0]) { const fd = new FormData(); fd.append('kind', kind); fd.append('file', file.files[0]); r = await api('/api/documents', { method: 'POST', form: fd }); }
          else if (paste.value.trim().length >= 20) r = await api('/api/documents/text', { method: 'POST', body: { kind, text: paste.value, filename: 'pasted.txt' } });
          else { msg.replaceChildren(banner('Choose a PDF, DOCX or TXT file, or paste some text.', 'err')); e.target.disabled = false; return; }
          if (kind === 'resume') st.profile = { id: r.profile_id, profile: r.extracted }; else st.job = { id: r.job_id, job: r.extracted };
          await reload(); updateCont();
          toast(label + ' processed. Review it in the next step.');
          msg.replaceChildren(banner(label + ' uploaded and processed.', 'ok'));
        } catch (ex) { msg.replaceChildren(banner(ex.message, 'err')); }
        e.target.disabled = false;
      } }, 'Upload ' + label.toLowerCase());
      return h('div', { class: 'card' }, h('h3', {}, label), file, h('p', { class: 'muted small' }, 'PDF, DOCX or TXT, up to 5 MB.'), paste, h('div', { class: 'row', style: 'margin-top:10px' }, go, useSaved),
        (kind === 'resume' ? st.profile : st.job) ? h('p', { class: 'tag ok' }, 'selected ✓') : null);
    };
    mount(view,
      h('div', { class: 'banner' }, h('label', { class: 'check', for: 'consent', style: 'margin:0' }, consent,
        h('span', {}, 'I consent to InterviewMate processing the documents I upload on this server. They are treated as untrusted text, are only sent to an external AI provider if one is configured and I opt in (see Settings & Privacy), and I can delete them any time.'))),
      msg,
      h('div', { class: 'grid g2' }, uploader('resume', 'Resume'), uploader('job_description', 'Job description')),
      h('div', { class: 'row', style: 'margin-top:16px' },
        cont,
        h('span', { class: 'muted small' }, 'Without documents, questions come from the general bank for your chosen mode.')));
  }

  // ---- step 2
  function step2() {
    const nodes = [];
    const fields = {};
    const area = (label, value, id, hint) => { const t = h('textarea', { id, style: 'min-height:84px' }, value); fields[id] = t; return h('div', {}, h('label', { for: id }, label), t, hint ? h('p', { class: 'muted small' }, hint) : null); };
    if (st.profile) {
      const p = st.profile.profile;
      if (p.flagged_instruction_lines && p.flagged_instruction_lines.length) nodes.push(banner(p.flagged_instruction_lines.length + ' line(s) in your resume looked like instructions to an AI and were ignored. Documents are treated as data only.', 'err'));
      const unk = (p.unknown_fields || []);
      const projBoxes = (p.projects || []).map((pr, i) => ({ name: h('input', { type: 'text', value: pr.name, 'aria-label': 'Project name ' + (i + 1) }), det: h('textarea', { style: 'min-height:70px', 'aria-label': 'Project details ' + (i + 1) }, (pr.details || []).join('\n')), skills: pr.skills }));
      fields.projects = projBoxes;
      nodes.push(h('div', { class: 'card' }, h('h3', {}, 'Your profile (extracted — please correct anything wrong)'),
        unk.length ? h('p', {}, 'Not found in resume (kept as unknown, never assumed): ', unk.map(u => h('span', { class: 'tag warn' }, u.replace('_', ' ')))) : null,
        h('label', { for: 'pn' }, 'Name'), (fields.name = h('input', { type: 'text', id: 'pn', value: p.name || '' })),
        area('Technical skills (comma separated)', (p.technical_skills || []).join(', '), 'tech'),
        area('Soft skills (comma separated)', (p.soft_skills || []).join(', '), 'soft'),
        area('Education (one per line)', (p.education || []).join('\n'), 'edu'),
        area('Internships & experience (one per line)', (p.experience || []).join('\n'), 'exp'),
        area('Certifications (one per line)', (p.certifications || []).join('\n'), 'cert'),
        area('Achievements (one per line)', (p.achievements || []).join('\n'), 'ach'),
        h('h3', { style: 'margin-top:14px' }, 'Projects'),
        ...projBoxes.map(b => h('div', { class: 'card flat', style: 'margin-bottom:8px' }, b.name, b.det))));
    }
    if (st.job) {
      const j = st.job.job;
      nodes.push(h('div', { class: 'card', style: 'margin-top:16px' }, h('h3', {}, 'Job requirements (extracted — please correct)'),
        (j.unknown_fields || []).length ? h('p', {}, 'Not found: ', j.unknown_fields.map(u => h('span', { class: 'tag warn' }, u.replace('_', ' ')))) : null,
        h('label', { for: 'jt' }, 'Job title'), (fields.jtitle = h('input', { type: 'text', id: 'jt', value: j.title || '' })),
        area('Responsibilities (one per line)', (j.responsibilities || []).join('\n'), 'resp'),
        area('Required skills (comma separated)', (j.required_skills || []).join(', '), 'req'),
        area('Preferred skills (comma separated)', (j.preferred_skills || []).join(', '), 'pref')));
    }
    const cmpBox = h('div', {});
    const loadCmp = async () => {
      if (!(st.profile && st.job)) return;
      try {
        const c = await api('/api/compare?profile_id=' + st.profile.id + '&job_id=' + st.job.id);
        const tags = (arr, cls) => arr.length ? arr.map(x => h('span', { class: 'tag ' + cls }, x)) : h('span', { class: 'muted small' }, 'none');
        cmpBox.replaceChildren(h('div', { class: 'card', style: 'margin-top:16px' }, h('h3', {}, 'Resume vs. job description'),
          h('p', {}, h('strong', {}, 'Matching skills: '), tags(c.matching_skills, 'ok')),
          h('p', {}, h('strong', {}, 'Missing or unverified (required): '), tags(c.missing_or_unverified_required, 'warn')),
          h('p', {}, h('strong', {}, 'Missing or unverified (preferred): '), tags(c.missing_or_unverified_preferred, 'warn')),
          h('p', {}, h('strong', {}, 'Relevant projects: '), c.relevant_projects.length ? c.relevant_projects.map(p => h('span', { class: 'tag gold' }, p.name + ' (' + p.matched_skills.join(', ') + ')')) : h('span', { class: 'muted small' }, 'none matched')),
          h('p', {}, h('strong', {}, 'Likely technical interview topics: '), tags(c.suggested_topics, 'gold')),
          h('p', { class: 'muted small' }, c.note)));
      } catch (e) { cmpBox.replaceChildren(banner(e.message, 'err')); }
    };
    const msg = h('div', { 'aria-live': 'polite' });
    const saveAll = async () => {
      try {
        if (st.profile) {
          const payload = { name: fields.name.value, technical_skills: csv(fields.tech.value), soft_skills: csv(fields.soft.value), education: lines(fields.edu.value), experience: lines(fields.exp.value),
            certifications: lines(fields.cert.value), achievements: lines(fields.ach.value),
            projects: fields.projects.map(b => ({ name: b.name.value, details: lines(b.det.value), skills: b.skills })).filter(p => p.name.trim()) };
          const r = await api('/api/profiles/' + st.profile.id, { method: 'PUT', body: { profile: payload } });
          st.profile.profile = r.profile;
        }
        if (st.job) {
          const r = await api('/api/jobs/' + st.job.id, { method: 'PUT', body: { job: { title: fields.jtitle.value, responsibilities: lines(fields.resp.value), required_skills: csv(fields.req.value), preferred_skills: csv(fields.pref.value) } } });
          st.job.job = r.job;
        }
        msg.replaceChildren(banner('Corrections saved.', 'ok'));
        await loadCmp();
        return true;
      } catch (e) { msg.replaceChildren(banner(e.message, 'err')); return false; }
    };
    mount(view, ...nodes, cmpBox, msg, h('div', { class: 'row', style: 'margin-top:16px' },
      h('button', { class: 'btn', onclick: () => { st.step = 1; redraw(); } }, 'Back'),
      h('button', { class: 'btn', onclick: saveAll }, 'Save corrections'),
      h('button', { class: 'btn primary', onclick: async () => { if (await saveAll()) { st.step = 3; redraw(); } } }, 'Save and continue')));
    loadCmp();
  }

  // ---- step 3
  function step3() {
    let mode = ['hr', 'software', 'electrical', 'project', 'mixed'].includes(q.mode) ? q.mode : 'mixed';
    const modeBox = h('div', { class: 'grid g3', role: 'radiogroup', 'aria-label': 'Interview mode' });
    const drawModes = () => modeBox.replaceChildren(...MODES.map(([k, t, d]) => h('button', {
      class: 'card', style: 'text-align:left;cursor:pointer;' + (mode === k ? 'border-color:var(--gold)' : ''), role: 'radio', 'aria-checked': String(mode === k), onclick: () => { mode = k; drawModes(); },
    }, h('strong', { class: mode === k ? 'gold-text' : '' }, t), h('div', { class: 'muted small' }, d))));
    drawModes();
    const sel = (id, label, opts, val) => h('div', {}, h('label', { for: id }, label), h('select', { id }, opts.map(([v, l]) => h('option', { value: v, selected: v === val }, l))));
    const role = h('input', { type: 'text', id: 'role', value: (st.job && st.job.job.title) || '', placeholder: 'e.g., Graduate Engineer Trainee' });
    const projNames = st.profile ? (st.profile.profile.projects || []).map(p => p.name) : [];
    const proj = h('input', { type: 'text', id: 'proj', list: 'projlist', placeholder: projNames.length ? 'Auto-pick best match, or choose' : 'Optional: name your project' });
    const els = {};
    const err = h('div', { 'aria-live': 'assertive' });
    const form = h('div', { class: 'card', style: 'margin-top:16px' }, h('div', { class: 'grid g3' },
      h('div', {}, h('label', { for: 'role' }, 'Target role'), role),
      (els.exp = sel('exp', 'Experience level', [['fresher', 'Fresher / student'], ['junior', 'Junior (0-2 yrs)'], ['mid', 'Mid (2-5 yrs)'], ['senior', 'Senior (5+ yrs)']], 'fresher')),
      (els.diff = sel('diff', 'Difficulty', [['adaptive', 'Adaptive'], ['easy', 'Easy'], ['medium', 'Medium'], ['hard', 'Hard']], 'adaptive')),
      h('div', {}, h('label', { for: 'nq' }, 'Number of questions (1-20)'), (els.nq = h('input', { type: 'number', id: 'nq', min: 1, max: 20, value: 5 }))),
      h('div', {}, h('label', { for: 'dur' }, 'Duration in minutes (5-90)'), (els.dur = h('input', { type: 'number', id: 'dur', min: 5, max: 90, value: 30 }))),
      (els.lang = sel('lang', 'Interview language', [['en', 'English'], ['hi', 'Hindi (needs LLM provider)'], ['ta', 'Tamil (needs LLM provider)']], 'en')),
      (els.inp = sel('inp', 'Answer mode', [['typed', 'Typed'], ['voice', 'Voice (typed fallback always available)']], 'typed')),
      h('div', {}, h('label', { for: 'proj' }, 'Project for viva'), proj, h('datalist', { id: 'projlist' }, projNames.map(n => h('option', { value: n }))))),
      h('p', { class: 'muted small' }, 'The built-in question bank and offline evaluator are English-only. Other languages are stored for use with a configured LLM provider.'));
    const startBtn = h('button', { class: 'btn primary', onclick: async (e) => {
      err.replaceChildren(); e.target.disabled = true;
      try {
        const s = await api('/api/sessions', { method: 'POST', body: {
          mode, target_role: role.value, experience_level: els.exp.querySelector('select').value, difficulty: els.diff.querySelector('select').value,
          num_questions: Number(els.nq.value), duration_minutes: Number(els.dur.value), language: els.lang.querySelector('select').value,
          input_mode: els.inp.querySelector('select').value, project_name: proj.value, profile_id: st.profile ? st.profile.id : null, job_id: st.job ? st.job.id : null } });
        ctx.go('/interview/' + s.id);
      } catch (ex) { err.replaceChildren(banner(ex.message, 'err')); e.target.disabled = false; }
    } }, 'Begin interview');
    mount(view, h('h3', {}, 'Choose an interview mode'), modeBox, form, err,
      h('div', { class: 'row', style: 'margin-top:16px' }, h('button', { class: 'btn', onclick: () => { st.step = (st.profile || st.job) ? 2 : 1; redraw(); } }, 'Back'), startBtn));
  }
  redraw();
}

// ======================= Coding practice =======================
const KEYWORDS = {
  python: 'def class return if elif else for while in not and or is None True False import from as with try except finally raise lambda pass break continue yield',
  javascript: 'function const let var return if else for while of in new class this null undefined true false break continue try catch throw async await',
  java: 'public private static void class return if else for while new int long double boolean String null true false break continue try catch throw final',
  cpp: 'int long double bool void class struct return if else for while new auto const nullptr true false break continue try catch throw include using namespace std vector unordered_map',
};
export function highlight(code, lang) {
  const kw = new Set((KEYWORDS[lang] || '').split(' '));
  const re = /(#[^\n]*|\/\/[^\n]*|\/\*[\s\S]*?\*\/)|("(?:\\.|[^"\\\n])*"|'(?:\\.|[^'\\\n])*')|(\b\d+(?:\.\d+)?\b)|([A-Za-z_]\w*)/g;
  const out = []; let last = 0, m;
  while ((m = re.exec(code))) {
    if (m.index > last) out.push(code.slice(last, m.index));
    const color = m[1] ? '#7f8aa3' : m[2] ? '#9ad7a0' : m[3] ? '#f0b24a' : kw.has(m[4]) ? '#f3d77a' : null;
    out.push(color ? h('span', { style: 'color:' + color }, m[0]) : m[0]);
    last = re.lastIndex;
  }
  if (last < code.length) out.push(code.slice(last));
  out.push('\n');
  return out;
}

const STARTER = {
  python: 'def solve(nums, target):\n    # write your solution\n    pass\n',
  javascript: 'function solve(nums, target) {\n  // write your solution\n}\n',
  java: 'class Solution {\n    public int[] solve(int[] nums, int target) {\n        // write your solution\n        return null;\n    }\n}\n',
  cpp: '#include <vector>\nstd::vector<int> solve(std::vector<int>& nums, int target) {\n    // write your solution\n    return {};\n}\n',
};

async function codingPanel(root, ctx) {
  let info;
  try { info = await api('/api/coding/problems'); } catch (e) { mount(root, banner(e.message, 'err')); return; }
  let lang = 'python';
  const pre = h('pre', { class: 'code', 'aria-hidden': 'true', style: 'position:absolute;inset:0;margin:0;padding:12px;pointer-events:none;overflow:hidden' });
  const ta = h('textarea', { class: 'code', spellcheck: 'false', 'aria-label': 'Code editor', style: 'position:relative;background:transparent;color:transparent;caret-color:#f3d77a;min-height:260px;white-space:pre;overflow:auto;padding:12px' });
  const paint = () => { pre.replaceChildren(...highlight(ta.value, lang)); pre.scrollTop = ta.scrollTop; pre.scrollLeft = ta.scrollLeft; };
  ta.value = STARTER[lang];
  ta.addEventListener('input', paint); ta.addEventListener('scroll', paint);
  ta.addEventListener('keydown', (e) => {
    if (e.key === 'Tab') { e.preventDefault(); const s = ta.selectionStart; ta.value = ta.value.slice(0, s) + '    ' + ta.value.slice(ta.selectionEnd); ta.selectionStart = ta.selectionEnd = s + 4; paint(); }
  });
  const probSel = h('select', { id: 'prob' }, info.problems.map(p => h('option', { value: p.id }, p.title)));
  const probText = h('p', {});
  const showProb = () => { const p = info.problems.find(x => x.id === probSel.value); probText.textContent = p.statement + ' Edge cases to consider: ' + p.edge_cases.join(', ') + '.'; };
  probSel.addEventListener('change', showProb); showProb();
  const langSel = h('select', { id: 'lang', onchange: (e) => { lang = e.target.value; ta.value = STARTER[lang]; paint(); } }, info.languages.map(l => h('option', { value: l }, l)));
  const expl = h('textarea', { id: 'expl', placeholder: 'Explain your approach as you would to an interviewer: idea, complexity, edge cases, how you would test it.' });
  const out = h('div', { 'aria-live': 'polite', style: 'margin-top:16px' });
  mount(root,
    banner('Code review only: code is NEVER executed here (no isolated sandbox is configured). The review checks syntax and structure and reads your explanation, and says so in its results.'),
    h('div', { class: 'card' }, h('div', { class: 'grid g3' }, h('div', {}, h('label', { for: 'prob' }, 'Problem'), probSel), h('div', {}, h('label', { for: 'lang' }, 'Language'), langSel)),
      probText, h('div', { style: 'position:relative;border:1px solid var(--line);border-radius:10px;overflow:hidden;background:var(--bg)' }, pre, ta),
      h('label', { for: 'expl' }, 'Explain your approach (typed — or dictate with your device keyboard microphone)'), expl,
      h('div', { class: 'row', style: 'margin-top:12px' }, h('button', { class: 'btn primary', onclick: async (e) => {
        e.target.disabled = true; out.replaceChildren(h('p', { class: 'muted' }, 'Reviewing…'));
        try {
          const r = await api('/api/coding/review', { method: 'POST', body: { language: lang, problem_id: probSel.value, code: ta.value, explanation: expl.value } });
          const names = { algorithmic_reasoning: 'Algorithmic reasoning', correctness: 'Correctness (structure only)', edge_cases: 'Edge cases', testing: 'Testing', complexity: 'Time & space complexity' };
          out.replaceChildren(h('div', { class: 'card' }, h('h3', {}, 'Static review'), h('span', { class: 'tag warn' }, 'execution: not run'), h('span', { class: 'tag' }, r.label),
            r.notes.length ? h('ul', {}, r.notes.map(n => h('li', {}, n))) : null,
            h('table', {}, h('tbody', {}, Object.entries(r.scores).map(([k, v]) => h('tr', {}, h('td', {}, names[k]), h('td', { class: 'score' }, v === null ? 'n/a' : v + ' / 100'))))),
            r.complexity_note ? h('p', {}, r.complexity_note) : null,
            h('strong', {}, 'Suggestions'), h('ul', {}, r.suggestions.map(s => h('li', {}, s))),
            h('details', {}, h('summary', { class: 'small muted' }, 'Limitations'), h('ul', { class: 'small muted' }, r.limitations.map(l => h('li', {}, l))))));
        } catch (ex) { out.replaceChildren(banner(ex.message, 'err')); }
        e.target.disabled = false;
      } }, 'Review my code (no execution)'))), out);
  paint();
}

// ======================= Live interview =======================
export async function liveInterview(root, ctx, idParam) {
  const sid = Number(idParam);
  let sess, health = {}, fetchedAt = Date.now(), timerId = null, recorder = null, stream = null, recTimer = null, recStart = 0, audioEl = null, muted = false, lastSpokenQ = null;
  const cleanup = () => {
    clearInterval(timerId); clearInterval(recTimer);
    if (stream) stream.getTracks().forEach(t => t.stop());
    if (recorder && recorder.state !== 'inactive') { try { recorder.ondataavailable = null; recorder.onstop = null; recorder.stop(); } catch (e) { /* already stopped */ } }
    if (audioEl) { audioEl.pause(); audioEl = null; }
    if ('speechSynthesis' in window) window.speechSynthesis.cancel();
  };
  mount(root, h('p', { class: 'muted' }, 'Loading interview…'));
  try { [sess, health] = await Promise.all([api('/api/sessions/' + sid), api('/api/health')]); }
  catch (e) { mount(root, banner(e.message, 'err'), h('a', { class: 'btn', href: '#/history' }, 'Back to history')); return cleanup; }
  if (sess.status === 'completed') { ctx.go('/results/' + sid); return cleanup; }
  fetchedAt = Date.now();
  let feedback = null;      // last answer response while reviewing
  let answerText = '';
  let busy = false;

  const remaining = () => sess.status === 'active' ? Math.max(0, sess.remaining_seconds - (Date.now() - fetchedAt) / 1000) : sess.remaining_seconds;
  const timerEl = h('span', { class: 'timer', role: 'timer', 'aria-label': 'Time remaining' });
  const tick = () => { timerEl.textContent = fmtTime(remaining()); };
  timerId = setInterval(tick, 1000);

  const setSession = (s) => { sess = s; fetchedAt = Date.now(); };
  const control = async (action) => {
    if (busy) return; busy = true;
    try { setSession(await api('/api/sessions/' + sid + '/control', { method: 'POST', body: { action } })); if (action === 'repeat') toast('Question repeated.'); }
    catch (e) { toast(e.message); }
    busy = false;
    if (sess.status === 'completed') { ctx.go('/results/' + sid); return; }
    if (action === 'repeat' || action === 'skip') { feedback = null; answerText = ''; lastSpokenQ = null; }
    draw();
  };

  // ---------- speaking (server TTS if configured, else browser voice) ----------
  async function speak(text) {
    stopSpeaking();
    if (muted) return;
    try {
      if (health.tts_configured) {
        const res = await api('/api/speech/synthesize', { method: 'POST', body: { text }, raw: true });
        const blob = await res.blob(); audioEl = new Audio(URL.createObjectURL(blob)); await audioEl.play(); return;
      }
    } catch (e) { /* fall through to browser voice */ }
    if ('speechSynthesis' in window) { const u = new SpeechSynthesisUtterance(text); u.lang = sess.language || 'en'; window.speechSynthesis.speak(u); }
    else toast('Read-aloud is not available on this device. The question is shown as text.');
  }
  function stopSpeaking() { if (audioEl) { audioEl.pause(); audioEl = null; } if ('speechSynthesis' in window) window.speechSynthesis.cancel(); }
  function pauseSpeaking() { if (audioEl) audioEl.paused ? audioEl.play() : audioEl.pause(); else if ('speechSynthesis' in window) (window.speechSynthesis.paused ? window.speechSynthesis.resume() : window.speechSynthesis.pause()); }

  // ---------- recording ----------
  const mic = { status: 'idle', seconds: 0, note: '' };
  const micEl = h('div', { 'aria-live': 'polite' });
  const drawMic = () => {
    const labels = { idle: 'Microphone off', requesting: 'Requesting microphone permission…', recording: 'Recording', processing: 'Transcribing…', ready: 'Transcript ready — review and edit below' };
    micEl.replaceChildren(h('div', { class: 'row' },
      mic.status === 'recording' ? h('span', { class: 'rec', 'aria-hidden': 'true' }) : null,
      h('strong', {}, labels[mic.status]), mic.status === 'recording' ? h('span', { class: 'timer small' }, fmtTime(mic.seconds)) : null,
      mic.note ? h('span', { class: 'small muted' }, mic.note) : null));
  };
  async function startRecording() {
    if (!navigator.mediaDevices || typeof MediaRecorder === 'undefined') { mic.note = 'Recording is not supported in this browser — please type your answer.'; drawMic(); return; }
    if (!ctx.user.consent_audio) {
      if (!confirm('Allow InterviewMate to use your microphone to record voice answers? Audio is turned into text and is not stored. You can withdraw this in Settings & Privacy.')) return;
      try { ctx.user = await api('/api/me', { method: 'PUT', body: { consent_audio: true } }); } catch (e) { toast(e.message); return; }
    }
    mic.status = 'requesting'; mic.note = ''; drawMic();
    try { stream = await navigator.mediaDevices.getUserMedia({ audio: true }); }
    catch (e) { mic.status = 'idle'; mic.note = 'Microphone permission was denied or unavailable — you can type your answer instead.'; drawMic(); return; }
    stopSpeaking();
    const chunks = [];
    recorder = new MediaRecorder(stream);
    recorder.ondataavailable = (ev) => { if (ev.data && ev.data.size) chunks.push(ev.data); };
    recorder.onstop = async () => {
      clearInterval(recTimer); if (stream) { stream.getTracks().forEach(t => t.stop()); stream = null; }
      if (mic.status !== 'processing') return;     // cancelled
      const blob = new Blob(chunks, { type: recorder.mimeType || 'audio/webm' });
      const fd = new FormData(); fd.append('audio', blob, 'answer.webm'); fd.append('content_type', blob.type);
      try {
        const r = await api('/api/speech/transcribe', { method: 'POST', form: fd });
        answerText = (answerText ? answerText + ' ' : '') + r.text; mic.status = 'ready'; mic.note = r.note; drawMic(); const ta = root.querySelector('#answer'); if (ta) ta.value = answerText;
      } catch (e) { mic.status = 'idle'; mic.note = e.code === 'stt_unavailable' ? 'Speech recognition is not set up on this server — please type your answer.' : e.message; drawMic(); }
    };
    recorder.start(); recStart = Date.now(); mic.status = 'recording'; mic.seconds = 0; drawMic();
    recTimer = setInterval(() => { mic.seconds = (Date.now() - recStart) / 1000; drawMic(); if (mic.seconds >= 180) stopRecording(); }, 500);
  }
  function stopRecording() { if (recorder && recorder.state === 'recording') { mic.status = 'processing'; drawMic(); recorder.stop(); } }
  function cancelRecording() { mic.status = 'idle'; mic.note = 'Recording cancelled.'; clearInterval(recTimer); if (recorder && recorder.state !== 'inactive') recorder.stop(); if (stream) { stream.getTracks().forEach(t => t.stop()); stream = null; } drawMic(); }

  // ---------- submit ----------
  async function submit() {
    const ta = root.querySelector('#answer'); const text = ta ? ta.value.trim() : '';
    if (!text) { toast('Write or record an answer first — or use Skip.'); return; }
    if (busy) return; busy = true; stopSpeaking();
    const btn = root.querySelector('#submit'); if (btn) btn.disabled = true;
    try {
      const wasVoice = mic.status === 'ready';
      const r = await api('/api/sessions/' + sid + '/answer', { method: 'POST', body: { question_id: sess.current_question.id, text, source: wasVoice ? 'voice' : 'typed', allow_external: !!ctx.user.consent_ai_processing } });
      feedback = { r, answered: sess.current_question }; setSession(r.session); answerText = ''; mic.status = 'idle'; mic.note = '';
    } catch (e) { toast(e.message); }
    busy = false; draw();
  }

  // ---------- render ----------
  const stage = h('div', { style: 'position:relative' });
  function draw() {
    tick();
    const total = sess.num_questions, done = Math.min(sess.progress.main_asked - (feedback ? 0 : 1), total);
    const header = h('div', { class: 'card' },
      h('div', { class: 'row spread' },
        h('div', {}, h('strong', {}, modeLabel(sess.mode)), h('span', { class: 'muted' }, ' · ' + sess.target_role + ' · level: ' + sess.progress.current_level), sess.is_demo ? h('span', { class: 'tag warn', style: 'margin-left:8px' }, 'DEMO') : null),
        h('div', { class: 'row' }, h('span', { class: 'muted small' }, 'Time left'), timerEl)),
      h('div', { class: 'progress', style: 'margin-top:10px', role: 'progressbar', 'aria-valuemin': 0, 'aria-valuemax': total, 'aria-valuenow': Math.max(0, done) }, h('i', { style: 'width:' + Math.max(0, Math.min(100, (done / total) * 100)) + '%' })),
      h('p', { class: 'muted small', style: 'margin:6px 0 0' }, 'Question ' + Math.min(sess.progress.main_asked, total) + ' of ' + total + (sess.progress.skipped ? ' · skipped ' + sess.progress.skipped : '')),
      sess.language_note ? h('p', { class: 'small tag warn' }, sess.language_note) : null);
    const controls = h('div', { class: 'row' },
      sess.status === 'paused' ? h('button', { class: 'btn primary', onclick: () => control('resume') }, 'Resume') : h('button', { class: 'btn', onclick: () => control('pause'), disabled: !!feedback && false }, 'Pause'),
      h('button', { class: 'btn', onclick: () => control('repeat'), disabled: sess.status === 'paused' || !!feedback }, 'Repeat question'),
      h('button', { class: 'btn', onclick: () => { if (confirm('Skip this question? It will not be scored.')) control('skip'); }, disabled: sess.status === 'paused' || !!feedback }, 'Skip'),
      h('button', { class: 'btn danger', onclick: () => { if (confirm('End the interview now and see your results?')) control('end'); } }, 'End interview'));
    const body = h('div', {});
    if (feedback) {
      const r = feedback.r;
      body.appendChild(h('div', { class: 'card' }, h('h3', {}, 'Feedback on your answer'), h('p', { class: 'muted small' }, 'Q: ' + feedback.answered.text),
        evaluationView(r.evaluation, { evaluationId: r.evaluation.evaluation_id }),
        h('h3', { style: 'margin-top:16px' }, 'Coaching'), coachPanel(sid, feedback.answered.id),
        h('div', { class: 'row', style: 'margin-top:16px' },
          r.next.type === 'complete'
            ? h('a', { class: 'btn primary', href: '#/results/' + sid }, 'Interview complete — view results')
            : h('button', { class: 'btn primary', onclick: () => { feedback = null; lastSpokenQ = null; draw(); } },
              r.next.type === 'followup' ? 'Continue to follow-up question' : 'Next question'),
          r.next.type === 'followup' ? h('span', { class: 'tag gold' }, 'follow-up: ' + (r.next.kind === 'diagnostic' ? 'testing understanding' : 'asking for detail')) : null,
          r.next.difficulty_change && r.next.difficulty_change !== 'same' ? h('span', { class: 'tag' }, 'difficulty will go ' + (r.next.difficulty_change === 'harder' ? 'up' : 'down')) : null)));
    } else if (sess.current_question) {
      const cq = sess.current_question;
      const speaker = h('div', { class: 'row' },
        h('button', { class: 'btn small', onclick: () => speak(cq.text), 'aria-label': 'Play or replay the question aloud' }, '▶ Play / replay'),
        h('button', { class: 'btn small', onclick: pauseSpeaking, 'aria-label': 'Pause or resume reading' }, '⏸ Pause / resume'),
        h('button', { class: 'btn small', 'aria-pressed': String(muted), onclick: (e) => { muted = !muted; if (muted) stopSpeaking(); e.target.textContent = muted ? '🔇 Muted' : '🔊 Mute'; e.target.setAttribute('aria-pressed', String(muted)); } }, muted ? '🔇 Muted' : '🔊 Mute'));
      const ta = h('textarea', { id: 'answer', placeholder: 'Type your answer here… (take your time; it is fine to say you do not know something)', 'aria-label': 'Your answer', oninput: (e) => { answerText = e.target.value; } });
      ta.value = answerText;
      body.appendChild(h('div', { class: 'card qcard' },
        h('div', {}, h('span', { class: 'tag gold' }, cq.topic), h('span', { class: 'tag' }, cq.difficulty), cq.is_followup ? h('span', { class: 'tag ok' }, 'follow-up') : null),
        h('p', { class: 'qtext', id: 'qtext' }, cq.text), speaker));
      body.appendChild(h('div', { class: 'card', style: 'margin-top:16px' },
        sess.input_mode === 'voice' || true ? h('div', {}, micEl, h('div', { class: 'row', style: 'margin:10px 0' },
          h('button', { class: 'btn', onclick: () => (mic.status === 'recording' ? stopRecording() : startRecording()), disabled: mic.status === 'processing' || mic.status === 'requesting' }, mic.status === 'recording' ? '■ Stop & transcribe' : '🎙 Record answer'),
          mic.status === 'recording' ? h('button', { class: 'btn ghost', onclick: cancelRecording }, 'Cancel recording') : null,
          h('span', { class: 'muted small' }, health.stt_configured ? 'Voice is converted to editable text.' : 'Speech recognition is not configured on this server; typing works fully.'))) : null,
        ta,
        h('div', { class: 'row', style: 'margin-top:10px' }, h('button', { class: 'btn primary', id: 'submit', onclick: submit }, 'Submit answer'), h('span', { class: 'muted small' }, 'You can edit transcribed text before submitting.'))));
      drawMic();
      if (lastSpokenQ !== cq.id && sess.input_mode === 'voice' && sess.status === 'active') { lastSpokenQ = cq.id; speak(cq.text); }
    }
    const paused = sess.status === 'paused' ? h('div', { class: 'overlay' }, h('div', { style: 'text-align:center' }, h('h2', {}, 'Interview paused'), h('p', { class: 'muted' }, 'The timer is stopped and the question is hidden.'), h('button', { class: 'btn primary', onclick: () => control('resume') }, 'Resume'))) : null;
    mount(stage, header, h('div', { style: 'margin:12px 0' }, controls), h('div', { style: 'position:relative' }, body, paused));
  }
  mount(root, stage); draw();
  return cleanup;
}
